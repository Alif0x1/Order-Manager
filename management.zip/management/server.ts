import dotenv from "dotenv";
dotenv.config();

import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import mongoose from "mongoose";
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  console.error("❌ CRITICAL: MONGODB_URI is not defined in environment variables.");
  process.exit(1);
}

// Product Schema
const productSchema = new mongoose.Schema({
  handle: String,
  title: String,
  bodyHtml: String,
  vendor: String,
  category: String,
  type: String,
  price: Number,
  compareAtPrice: Number,
  imageSrc: String,
  status: String,
  stock: { type: Number, default: 0 },
  options: [{
    name: String,
    values: [String]
  }],
  variantStock: {
    type: Map,
    of: Number,
    default: {}
  }
});

const Product = mongoose.model("Product", productSchema);

// Coupon Schema
const couponSchema = new mongoose.Schema({
  code: { type: String, unique: true, uppercase: true },
  type: { type: String, enum: ["percentage", "fixed"] },
  value: Number, // Percentage or Fixed amount
  minOrder: { type: Number, default: 0 },
  active: { type: Boolean, default: true }
});

const Coupon = mongoose.model("Coupon", couponSchema);

// Location/Zone Schema
const locationSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  status: { type: String, default: "Active" },
  createdAt: { type: Date, default: Date.now }
});

const Location = mongoose.model("Location", locationSchema);

// Order Schema
const orderSchema = new mongoose.Schema({
  orderNumber: { type: String, unique: true },
  customerName: String,
  customerEmail: String,
  customerPhone: String,
  address: String,
  customerNote: { type: String, default: "" },
  items: [{
    productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
    title: String,
    price: Number,
    quantity: Number,
    variant: String
  }],
  location: String,
  deliveryZone: String,
  deliveryCharge: { type: Number, default: 0 },
  couponCode: String,
  discountAmount: { type: Number, default: 0 },
  totalAmount: Number,
  status: { type: String, default: "Pending" },
  consignmentId: { type: Number },
  trackingCode: { type: String },
  createdAt: { type: Date, default: Date.now }
});

const Order = mongoose.model("Order", orderSchema);

async function generateOrderNumber() {
  const date = new Date();
  const dateStr = date.toISOString().slice(0, 10).replace(/-/g, "");
  const count = await Order.countDocuments({
    createdAt: {
      $gte: new Date(date.setHours(0, 0, 0, 0)),
      $lt: new Date(date.setHours(23, 59, 59, 999))
    }
  });
  return `ORD-${dateStr}-${(count + 1).toString().padStart(4, "0")}`;
}

const app = express();

async function startServer() {
  const PORT = process.env.PORT || 3000;
  app.use(express.json({ limit: "10mb" }));

  // Custom Request Logger
  app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
      const duration = Date.now() - start;
      console.log(`[${new Date().toLocaleTimeString()}] ${req.method} ${req.originalUrl} - ${res.statusCode} (${duration}ms)`);
    });
    next();
  });

  // Connect to MongoDB
  try {
    await mongoose.connect(MONGODB_URI);
    console.log("Connected to MongoDB");
  } catch (err) {
    console.error("MongoDB connection error:", err);
  }

  console.log(`[BOOT] Initializing Order Management System...`);
  console.log("[READY] Steadfast Courier Module Loaded");

  // API Routes
  app.get("/api/ping", (req, res) => res.json({ status: "pong", timestamp: new Date().toISOString() }));

  app.get("/api/health", (req, res) => {
    const isConnected = mongoose.connection.readyState === 1;
    res.json({
      status: isConnected ? "connected" : "disconnected",
      database: "MongoDB Atlas"
    });
  });

  app.post("/api/admin/login", (req, res) => {
    const { password } = req.body;
    const ADMIN_PASS = process.env.ADMIN_PASSWORD || "kali@1122";

    if (password === ADMIN_PASS) {
      res.json({ success: true, token: "admin_session_" + Date.now() });
    } else {
      res.status(401).json({ error: "Unauthorized access denied" });
    }
  });

  app.get("/api/products", async (req, res) => {
    try {
      const { all } = req.query;
      const query = all === "true" ? {} : { status: "active" };
      const products = await Product.find(query);
      res.json(products);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const product = new Product(req.body);
      await product.save();
      res.status(201).json(product);
    } catch (err) {
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  app.patch("/api/products/:id", async (req, res) => {
    try {
      const updatedProduct = await Product.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
      );
      res.json(updatedProduct);
    } catch (err) {
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      await Product.findByIdAndDelete(req.params.id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  app.post("/api/products/seed", async (req, res) => {
    try {
      const sampleProducts = [
        {
          handle: "better-enjoyment-2",
          title: "Better enjoyment white",
          bodyHtml: "<p>X Level Better Enjoyment brings a smooth, premium feel to your phone while keeping it slim and easy to handle.</p>",
          vendor: "Online lifestyle",
          category: "Electronics > Communications > Telephony > Mobile & Smart Phone Accessories > Mobile Phone Cases",
          price: 1250.00,
          compareAtPrice: 1800.00,
          imageSrc: "https://cdn.shopify.com/s/files/1/0721/3740/8556/files/better-enjoyment-whiteonline-lifestyle-4982159.jpg?v=1773924757",
          status: "active"
        },
        {
          handle: "folding-electric-silicone-kettle-600ml",
          title: "Folding Electric Silicone Kettle 600ML",
          bodyHtml: "<p>যারা ট্রাভেল করেন বা যারা সবসময় একটু গরম পানি বা চায়ের চিন্তায় থাকেন -তাদের জন্য নিয়ে এসেছি এই ভাঁজ করা যায় এমন ইলেকট্রিক কেটলি!</p>",
          vendor: "Online lifestyle",
          category: "Home & Garden > Kitchen & Dining > Kitchen Appliances > Electric Kettles",
          price: 820.00,
          compareAtPrice: 1600.00,
          imageSrc: "https://cdn.shopify.com/s/files/1/0721/3740/8556/files/folding-electric-silicone-kettle-600mlonline-lifestyle-3895051.jpg?v=1773924746",
          status: "active"
        }
      ];

      let added = 0;
      for (const p of sampleProducts) {
        const existing = await Product.findOne({ handle: p.handle });
        if (!existing) {
          await new Product(p).save();
          added++;
        }
      }
      res.json({ success: true, added });
    } catch (err) {
      res.status(500).json({ error: "Failed to seed database" });
    }
  });

  app.post("/api/products/upload", async (req, res) => {
    try {
      const { products: csvProducts } = req.body;
      let added = 0;
      let updated = 0;

      for (const p of csvProducts) {
        if (!p.handle) continue;

        const existing = await Product.findOne({ handle: p.handle });
        if (existing) {
          await Product.updateOne({ handle: p.handle }, p);
          updated++;
        } else {
          await new Product(p).save();
          added++;
        }
      }
      res.json({ success: true, added, updated });
    } catch (err) {
      res.status(500).json({ error: "Failed to upload products" });
    }
  });

  const sendShopifyWebhook = async (order: any) => {
    if (!process.env.SHOPIFY_WEBHOOK_URL) return;
    try {
      const payload = {
        id: order._id || Date.now(),
        email: order.customerEmail || "",
        created_at: order.createdAt || new Date().toISOString(),
        order_number: order.orderNumber,
        line_items: (order.items || []).map((item: any) => ({
          title: item.title,
          price: item.price,
          quantity: item.quantity
        })),
        shipping_address: {
          first_name: order.customerName || "Customer",
          last_name: "",
          address1: order.address || "",
          phone: order.customerPhone || "",
          city: order.location || ""
        },
        total_price: order.totalAmount || 0,
        financial_status: "pending"
      };

      const res = await fetch(process.env.SHOPIFY_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) console.warn("External Webhook rejected payload:", res.status);
    } catch (err) {
      console.error("Failed to route external Webhook:", err);
    }
  };

  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = req.body;
      orderData.orderNumber = await generateOrderNumber();

      const newOrder = new Order(orderData);
      await newOrder.save();

      // Automatically add new custom locations
      if (orderData.location) {
        const existingLocation = await Location.findOne({
          name: { $regex: new RegExp(`^${orderData.location}$`, 'i') }
        });
        if (!existingLocation) {
          // If the customer typed a new area not in the DB, create it
          await new Location({ name: orderData.location, status: "Active" }).save();
        }
      }

      // Update Inventory
      for (const item of orderData.items) {
        const product = await Product.findById(item.productId);
        if (product) {
          // Decrement total stock
          if (product.stock !== undefined) {
            product.stock = Math.max(0, product.stock - item.quantity);
          }

          // Decrement variant stock
          if (item.variant && product.variantStock) {
            const currentVariantStock = product.variantStock.get(item.variant) || 0;
            product.variantStock.set(item.variant, Math.max(0, currentVariantStock - item.quantity));
          }

          await product.save();
        }
      }

      res.status(201).json(newOrder);
    } catch (err) {
      console.error("Order error:", err);
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  app.get("/api/orders", async (req, res) => {
    try {
      // Limit to 300 to drastically reduce loading times.
      const orders = await Order.find().sort({ createdAt: -1 }).limit(300);
      res.json(orders);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  // Manual Steadfast Courier Push
  app.post("/api/orders/:id/send-to-steadfast", async (req, res) => {
    try {
      const order = await Order.findById(req.params.id);
      if (!order) return res.status(404).json({ error: "Order not found" });
      if (order.trackingCode) return res.status(400).json({ error: "Already sent to courier" });

      if (!process.env.STEADFAST_API_KEY || !process.env.STEADFAST_SECRET_KEY) {
        return res.status(500).json({ error: "Steadfast keys not configured" });
      }

      const itemsText = (order.items || []).map((i: any) => `${i.quantity}x ${i.title}`).join(", ");

      const steadfastData = {
        invoice: order.orderNumber,
        recipient_name: order.customerName || "Customer",
        recipient_phone: order.customerPhone || "00000000000",
        recipient_address: order.address || "N/A",
        recipient_email: order.customerEmail || "",
        cod_amount: order.totalAmount || 0,
        note: order.customerNote || "",
        item_description: itemsText.length > 500 ? itemsText.substring(0, 497) + "..." : itemsText
      };

      const steadfastResponse = await fetch("https://portal.packzy.com/api/v1/create_order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Api-Key": process.env.STEADFAST_API_KEY,
          "Secret-Key": process.env.STEADFAST_SECRET_KEY
        },
        body: JSON.stringify(steadfastData)
      });

      if (steadfastResponse.ok) {
        const steadfastResult = await steadfastResponse.json();
        if (steadfastResult.status === 200 && steadfastResult.consignment) {
          order.consignmentId = steadfastResult.consignment.consignment_id;
          order.trackingCode = steadfastResult.consignment.tracking_code;
          await order.save();

          // Broadcast to the external webhook
          sendShopifyWebhook(order);

          return res.json(order);
        } else {
          return res.status(400).json({ error: "Courier API rejected order", details: steadfastResult });
        }
      } else {
        return res.status(steadfastResponse.status).json({ error: "Courier connection failed" });
      }
    } catch (err) {
      res.status(500).json({ error: "Internal error syncing with courier" });
    }
  });

  // Get current balance from steadfast
  app.get("/api/steadfast/balance", async (req, res) => {
    try {
      if (!process.env.STEADFAST_API_KEY || !process.env.STEADFAST_SECRET_KEY) {
        return res.status(500).json({ error: "Steadfast keys not configured" });
      }
      const response = await fetch("https://portal.packzy.com/api/v1/get_balance", {
        headers: {
          "Api-Key": process.env.STEADFAST_API_KEY,
          "Secret-Key": process.env.STEADFAST_SECRET_KEY,
          "Content-Type": "application/json"
        }
      });
      if (response.ok) {
        const data = await response.json();
        res.json(data);
      } else {
        res.status(response.status).json({ error: "Failed to fetch balance" });
      }
    } catch (err) {
      res.status(500).json({ error: "Courier connection failed" });
    }
  });

  // Get police stations
  app.get("/api/steadfast/police-stations", async (req, res) => {
    try {
      if (!process.env.STEADFAST_API_KEY || !process.env.STEADFAST_SECRET_KEY) {
        return res.status(500).json({ error: "Steadfast keys not configured" });
      }
      const response = await fetch("https://portal.packzy.com/api/v1/police_stations", {
        headers: {
          "Api-Key": process.env.STEADFAST_API_KEY,
          "Secret-Key": process.env.STEADFAST_SECRET_KEY,
          "Content-Type": "application/json"
        }
      });
      if (response.ok) {
        const data = await response.json();
        res.json(data);
      } else {
        res.status(response.status).json({ error: "Failed to fetch police stations" });
      }
    } catch (err) {
      res.status(500).json({ error: "Courier connection failed" });
    }
  });

  // Get current status from steadfast (Isolated Route)
  app.get("/api/steadfast/status/:id", async (req, res, next) => {
    try {
      const id = req.params.id;
      if (!mongoose.Types.ObjectId.isValid(id)) {
        console.warn(`[Steadfast] Invalid ObjectID requested: ${id}`);
        return res.status(400).json({ error: "Invalid order ID format" });
      }

      const order = await Order.findById(id);
      if (!order) {
        console.warn(`[Steadfast] Order not found for ID: ${id}`);
        return res.status(404).json({ error: "Order record not found" });
      }

      if (!process.env.STEADFAST_API_KEY || !process.env.STEADFAST_SECRET_KEY) {
        console.error("[Steadfast] Missing API keys in .env");
        return res.status(500).json({ error: "Steadfast keys not configured" });
      }

      const headers = {
        "Api-Key": process.env.STEADFAST_API_KEY,
        "Secret-Key": process.env.STEADFAST_SECRET_KEY,
        "Content-Type": "application/json"
      };

      // Robust lookup helper
      const tryLookup = async (path: string, val: any) => {
        if (!val) return null;

        // Timeout handling (10s)
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 10000);

        try {
          const url = `https://portal.packzy.com/api/v1/${path}/${val}`;
          console.log(`[Steadfast] Attempting lookup via ${path}: ${val}`);
          const response = await fetch(url, { headers, signal: controller.signal });

          if (!response.ok) {
            console.error(`[Steadfast] Courier API Error - Status ${response.status} for ${path}`);
            return null;
          }

          const data = await response.json();
          if (data.status === 200 && data.delivery_status) {
            console.log(`[Steadfast] Found status: ${data.delivery_status} via ${path}`);
            return data;
          }
          return null;
        } catch (e: any) {
          if (e.name === 'AbortError') {
            console.error(`[Steadfast] Gateway Timeout for ${path}`);
          } else {
            console.error(`[Steadfast] Request Exception during ${path}:`, e.message);
          }
          return null;
        } finally {
          clearTimeout(timeout);
        }
      };

      // Multi-layer lookup strategy
      let data = await tryLookup("status_by_trackingcode", order.trackingCode);
      if (!data) data = await tryLookup("status_by_cid", order.consignmentId);
      if (!data) data = await tryLookup("status_by_invoice", order.orderNumber);

      if (data) {
        return res.json(data);
      } else {
        console.warn(`[Steadfast] Tracking lookup exhaustion for ${order.orderNumber}`);
        return res.status(404).json({ error: "Order not found in courier system" });
      }
    } catch (err: any) {
      console.error("[Steadfast] Master failure in status route:", err.message);
      return res.status(500).json({ error: "Courier status sync failed" });
    }
  });

  // Customer Intelligence / Fraud Check
  app.get("/api/customers/:phone/history", async (req, res) => {
    try {
      const phone = req.params.phone;
      const historyPromise = Order.find({ customerPhone: phone });

      let networkPromise = Promise.resolve<any>(null);
      if (process.env.FRAUD_BD_API_KEY) {
        console.log(`[FraudBD] Querying for ${phone}...`);
        networkPromise = fetch("https://fraudbd.com/api/check-courier-info", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "api_key": process.env.FRAUD_BD_API_KEY
          },
          body: JSON.stringify({ phone_number: phone })
        })
          .then(res => res.json())
          .catch(err => {
            console.error(`[FraudBD] Fetch error for ${phone}:`, err.message);
            return null;
          });
      } else {
        console.warn("[FraudBD] Missing API key in environment");
      }

      const [history, networkResponse] = await Promise.all([historyPromise, networkPromise]);
      let networkData = null;

      // Extract and normalize data from FraudBD
      if (networkResponse && networkResponse.status === true && networkResponse.data) {
        const raw = networkResponse.data;
        const total = parseInt(raw.total_orders || "0");
        const success = parseInt(raw.successful_deliveries || "0");
        const successRate = total > 0 ? Math.round((success / total) * 100) : 0;

        const mappedSummaries: any = {};
        if (raw.courier_details) {
          Object.entries(raw.courier_details).forEach(([name, details]: [string, any]) => {
            if (details.customer_rating) {
              // Pathao style rating
              mappedSummaries[name] = {
                data_type: "rating",
                customer_rating: details.customer_rating,
                risk_level: details.risk_level || "unknown",
                total: details.total_orders || 0
              };
            } else {
              // Standard ratio
              mappedSummaries[name] = {
                data_type: "ratio",
                success: details.delivered || 0,
                total: (details.delivered || 0) + (details.returned || 0)
              };
            }
          });
        }

        networkData = {
          totalSummary: {
            total,
            success,
            successRate
          },
          Summaries: mappedSummaries
        };

        console.log(`[FraudBD] Success for ${phone}: ${total} global orders found.`);
      } else {
        if (networkResponse) {
          console.log(`[FraudBD] No data or error for ${phone}:`, networkResponse.message || "Manual check required");
        }
      }

      const stats = {
        totalOrders: history.length,
        delivered: history.filter(o => o.status === "Delivered").length,
        returned: history.filter(o => o.status === "Returned").length,
        cancelled: history.filter(o => o.status === "Cancelled").length,
        pending: history.filter(o => o.status === "Pending").length,
        shipped: history.filter(o => o.status === "Shipped").length,
      };

      let globalTotal = stats.totalOrders;
      let globalFailed = stats.returned + stats.cancelled;
      let globalSuccess = stats.delivered;

      if (networkData && networkData.totalSummary) {
        globalTotal += networkData.totalSummary.total || 0;
        globalSuccess += networkData.totalSummary.success || 0;
        // In local stats, cancelled/returned are failure. In network stats, total - success = failure.
        globalFailed += (networkData.totalSummary.total - networkData.totalSummary.success);
      }

      // Calculate Reliability Score based on Global Data
      let reliability = 100;
      if (globalTotal > 0) {
        reliability = Math.max(0, Math.round(((globalTotal - globalFailed) / globalTotal) * 100));
      }

      const globalStats = {
        totalOrders: globalTotal,
        delivered: globalSuccess,
        failed: globalFailed
      };

      res.json({ stats, globalStats, reliability, network: networkData });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to fetch customer history" });
    }
  });

  // Proxy: Get Steadfast Police Stations
  app.get("/api/steadfast/police_stations", async (req, res) => {
    try {
      if (!process.env.STEADFAST_API_KEY || !process.env.STEADFAST_SECRET_KEY) {
        return res.status(500).json({ error: "Steadfast keys not configured" });
      }
      const response = await fetch("https://portal.packzy.com/api/v1/police_stations", {
        headers: {
          "Api-Key": process.env.STEADFAST_API_KEY,
          "Secret-Key": process.env.STEADFAST_SECRET_KEY,
          "Content-Type": "application/json"
        }
      });
      if (response.ok) {
        const data = await response.json();
        res.json(data);
      } else {
        res.status(response.status).json({ error: "Failed to fetch from Steadfast Courier" });
      }
    } catch (err) {
      console.error("Police stations proxy error:", err);
      res.status(500).json({ error: "Courier connection failed" });
    }
  });

  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      const dateFilter: any = {};

      if (startDate || endDate) {
        dateFilter.createdAt = {};
        if (startDate) dateFilter.createdAt.$gte = new Date(startDate as string);
        if (endDate) {
          const end = new Date(endDate as string);
          end.setHours(23, 59, 59, 999);
          dateFilter.createdAt.$lte = end;
        }
      }

      const totalOrders = await Order.countDocuments(dateFilter);
      const totalProducts = await Product.countDocuments();

      const revenueMatch = startDate || endDate ? { $match: dateFilter } : { $match: {} };
      const totalRevenue = await Order.aggregate([
        revenueMatch,
        { $group: { _id: null, total: { $sum: "$totalAmount" } } }
      ]);

      const uniqueCustomers = await Order.aggregate([
        revenueMatch,
        { $group: { _id: "$customerPhone" } },
        { $count: "count" }
      ]);

      const recentOrders = await Order.find(dateFilter).sort({ createdAt: -1 }).limit(5);

      res.json({
        totalOrders,
        totalProducts,
        totalRevenue: totalRevenue[0]?.total || 0,
        uniqueCustomers: uniqueCustomers[0]?.count || 0,
        recentOrders
      });
    } catch (err) {
      console.error("Stats fetch error:", err);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Location CRUD
  app.get("/api/locations", async (req, res) => {
    try {
      const locations = await Location.find().sort({ name: 1 });
      // Attach order count per location
      const locationsWithCounts = await Promise.all(
        locations.map(async (loc) => {
          const orders = await Order.countDocuments({ location: loc.name });
          return { ...loc.toObject(), id: loc._id, orders };
        })
      );
      res.json(locationsWithCounts);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch locations" });
    }
  });

  app.post("/api/locations", async (req, res) => {
    try {
      const location = new Location(req.body);
      await location.save();
      res.status(201).json(location);
    } catch (err: any) {
      if (err.code === 11000) {
        res.status(400).json({ error: "A zone with this name already exists" });
      } else {
        res.status(500).json({ error: "Failed to create location" });
      }
    }
  });

  app.patch("/api/locations/:id", async (req, res) => {
    try {
      const updated = await Location.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
      );
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: "Failed to update location" });
    }
  });

  app.delete("/api/locations/:id", async (req, res) => {
    try {
      await Location.findByIdAndDelete(req.params.id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete location" });
    }
  });

  app.post("/api/coupons/validate", async (req, res) => {
    try {
      const { code, cartTotal } = req.body;
      const coupon = await Coupon.findOne({ code: code.toUpperCase(), active: true });

      if (!coupon) {
        return res.status(404).json({ error: "Invalid or inactive coupon code" });
      }

      if (cartTotal < coupon.minOrder) {
        return res.status(400).json({ error: `Minimum order of ৳${coupon.minOrder} required` });
      }

      let discount = 0;
      if (coupon.type === "percentage") {
        discount = (cartTotal * coupon.value) / 100;
      } else {
        discount = Math.min(coupon.value, cartTotal);
      }

      res.json({
        success: true,
        code: coupon.code,
        discount,
        type: coupon.type,
        value: coupon.value
      });
    } catch (err) {
      res.status(500).json({ error: "Server error during coupon validation" });
    }
  });

  // Coupon CRUD
  app.get("/api/coupons", async (req, res) => {
    try {
      const coupons = await Coupon.find().sort({ code: 1 });
      res.json(coupons);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch coupons" });
    }
  });

  app.post("/api/coupons", async (req, res) => {
    try {
      const coupon = new Coupon(req.body);
      await coupon.save();
      res.status(201).json(coupon);
    } catch (err: any) {
      if (err.code === 11000) {
        res.status(400).json({ error: "A coupon with this code already exists" });
      } else {
        res.status(500).json({ error: "Failed to create coupon" });
      }
    }
  });

  app.patch("/api/coupons/:id", async (req, res) => {
    try {
      const updated = await Coupon.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
      );
      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: "Failed to update coupon" });
    }
  });

  app.delete("/api/coupons/:id", async (req, res) => {
    try {
      await Coupon.findByIdAndDelete(req.params.id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete coupon" });
    }
  });

  app.post("/api/coupons/seed", async (req, res) => {
    try {
      const testCoupons = [
        { code: "SAVE10", type: "percentage", value: 10, minOrder: 500 },
        { code: "WELCOME50", type: "fixed", value: 50, minOrder: 100 },
        { code: "BIGBANG30", type: "percentage", value: 30, minOrder: 2000 }
      ];

      await Coupon.deleteMany({});
      await Coupon.insertMany(testCoupons);
      res.json({ success: true, seeded: testCoupons.length });
    } catch (err) {
      res.status(500).json({ error: "Failed to seed coupons" });
    }
  });

  app.patch("/api/orders/:id", async (req, res) => {
    try {
      const updateData = req.body;
      const updatedOrder = await Order.findByIdAndUpdate(
        req.params.id,
        updateData,
        { new: true }
      );
      res.json(updatedOrder);
    } catch (err) {
      res.status(500).json({ error: "Failed to update order" });
    }
  });

  app.delete("/api/orders/:id", async (req, res) => {
    try {
      await Order.findByIdAndDelete(req.params.id);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to delete order" });
    }
  });

  // Steadfast Incoming Webhook Listener
  app.post("/api/webhooks/steadfast", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      const secret = process.env.STEADFAST_WEBHOOK_SECRET;

      if (!secret || authHeader !== `Bearer ${secret}`) {
        return res.status(401).json({ status: "error", message: "Unauthorized callback" });
      }

      const { notification_type, invoice, status } = req.body;

      // Handle Delivery Status changes
      if (notification_type === "delivery_status" && invoice && status) {
        let mappedStatus = "Shipped"; // Default for active logistics
        const normalizedStatus = status.toLowerCase();

        console.log(`[Steadfast Webhook] Status update for ${invoice}: ${status}`);

        if (normalizedStatus === "delivered" || normalizedStatus === "partial_delivered") {
          mappedStatus = "Delivered";
        } else if (normalizedStatus === "cancelled") {
          mappedStatus = "Cancelled";
        } else if (normalizedStatus === "in_review" || normalizedStatus === "pending" || normalizedStatus.includes("approval_pending")) {
          mappedStatus = "In Review";
        } else if (normalizedStatus === "hold") {
          mappedStatus = "Shipped";
        }

        const updateResult = await Order.findOneAndUpdate({ orderNumber: invoice }, { status: mappedStatus });
        if (updateResult) {
          console.log(`[Steadfast Webhook] Order ${invoice} internal status updated to: ${mappedStatus}`);
        }
      }

      // If It's tracking_update, we don't necessarily update the status yet, but we acknowledge it.

      res.status(200).json({ status: "success", message: "Webhook received successfully." });
    } catch (err) {
      console.error("Webhook processing error:", err);
      res.status(200).json({ status: "error", message: "Webhook processed with internal errors" });
    }
  });

  // Vite middleware for development - MUST BE LAST
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);

    // SPA Fallback for Development
    app.get("*", async (req, res, next) => {
      if (req.originalUrl.startsWith("/api")) return next();
      try {
        const html = await vite.transformIndexHtml(req.originalUrl, `
          <!doctype html>
          <html lang="en">
            <head><meta charset="UTF-8" /></head>
            <body><div id="root"></div><script type="module" src="/src/main.tsx"></script></body>
          </html>
        `);
        res.status(200).set({ "Content-Type": "text/html" }).end(html);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    // Production: Serve static files from 'dist'
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));

    app.get("*", (req, res) => {
      if (req.originalUrl.startsWith("/api")) return res.status(404).json({ error: "API route not found" });
      res.sendFile(path.resolve(distPath, "index.html"));
    });
  }

  // Only listen if not on Vercel
  if (!process.env.VERCEL) {
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  }
}

startServer();

export default app;
