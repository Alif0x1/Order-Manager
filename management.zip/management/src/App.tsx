/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import ProductCard from "./components/ProductCard";
import Cart from "./components/Cart";
import OrderForm from "./components/OrderForm";
import Dashboard from "./components/Dashboard";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";
import { Loader2, PackageCheck, Search, ArrowRight, ShoppingBag } from "lucide-react";

interface Product {
  _id: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  category: string;
  vendor: string;
  options?: Array<{ name: string; values: string[] }>;
}

interface CartItem extends Product {
  quantity: number;
  selectedVariant?: string;
}

export default function App() {
  const [view, setView] = useState<"shop" | "dashboard">("shop");
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckout, setIsCheckout] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [orderSuccess, setOrderSuccess] = useState<string | null>(null);
  const [locations, setLocations] = useState<any[]>([]);
  const [appliedCoupon, setAppliedCoupon] = useState<any | null>(null);
  const [discount, setDiscount] = useState(0);
  const [shopSearch, setShopSearch] = useState("");
  const [lastOrderTotal, setLastOrderTotal] = useState<number>(0);
  const [selectedLocation, setSelectedLocation] = useState("");

  useEffect(() => {
    fetchProducts();
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const response = await fetch("/api/locations");
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      }
    } catch (error) {
      console.error("Failed to fetch locations");
    }
  };

  const fetchProducts = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/products");
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
    } catch (error) {
      console.error("Failed to fetch products");
    } finally {
      setIsLoading(false);
    }
  };

  const addToCart = (product: Product, variant?: string) => {
    setCart((prev) => {
      const existing = prev.find((item) => item._id === product._id && item.selectedVariant === variant);
      if (existing) {
        return prev.map((item) =>
          (item._id === product._id && item.selectedVariant === variant) 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      return [...prev, { ...product, quantity: 1, selectedVariant: variant }];
    });
    toast.success("Added to order!");
  };

  const updateQuantity = (id: string, delta: number, variant?: string) => {
    setCart((prev) =>
      prev.map((item) => {
        if (item._id === id && item.selectedVariant === variant) {
          const newQty = Math.max(1, item.quantity + delta);
          return { ...item, quantity: newQty };
        }
        return item;
      })
    );
  };

  const removeFromCart = (id: string, variant?: string) => {
    setCart((prev) => prev.filter((item) => !(item._id === id && item.selectedVariant === variant)));
    toast.info("Removed from order");
  };

  const handleOrderSubmit = async (customerData: any) => {
    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const deliveryCharge = customerData.deliveryCharge || 0;
    const orderTotal = subtotal - discount + deliveryCharge;
    const order = {
      ...customerData,
      items: cart.map(item => ({
        productId: item._id,
        title: item.title,
        price: item.price,
        quantity: item.quantity,
        variant: item.selectedVariant
      })),
      couponCode: appliedCoupon?.code,
      discountAmount: discount,
      deliveryCharge,
      totalAmount: orderTotal
    };

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order)
      });

      if (response.ok) {
        const result = await response.json();
        setLastOrderTotal(orderTotal);
        setCart([]);
        setIsCartOpen(false);
        setIsCheckout(false);
        setAppliedCoupon(null);
        setDiscount(0);
        setOrderSuccess(result.orderNumber);
        toast.success(`Order ${result.orderNumber} placed successfully!`);
      }
    } catch (error) {
      toast.error("Failed to place order");
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50/50 font-sans antialiased">
      <Navbar 
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)} 
        onOpenCart={() => setIsCartOpen(true)}
        view={view}
        setView={setView}
      />
      
      <main className="container mx-auto px-4 py-6">
        {orderSuccess ? (
          <motion.div 
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="max-w-sm mx-auto text-center py-20"
          >
            <div className="bg-emerald-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <PackageCheck className="h-8 w-8 text-emerald-600" />
            </div>
            <h1 className="text-xl font-bold text-neutral-900 mb-1">Order confirmed</h1>
            <p className="text-sm font-medium text-neutral-900 tabular-nums mb-4">{orderSuccess}</p>
            {lastOrderTotal > 0 && (
              <p className="text-2xl font-bold text-neutral-900 tabular-nums mb-2">৳{lastOrderTotal.toLocaleString()}</p>
            )}
            <p className="text-sm text-neutral-400 mb-8">
              We'll contact you shortly for delivery details.
            </p>
            <button 
              onClick={() => { setOrderSuccess(null); setLastOrderTotal(0); }} 
              className="h-10 px-6 rounded-lg bg-neutral-900 text-white text-sm font-medium hover:bg-neutral-800 transition-all"
            >
              Continue shopping
            </button>
          </motion.div>
        ) : view === "shop" ? (
          <>
            {/* Shop header — content-first, no decoration */}
            <header className="mb-8 max-w-2xl mx-auto text-center pt-6">
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-neutral-900 mb-2">
                Shop
              </h1>
              <p className="text-sm text-neutral-400 mb-6">
                Browse our collection and place your order directly.
              </p>
              <div className="relative max-w-md mx-auto">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-300" />
                <input 
                  value={shopSearch}
                  onChange={(e) => setShopSearch(e.target.value)}
                  placeholder="Search products…"
                  className="w-full h-11 pl-10 pr-4 bg-white rounded-xl border border-neutral-200 text-sm font-medium focus:ring-2 focus:ring-neutral-200 focus:border-transparent outline-none transition-all placeholder:text-neutral-300"
                />
              </div>
            </header>

            {isLoading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="h-6 w-6 animate-spin text-neutral-400" />
              </div>
            ) : (() => {
              const filtered = products.filter(p => 
                p.title.toLowerCase().includes(shopSearch.toLowerCase()) ||
                p.vendor.toLowerCase().includes(shopSearch.toLowerCase()) ||
                p.category?.toLowerCase().includes(shopSearch.toLowerCase())
              );
              return filtered.length === 0 ? (
                <div className="text-center py-20">
                  <p className="text-sm text-neutral-400">No products found for "{shopSearch}"</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  <AnimatePresence>
                    {filtered.map((product, index) => (
                      <motion.div
                        key={product._id}
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.03, duration: 0.25 }}
                      >
                        <ProductCard product={product} onAddToCart={addToCart} />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              );
            })()}
          </>
        ) : (
          <div className="py-4">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-xl font-bold tracking-tight text-neutral-900">Operations</h1>
              <button 
                onClick={() => setView("shop")}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-neutral-500 hover:text-neutral-900 hover:bg-neutral-50 transition-all border border-neutral-200"
              >
                <ShoppingBag className="h-3.5 w-3.5" /> Shop
              </button>
            </div>
            <Dashboard />
          </div>
        )}
        </main>

      <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
        <SheetContent className="w-full sm:max-w-md p-6">
          <SheetHeader>
            <SheetTitle className="text-base font-semibold text-neutral-900">
              {isCheckout ? "Checkout" : "Cart"}
            </SheetTitle>
          </SheetHeader>
          <div className="mt-4 h-[calc(100vh-100px)]">
            {isCheckout ? (
              <OrderForm 
                total={cart.reduce((sum, item) => sum + item.price * item.quantity, 0)}
                discount={discount}
                appliedCoupon={appliedCoupon}
                onCancel={() => setIsCheckout(false)}
                onSubmit={handleOrderSubmit}
                locations={locations}
                initialLocation={selectedLocation}
                onApplyCoupon={(couponData: any) => {
                  setAppliedCoupon(couponData);
                  setDiscount(couponData.discount);
                }}
              />
            ) : (
              <Cart 
                items={cart} 
                onUpdateQuantity={updateQuantity} 
                onRemove={removeFromCart}
                onCheckout={() => setIsCheckout(true)}
                discount={discount}
                appliedCoupon={appliedCoupon}
                onApplyCoupon={(couponData: any) => {
                  setAppliedCoupon(couponData);
                  setDiscount(couponData.discount);
                }}
                locations={locations}
                selectedLocation={selectedLocation}
                onLocationChange={setSelectedLocation}
              />
            )}
          </div>
        </SheetContent>
      </Sheet>

      <Toaster position="bottom-right" />
    </div>
  );
}
