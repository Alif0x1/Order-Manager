import { ShoppingCart, Package } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  view: "shop" | "dashboard";
  setView: (view: "shop" | "dashboard") => void;
}

export default function Navbar({ cartCount, onOpenCart, view, setView }: NavbarProps) {
  return (
    <nav className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-md border-b border-neutral-100">
      <div className="container flex h-14 items-center justify-between px-4 mx-auto">
        <button onClick={() => setView("shop")} className="flex items-center gap-2.5">
          <div className="bg-neutral-900 p-1.5 rounded-lg">
            <Package className="h-4 w-4 text-white" />
          </div>
          <span className="text-sm font-semibold text-neutral-900 tracking-tight hidden sm:block">Order Manager</span>
        </button>
        
        <div className="flex items-center gap-1">
          <button 
            onClick={() => setView("shop")}
            className={`hidden md:flex px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${view === "shop" ? "text-neutral-900 bg-neutral-100" : "text-neutral-400 hover:text-neutral-700"}`}
          >
            Shop
          </button>
          <button 
            onClick={() => setView("dashboard")}
            className={`hidden md:flex px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${view === "dashboard" ? "text-neutral-900 bg-neutral-100" : "text-neutral-400 hover:text-neutral-700"}`}
          >
            Dashboard
          </button>
          
          <button onClick={onOpenCart} className="relative ml-2 p-2 rounded-lg text-neutral-500 hover:text-neutral-900 hover:bg-neutral-50 transition-colors">
            <ShoppingCart className="h-5 w-5" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 h-4 w-4 flex items-center justify-center rounded-full bg-neutral-900 text-white text-[10px] font-semibold">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </nav>
  );
}
