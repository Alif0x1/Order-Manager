import * as React from "react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Upload, FileText, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import Papa from "papaparse";
import { toast } from "sonner";

export default function CsvUpload({ onUploadSuccess }: { onUploadSuccess: () => void }) {
  const [isUploading, setIsUploading] = useState(false);
  const [file, setFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = () => {
    if (!file) return;

    setIsUploading(true);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const products = results.data.map((row: any) => ({
            handle: row.Handle,
            title: row.Title,
            bodyHtml: row["Body (HTML)"],
            vendor: row.Vendor,
            category: row["Product Category"],
            type: row.Type,
            price: parseFloat(row["Variant Price"]) || 0,
            compareAtPrice: parseFloat(row["Variant Compare At Price"]) || 0,
            imageSrc: row["Image Src"],
            status: row.Status || "active",
            options: row["Option1 Name"] ? [{
              name: row["Option1 Name"],
              values: [row["Option1 Value"]]
            }] : []
          })).filter(p => p.handle && p.title);

          const response = await fetch("/api/products/upload", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ products })
          });

          if (response.ok) {
            const data = await response.json();
            toast.success(`Successfully uploaded! Added: ${data.added}, Updated: ${data.updated}`);
            setFile(null);
            onUploadSuccess();
          } else {
            const errorData = await response.json().catch(() => ({}));
            toast.error(errorData.error || "Failed to upload products. Check database connection.");
          }
        } catch (error) {
          console.error(error);
          toast.error("Error processing CSV file");
        } finally {
          setIsUploading(false);
        }
      }
    });
  };

  return (
    <Card className="border-dashed border-2 bg-muted/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5 text-blue-600" />
          Bulk Product Upload
        </CardTitle>
        <CardDescription>
          Upload a Shopify-formatted CSV file to add or update products.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-8 bg-background">
          <FileText className="h-12 w-12 text-muted-foreground mb-4" />
          <Input 
            type="file" 
            accept=".csv" 
            onChange={handleFileChange}
            className="max-w-xs cursor-pointer"
          />
          {file && (
            <p className="mt-2 text-sm font-medium text-blue-600">
              Selected: {file.name}
            </p>
          )}
        </div>
        
        <Button 
          onClick={handleUpload} 
          disabled={!file || isUploading}
          className="w-full bg-blue-600 hover:bg-blue-700"
        >
          {isUploading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            "Start Upload"
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
