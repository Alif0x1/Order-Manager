import React, { useState, useEffect, useCallback } from "react";
import OrdersManager from "./admin/OrdersManager";
import InventoryManager from "./admin/InventoryManager";
import CouponsManager from "./admin/CouponsManager";
import ZonesManager from "./admin/ZonesManager";
import { 
  ShoppingBag, Users, DollarSign, Package, Loader2, Database, 
  AlertTriangle, RefreshCw, MoreVertical, CheckCircle, RotateCcw, 
  Trash2, Edit3, MapPin, History, LayoutDashboard, Search,
  Plus, X, ChevronRight, Eye, Tag, Store, Ticket, User, Truck, Calendar,
  Bell, Settings, LogOut, Menu
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { 
  Card, CardContent, CardHeader, CardTitle, CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

// Logic parts reused from Dashboard
interface Stats {
  totalOrders: number;
  totalProducts: number;
  totalRevenue: number;
  recentOrders: any[];
}

interface Product {
  _id?: string;
  handle: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  vendor: string;
  category: string;
  status: string;
  stock?: number;
  options?: Array<{ name: string; values: string[] }>;
  variantStock?: Record<string, number>;
}

const STATUS_COLORS: Record<string, string> = {
  "Pending": "bg-yellow-100 text-yellow-700 border-yellow-200",
  "Shipped": "bg-indigo-100 text-indigo-700 border-indigo-200",
  "Delivered": "bg-emerald-100 text-emerald-700 border-emerald-200",
  "Returned": "bg-orange-100 text-orange-700 border-orange-200",
  "Cancelled": "bg-slate-100 text-slate-700 border-slate-200"
};

export default function AdminPortal({ onBackToShop }: { onBackToShop: () => void }) {
  const [activeTab, setActiveTab] = useState<"overview" | "orders" | "inventory" | "coupons" | "zones">("overview");
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [dbStatus, setDbStatus] = useState<"connected" | "disconnected" | "checking">("checking");

  const fetchStats = useCallback(async () => {
    try {
      const response = await fetch("/api/dashboard/stats");
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      toast.error("Failed to sync metrics");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  return (
    <div className="flex h-screen bg-[#F8FAFC] overflow-hidden font-sans selection:bg-indigo-100 selection:text-indigo-900 text-slate-900">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 80 }}
        className="bg-white border-r border-slate-200 flex flex-col relative z-20 shadow-xl shadow-slate-200/50"
      >
        <div className="p-6 flex items-center justify-between">
          <AnimatePresence mode="wait">
            {isSidebarOpen ? (
              <motion.div 
                key="logo-full"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="flex items-center gap-3"
              >
                <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-200">
                  <Database className="text-white h-5 w-5" />
                </div>
                <span className="font-black text-xl tracking-tight text-slate-900">ADMIN<span className="text-indigo-600">PRO</span></span>
              </motion.div>
            ) : (
              <motion.div 
                key="logo-icon"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto"
              >
                <Database className="text-white h-5 w-5" />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          <SidebarItem 
            active={activeTab === "overview"} 
            onClick={() => setActiveTab("overview")} 
            icon={<LayoutDashboard />} 
            label="Overview" 
            collapsed={!isSidebarOpen} 
          />
          <SidebarItem 
            active={activeTab === "orders"} 
            onClick={() => setActiveTab("orders")} 
            icon={<ShoppingBag />} 
            label="Order History" 
            collapsed={!isSidebarOpen} 
          />
          <SidebarItem 
            active={activeTab === "inventory"} 
            onClick={() => setActiveTab("inventory")} 
            icon={<Package />} 
            label="Inventory" 
            collapsed={!isSidebarOpen} 
          />
          <SidebarItem 
            active={activeTab === "coupons"} 
            onClick={() => setActiveTab("coupons")} 
            icon={<Ticket />} 
            label="Promotions" 
            collapsed={!isSidebarOpen} 
          />
          <SidebarItem 
            active={activeTab === "zones"} 
            onClick={() => setActiveTab("zones")} 
            icon={<MapPin />} 
            label="Delevary Zones" 
            collapsed={!isSidebarOpen} 
          />
        </nav>

        <div className="p-4 border-t border-slate-100">
          <SidebarItem 
            active={false}
            onClick={onBackToShop} 
            icon={<Store />} 
            label="Exit to Shop" 
            collapsed={!isSidebarOpen}
            className="text-slate-500 hover:text-indigo-600 hover:bg-indigo-50"
          />
        </div>
        
        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="absolute -right-3 top-20 w-6 h-6 bg-white border border-slate-200 rounded-full flex items-center justify-center shadow-sm hover:bg-slate-50 transition-colors"
        >
          <ChevronRight className={`h-3 w-3 transition-transform ${isSidebarOpen ? "rotate-180" : ""}`} />
        </button>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Top Header */}
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-4 flex-1 max-w-xl">
             <div className="relative flex-1 group">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
                <Input 
                  placeholder="Global search..." 
                  className="pl-10 h-11 bg-slate-100 border-none focus:ring-2 focus:ring-indigo-500 rounded-xl transition-all w-full max-w-sm"
                />
             </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${dbStatus === 'connected' ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Server {dbStatus}</span>
            </div>
            
            <Separator orientation="vertical" className="h-6" />
            
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-black text-slate-900">Admin User</p>
                <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">Store Owner</p>
              </div>
              <div className="w-10 h-10 rounded-2xl bg-slate-900 border-2 border-white shadow-lg flex items-center justify-center text-white font-black overflow-hidden hover:scale-105 transition-transform cursor-pointer">
                <User className="h-5 w-5" />
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8 no-scrollbar bg-slate-50/50">
          <AnimatePresence mode="wait">
            {activeTab === "overview" && (
              <motion.div
                key="tab-overview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                 <div className="flex flex-col gap-1">
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight">System Overview</h2>
                    <p className="text-slate-500 font-medium">Monitoring business pulse performance.</p>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <DashboardMetric 
                      title="Gross Revenue" 
                      value={`৳${(stats?.totalRevenue || 0).toLocaleString()}`} 
                      trend="+12.5%" 
                      icon={<DollarSign className="text-emerald-600" />} 
                      color="emerald"
                    />
                    <DashboardMetric 
                      title="Success Orders" 
                      value={stats?.totalOrders || 0} 
                      trend="+5.2%" 
                      icon={<ShoppingBag className="text-indigo-600" />} 
                      color="indigo"
                    />
                    <DashboardMetric 
                      title="Active Inventory" 
                      value={stats?.totalProducts || 0} 
                      trend="Stable" 
                      icon={<Package className="text-amber-600" />} 
                      color="amber"
                    />
                    <DashboardMetric 
                      title="Growth Rate" 
                      value="78%" 
                      trend="+2.1%" 
                      icon={<Users className="text-rose-600" />} 
                      color="rose"
                    />
                 </div>

                 {/* Placeholder for more complex components */}
                 <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <Card className="lg:col-span-2 border-none shadow-sm rounded-3xl bg-white p-8">
                       <div className="flex items-center justify-between mb-8">
                          <div>
                             <CardTitle className="text-xl font-black">Market Performance</CardTitle>
                             <CardDescription>Real-time delivery & sales volume</CardDescription>
                          </div>
                          <Button variant="outline" className="rounded-xl border-slate-200">View Full Reports</Button>
                       </div>
                       <div className="h-64 flex items-center justify-center bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200 text-slate-400 font-bold italic">
                          Analytical Charts Loading...
                       </div>
                    </Card>

                    <Card className="border-none shadow-sm rounded-3xl bg-white p-8 overflow-hidden">
                       <CardTitle className="text-xl font-black mb-6">Recent Activity</CardTitle>
                       <div className="space-y-6">
                          {stats?.recentOrders?.map((order: any, idx) => (
                            <div key={order._id || idx} className="flex items-start gap-4">
                               <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center font-black text-indigo-600 shrink-0">
                                  {idx + 1}
                               </div>
                               <div className="flex-1 min-w-0">
                                  <p className="font-bold text-slate-900 truncate">{order.customerName}</p>
                                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{order.orderNumber}</p>
                               </div>
                               <div className="text-right">
                                  <p className="font-black text-slate-900">৳{order.totalAmount?.toLocaleString()}</p>
                                  <p className="text-[10px] font-bold text-emerald-600">SUCCESS</p>
                               </div>
                            </div>
                          ))}
                       </div>
                       <Button variant="ghost" className="w-full mt-8 rounded-xl hover:bg-indigo-50 text-indigo-600 font-bold">See All Activity</Button>
                    </Card>
                 </div>
              </motion.div>
            )}

            {activeTab === "orders" && (
              <motion.div key="tab-orders" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                <OrdersManager />
              </motion.div>
            )}
            {activeTab === "inventory" && (
              <motion.div key="tab-inventory" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                <InventoryManager />
              </motion.div>
            )}
            {activeTab === "coupons" && (
              <motion.div key="tab-coupons" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                <CouponsManager />
              </motion.div>
            )}
            {activeTab === "zones" && (
              <motion.div key="tab-zones" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                <ZonesManager />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

function SidebarItem({ active, onClick, icon, label, collapsed, className = "" }: any) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center transition-all duration-300 rounded-2xl group ${
        active 
          ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" 
          : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
      } ${collapsed ? "justify-center p-3" : "px-4 py-3.5 gap-4"} ${className}`}
    >
      <div className={`transition-transform duration-300 ${active ? "scale-110" : "group-hover:scale-110"}`}>
        {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: "h-5 w-5" }) : icon}
      </div>
      <AnimatePresence>
        {!collapsed && (
          <motion.span 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            className="font-black text-sm tracking-tight whitespace-nowrap"
          >
            {label}
          </motion.span>
        )}
      </AnimatePresence>
      {active && !collapsed && (
         <motion.div layoutId="sidebar-blob" className="ml-auto w-1.5 h-6 bg-white/20 rounded-full" />
      )}
    </button>
  );
}

function DashboardMetric({ title, value, trend, icon, color }: any) {
  const colorMap: any = {
    indigo: "bg-indigo-50 text-indigo-600 shadow-indigo-100",
    emerald: "bg-emerald-50 text-emerald-600 shadow-emerald-100",
    amber: "bg-amber-50 text-amber-600 shadow-amber-100",
    rose: "bg-rose-50 text-rose-600 shadow-rose-100",
  };

  return (
    <Card className="border-none shadow-sm hover:shadow-xl transition-all duration-500 rounded-[2rem] bg-white group overflow-hidden">
      <CardContent className="p-8">
        <div className="flex items-center justify-between mb-6">
          <div className={`${colorMap[color]} p-4 rounded-2xl group-hover:scale-110 transition-transform duration-500`}>
             {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: "h-6 w-6" }) : icon}
          </div>
          <span className={`text-[10px] font-black px-2 py-1 rounded-full bg-slate-50 text-slate-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors`}>{trend}</span>
        </div>
        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-2">{title}</p>
        <p className="text-3xl font-black text-slate-900">{value}</p>
      </CardContent>
    </Card>
  );
}
