import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  ShoppingBag, Users, DollarSign, Package, Loader2, Database,
  AlertTriangle, RefreshCw, MoreVertical, CheckCircle, RotateCcw,
  Trash2, Edit3, MapPin, History, LayoutDashboard, Search,
  Plus, X, ChevronRight, Eye, Tag, Store, Ticket, User, Truck, Calendar,
  BarChart3, CalendarDays, Lock, ShieldCheck, KeyRound, ArrowRight, FileText, Upload, Zap,
  ChevronDown, Activity, TrendingUp, Shield, Globe, ArrowUpRight
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import Papa from "papaparse";
import { Label } from "@/components/ui/label";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { Separator } from "@/components/ui/separator";

interface Stats {
  totalOrders: number;
  totalProducts: number;
  totalRevenue: number;
  uniqueCustomers: number;
  recentOrders: any[];
}

interface Location {
  id: number;
  name: string;
  orders: number;
  status: string;
}

interface Product {
  _id?: string;
  handle: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  vendor: string;
  category: string;
  status: string;
  stock?: number;
  options?: Array<{ name: string; values: string[] }>;
  variantStock?: Record<string, number>;
}

const STATUS_COLORS: Record<string, string> = {
  "Pending": "bg-amber-50 text-amber-700",
  "Shipped": "bg-sky-50 text-sky-700",
  "Delivered": "bg-emerald-50 text-emerald-700",
  "Returned": "bg-rose-50 text-rose-700",
  "Cancelled": "bg-neutral-100 text-neutral-500"
};

const STEADFAST_STATUS_MAP: Record<string, string> = {
  "pending": "Pending",
  "delivered_approval_pending": "Delivered (Approval Pending)",
  "partial_delivered_approval_pending": "Partial Delivered (Approval Pending)",
  "cancelled_approval_pending": "Cancelled (Approval Pending)",
  "unknown_approval_pending": "Unknown Pending",
  "delivered": "Delivered",
  "partial_delivered": "Partially Delivered",
  "cancelled": "Cancelled",
  "hold": "Hold",
  "in_review": "In Review",
  "unknown": "Unknown"
};

const STEADFAST_STATUS_THEMES: Record<string, string> = {
  "pending": "bg-neutral-100 text-neutral-600 border-neutral-200",
  "delivered_approval_pending": "bg-indigo-50 text-indigo-600 border-indigo-100",
  "partial_delivered_approval_pending": "bg-indigo-50 text-indigo-600 border-indigo-100",
  "cancelled_approval_pending": "bg-rose-50 text-rose-600 border-rose-100",
  "unknown_approval_pending": "bg-slate-50 text-slate-600 border-slate-200",
  "delivered": "bg-emerald-50 text-emerald-700 border-emerald-100",
  "partial_delivered": "bg-emerald-50 text-emerald-600 border-emerald-100",
  "cancelled": "bg-rose-100 text-rose-700 border-rose-200",
  "hold": "bg-amber-50 text-amber-700 border-amber-100",
  "in_review": "bg-sky-50 text-sky-700 border-sky-100",
  "unknown": "bg-slate-100 text-slate-500 border-slate-200"
};

const STATUS_DOT: Record<string, string> = {
  "Pending": "bg-amber-400",
  "In Review": "bg-sky-400",
  "Shipped": "bg-indigo-400",
  "Delivered": "bg-emerald-400",
  "Returned": "bg-rose-400",
  "Cancelled": "bg-neutral-400"
};

const INTERNAL_STATUS_DESCRIPTIONS: Record<string, string> = {
  "Pending": "Order received and waiting for initial processing.",
  "In Review": "Our team is currently verifying your delivery coordinates.",
  "Shipped": "Order is out with our logistics partner.",
  "Delivered": "Order successfully fulfilled and received.",
  "Returned": "Order could not be delivered and has been returned.",
  "Cancelled": "This transaction has been voided."
};

interface CouponItem {
  _id?: string;
  code: string;
  type: "percentage" | "fixed";
  value: number;
  minOrder: number;
  active: boolean;
}

export default function Dashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loginPassword, setLoginPassword] = useState("");
  const [isLoginLoading, setIsLoginLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"overview" | "history" | "locations" | "products" | "coupons">("overview");
  const [stats, setStats] = useState<Stats | null>(null);
  const [allOrders, setAllOrders] = useState<any[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDataLoading, setIsDataLoading] = useState(false);
  const [dbStatus, setDbStatus] = useState<"connected" | "disconnected" | "checking">("checking");
  const [isUpdating, setIsUpdating] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const [steadfastStatus, setSteadfastStatus] = useState<string | null>(null);
  const [isSteadfastLoading, setIsSteadfastLoading] = useState(false);
  const [courierBalance, setCourierBalance] = useState<number | null>(null);

  // Edit Order Modal State
  const [editingOrder, setEditingOrder] = useState<any | null>(null);
  const [editFormData, setEditFormData] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    address: "",
    deliveryZone: "",
    deliveryCharge: 0
  });

  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [customerHistory, setCustomerHistory] = useState<any | null>(null);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  const [isPushingCourier, setIsPushingCourier] = useState(false);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  // Product Modal State
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [isCsvUploading, setIsCsvUploading] = useState(false);
  const [lastOrderCount, setLastOrderCount] = useState<number | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [variantInput, setVariantInput] = useState("");
  const [productFormData, setProductFormData] = useState<Product>({
    handle: "",
    title: "",
    price: 0,
    compareAtPrice: 0,
    imageSrc: "",
    vendor: "Online lifestyle",
    category: "General",
    status: "active",
    stock: 0,
    options: [{ name: "Variant", values: [] }],
    variantStock: {}
  });

  // Coupon State
  const [coupons, setCoupons] = useState<CouponItem[]>([]);
  const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<CouponItem | null>(null);
  const [couponFormData, setCouponFormData] = useState<CouponItem>({
    code: "",
    type: "percentage",
    value: 0,
    minOrder: 0,
    active: true
  });

  const fetchStats = useCallback(async (silent = false) => {
    if (!silent) setIsLoading(true);
    try {
      let url = "/api/dashboard/stats";
      const params = new URLSearchParams();
      if (startDate) params.append("startDate", startDate);
      if (endDate) params.append("endDate", endDate);

      const queryString = params.toString();
      if (queryString) url += `?${queryString}`;

      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setStats(data);
        if (!silent) toast.success("Fulfillment intelligence updated");
      }
    } catch (error) {
      console.error("Failed to fetch stats");
      toast.error("Intelligence synchronization failed");
    } finally {
      setIsLoading(false);
    }
  }, [startDate, endDate]);

  const fetchCourierBalance = useCallback(async () => {
    try {
      const response = await fetch("/api/steadfast/balance");
      if (response.ok) {
        const data = await response.json();
        setCourierBalance(data.current_balance);
      }
    } catch (error) {
      console.error("Failed to fetch balance");
    }
  }, []);

  useEffect(() => {
    if (selectedOrder?.customerPhone) {
      setIsHistoryLoading(true);
      fetch(`/api/customers/${selectedOrder.customerPhone}/history`)
        .then(res => res.json())
        .then(data => setCustomerHistory(data))
        .catch(() => setCustomerHistory(null))
        .finally(() => setIsHistoryLoading(false));
    } else {
      setCustomerHistory(null);
    }
  }, [selectedOrder?.customerPhone]);

  useEffect(() => {
    fetchStats(true);
    fetchCourierBalance();
  }, [fetchStats, fetchCourierBalance]);

  // Background Monitoring (Active while locked or unlocked)
  useEffect(() => {
    const monitorOrders = async () => {
      try {
        const response = await fetch("/api/dashboard/stats");
        if (response.ok) {
          const data = await response.json();
          // Initialize count on first load
          if (lastOrderCount === null) {
            setLastOrderCount(data.totalOrders);
            return;
          }
          // Compare and notify if new orders arrived
          if (data.totalOrders > lastOrderCount) {
            toast("New Operational Demand Received", {
              description: "A new order has entered the fulfillment queue.",
              icon: <Zap className="h-4 w-4 text-yellow-500" />,
              action: {
                label: "Authorize to View",
                onClick: () => { } // Just a hint to login
              }
            });
            setLastOrderCount(data.totalOrders);
            // Refresh stats if already authenticated
            if (isAuthenticated) fetchStats(true);
          }
        }
      } catch (err) {
        console.warn("Background monitoring heartbeat lost");
      }
    };

    const interval = setInterval(monitorOrders, 30000); // 30s heartbeat
    monitorOrders(); // Initial check
    return () => clearInterval(interval);
  }, [lastOrderCount, isAuthenticated, fetchStats]);

  useEffect(() => {
    const session = localStorage.getItem("admin_session");
    if (session) {
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoginLoading(true);
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: loginPassword })
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem("admin_session", data.token);
        setIsAuthenticated(true);
        toast.success("Command Center Authorized");
      } else {
        toast.error("Invalid access credentials");
      }
    } catch (error) {
      toast.error("Security system unreachable");
    } finally {
      setIsLoginLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("admin_session");
    setIsAuthenticated(false);
    toast.info("System Locked");
  };

  const fetchAllOrders = async () => {
    setIsDataLoading(true);
    try {
      const response = await fetch("/api/orders");
      if (response.ok) {
        const data = await response.json();
        setAllOrders(data);
      }
    } catch (error) {
      toast.error("Failed to fetch order history");
    } finally {
      setIsDataLoading(false);
    }
  };

  const fetchAllProducts = async () => {
    setIsDataLoading(true);
    try {
      const response = await fetch("/api/products?all=true");
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
    } catch (error) {
      toast.error("Failed to fetch products");
    } finally {
      setIsDataLoading(false);
    }
  };

  const fetchLocations = async () => {
    setIsDataLoading(true);
    try {
      const response = await fetch("/api/locations");
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      }
    } catch (error) {
      console.error("Failed to fetch locations");
    } finally {
      setIsDataLoading(false);
    }
  };

  const handleCsvUpload = () => {
    if (!csvFile) return;
    setIsCsvUploading(true);
    Papa.parse(csvFile, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const productsData = results.data.map((row: any) => ({
            handle: row.Handle,
            title: row.Title,
            bodyHtml: row["Body (HTML)"],
            vendor: row.Vendor,
            category: row["Product Category"],
            type: row.Type,
            price: parseFloat(row["Variant Price"]) || 0,
            compareAtPrice: parseFloat(row["Variant Compare At Price"]) || 0,
            imageSrc: row["Image Src"],
            status: row.Status || "active",
            options: row["Option1 Name"] ? [{
              name: row["Option1 Name"],
              values: [row["Option1 Value"]]
            }] : []
          })).filter(p => p.handle && p.title);

          const response = await fetch("/api/products/upload", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ products: productsData })
          });

          if (response.ok) {
            const data = await response.json();
            toast.success(`Registry updated: ${data.added} added, ${data.updated} localized`);
            setCsvFile(null);
            setIsCsvModalOpen(false);
            fetchAllProducts();
          } else {
            toast.error("Bulk sync failed");
          }
        } catch (error) {
          toast.error("Data translation error");
        } finally {
          setIsCsvUploading(false);
        }
      }
    });
  };

  const checkDbStatus = useCallback(async () => {
    try {
      const response = await fetch("/api/health");
      if (response.ok) {
        const data = await response.json();
        setDbStatus(data.status);
      } else {
        setDbStatus("disconnected");
      }
    } catch (error) {
      setDbStatus("disconnected");
    }
  }, []);

  const fetchSteadfastStatus = useCallback(async (orderId: string) => {
    setIsSteadfastLoading(true);
    try {
      const res = await fetch(`/api/steadfast/status/${orderId}`);
      const data = await res.json();

      if (res.status === 200) {
        const rawStatus: string = data.delivery_status;
        if (rawStatus) {
          setSteadfastStatus(STEADFAST_STATUS_MAP[rawStatus.toLowerCase()] || rawStatus.replace(/_/g, ' '));
        } else {
          setSteadfastStatus("Unknown/Pending");
        }
      } else if (res.status === 404) {
        setSteadfastStatus("Not found in Courier system");
      } else {
        setSteadfastStatus("Courier sync error");
      }
    } catch (error) {
      setSteadfastStatus("Connection error");
    } finally {
      setIsSteadfastLoading(false);
    }
  }, []);

  const fetchAllData = useCallback(() => {
    fetchStats(true);
    fetchAllOrders();
    fetchAllProducts();
    fetchLocations();
    fetchCoupons();
    checkDbStatus();
    fetchCourierBalance();
  }, [fetchStats, fetchCourierBalance]);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  useEffect(() => {
    if (selectedOrder) {
      if (selectedOrder.consignmentId || selectedOrder.trackingCode || selectedOrder.orderNumber) {
        fetchSteadfastStatus(selectedOrder._id);
      } else {
        setSteadfastStatus("Not dispatched via courier");
      }
    } else {
      setSteadfastStatus(null);
    }
  }, [selectedOrder, fetchSteadfastStatus]);


  const fetchCoupons = async () => {
    setIsDataLoading(true);
    try {
      const response = await fetch("/api/coupons");
      if (response.ok) {
        const data = await response.json();
        setCoupons(data);
      }
    } catch (error) {
      toast.error("Failed to fetch coupons");
    } finally {
      setIsDataLoading(false);
    }
  };

  const handleCouponSubmit = async () => {
    setIsDataLoading(true);
    const method = editingCoupon ? "PATCH" : "POST";
    const url = editingCoupon ? `/api/coupons/${editingCoupon._id}` : "/api/coupons";
    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...couponFormData, code: couponFormData.code.toUpperCase() })
      });
      if (response.ok) {
        toast.success(`Coupon ${editingCoupon ? "updated" : "created"} successfully!`);
        setIsCouponModalOpen(false);
        fetchCoupons();
      } else {
        const err = await response.json();
        toast.error(err.error || "Failed to save coupon");
      }
    } catch (error) {
      toast.error("Error saving coupon");
    } finally {
      setIsDataLoading(false);
    }
  };

  const toggleCouponActive = async (coupon: CouponItem) => {
    try {
      const response = await fetch(`/api/coupons/${coupon._id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active: !coupon.active })
      });
      if (response.ok) {
        toast.success(`Coupon ${coupon.code} ${coupon.active ? "disabled" : "enabled"}`);
        fetchCoupons();
      }
    } catch (error) {
      toast.error("Failed to toggle coupon");
    }
  };

  const deleteCoupon = async (couponId: string) => {
    if (!confirm("Delete this coupon permanently?")) return;
    setIsUpdating(couponId);
    try {
      const response = await fetch(`/api/coupons/${couponId}`, { method: "DELETE" });
      if (response.ok) {
        toast.success("Coupon deleted");
        fetchCoupons();
      }
    } catch (error) {
      toast.error("Failed to delete coupon");
    } finally {
      setIsUpdating(null);
    }
  };

  const openAddCoupon = () => {
    setEditingCoupon(null);
    setCouponFormData({ code: "", type: "percentage", value: 0, minOrder: 0, active: true });
    setIsCouponModalOpen(true);
  };

  const handleEditCoupon = (coupon: CouponItem) => {
    setEditingCoupon(coupon);
    setCouponFormData(coupon);
    setIsCouponModalOpen(true);
  };

  useEffect(() => {
    if (activeTab === "history") fetchAllOrders();
    if (activeTab === "locations") fetchLocations();
    if (activeTab === "products") fetchAllProducts();
    if (activeTab === "coupons") fetchCoupons();
  }, [activeTab]);

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    setIsUpdating(orderId);
    try {
      const response = await fetch(`/api/orders/${orderId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });

      if (response.ok) {
        toast.success(`Order status updated to ${newStatus}`);
        fetchStats(true);
        if (activeTab === "history") fetchAllOrders();
        if (selectedOrder && selectedOrder._id === orderId) {
          setSelectedOrder({ ...selectedOrder, status: newStatus });
        }
      } else {
        toast.error("Failed to update status");
      }
    } catch (error) {
      toast.error("Error updating status");
    } finally {
      setIsUpdating(null);
    }
  };

  const handleEditOrderClick = (order: any) => {
    setEditingOrder(order);
    setEditFormData({
      customerName: order.customerName,
      customerEmail: order.customerEmail,
      customerPhone: order.customerPhone,
      address: order.address,
      deliveryZone: order.deliveryZone || "",
      deliveryCharge: order.deliveryCharge || 0
    });
  };

  const saveOrderEdit = async () => {
    if (!editingOrder) return;
    setIsUpdating(editingOrder._id);
    try {
      const response = await fetch(`/api/orders/${editingOrder._id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editFormData)
      });

      if (response.ok) {
        toast.success("Order details updated");
        setEditingOrder(null);
        fetchStats(true);
        if (activeTab === "history") fetchAllOrders();
      } else {
        toast.error("Failed to update order");
      }
    } catch (error) {
      toast.error("Error saving changes");
    } finally {
      setIsUpdating(null);
    }
  };

  const deleteOrder = async (orderId: string) => {
    if (!confirm("Are you sure you want to delete this order?")) return;

    setIsUpdating(orderId);
    try {
      const response = await fetch(`/api/orders/${orderId}`, {
        method: "DELETE"
      });

      if (response.ok) {
        toast.success("Order deleted successfully");
        fetchStats(true);
        if (activeTab === "history") fetchAllOrders();
        if (selectedOrder && selectedOrder._id === orderId) setSelectedOrder(null);
      } else {
        toast.error("Failed to delete order");
      }
    } catch (error) {
      toast.error("Error deleting order");
    } finally {
      setIsUpdating(null);
    }
  };

  const handlePushToCourier = async () => {
    if (!selectedOrder) return;
    setIsPushingCourier(true);
    try {
      const res = await fetch(`/api/orders/${selectedOrder._id}/send-to-steadfast`, { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        toast.success("Logistics Sync Complete");
        setSelectedOrder(data); // update viewing order with tracking
        fetchAllOrders();
        fetchStats(true);
      } else {
        toast.error(data.error || "Courier assignment failed");
      }
    } catch (err) {
      toast.error("Network error during courier assignment");
    } finally {
      setIsPushingCourier(false);
    }
  };

  const handleProductSubmit = async () => {
    setIsDataLoading(true);
    const method = editingProduct ? "PATCH" : "POST";
    const url = editingProduct ? `/api/products/${editingProduct._id}` : "/api/products";

    // Ensure handle is set and clean options of MongoDB _id fields
    const finalData = {
      ...productFormData,
      options: productFormData.options?.map(opt => ({
        name: opt.name,
        values: opt.values
      })) || [],
      stock: productFormData.stock || 0,
      variantStock: productFormData.variantStock || {}
    };
    if (!finalData.handle) finalData.handle = finalData.title.toLowerCase().replace(/ /g, "-");
    // Remove _id from top level for new products
    if (!editingProduct) {
      delete (finalData as any)._id;
    }

    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(finalData)
      });

      if (response.ok) {
        toast.success(`Product ${editingProduct ? "updated" : "created"} successfully!`);
        setIsProductModalOpen(false);
        fetchAllProducts();
        fetchStats(true);
      } else {
        toast.error("Failed to save product");
      }
    } catch (error) {
      toast.error("Error saving product");
    } finally {
      setIsDataLoading(false);
    }
  };

  const deleteProduct = async (productId: string) => {
    if (!confirm("Delete this product permanently?")) return;
    setIsUpdating(productId);
    try {
      const response = await fetch(`/api/products/${productId}`, { method: "DELETE" });
      if (response.ok) {
        toast.success("Product deleted");
        fetchAllProducts();
        fetchStats(true);
      }
    } catch (error) {
      toast.error("Failed to delete product");
    } finally {
      setIsUpdating(null);
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    // Deep clone options and variantStock
    const cleanedProduct: Product = {
      ...product,
      stock: product.stock || 0,
      options: product.options?.map(opt => ({
        name: opt.name,
        values: [...opt.values]
      })) || [{ name: "Variant", values: [] }],
      variantStock: product.variantStock ? { ...product.variantStock } : {}
    };
    setProductFormData(cleanedProduct);
    setVariantInput("");
    setIsProductModalOpen(true);
  };

  const openAddProduct = () => {
    setEditingProduct(null);
    setProductFormData({
      handle: "",
      title: "",
      price: 0,
      compareAtPrice: 0,
      imageSrc: "",
      vendor: "Online lifestyle",
      category: "General",
      status: "active",
      stock: 0,
      options: [{ name: "Variant", values: [] }],
      variantStock: {}
    });
    setVariantInput("");
    setIsProductModalOpen(true);
  };

  const addVariantValue = () => {
    const trimmed = variantInput.trim();
    if (!trimmed) return;
    const currentOptions = productFormData.options || [];
    const currentOpt = currentOptions[0] || { name: "Variant", values: [] };

    if (currentOpt.values.includes(trimmed)) {
      toast.error("Variant already exists");
      return;
    }

    const newOptions = [{
      name: currentOpt.name,
      values: [...currentOpt.values, trimmed]
    }];
    const newVarStock = { ...(productFormData.variantStock || {}), [trimmed]: 0 };
    setProductFormData({ ...productFormData, options: newOptions, variantStock: newVarStock });
    setVariantInput("");
  };

  const removeVariantValue = (val: string) => {
    const currentOptions = productFormData.options || [];
    const currentOpt = currentOptions[0] || { name: "Variant", values: [] };

    const newOptions = [{
      name: currentOpt.name,
      values: currentOpt.values.filter(v => v !== val)
    }];
    const newVarStock = { ...(productFormData.variantStock || {}) };
    delete newVarStock[val];
    setProductFormData({ ...productFormData, options: newOptions, variantStock: newVarStock });
  };

  const updateVariantStock = (variant: string, stock: number) => {
    const newVarStock = { ...(productFormData.variantStock || {}), [variant]: stock };
    setProductFormData({ ...productFormData, variantStock: newVarStock });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-neutral-400" />
          <p className="text-xs text-neutral-400 font-medium tracking-wide">Loading data…</p>
        </div>
      </div>
    );
  }

  const filteredOrders = allOrders.filter(order => {
    const matchesSearch = (order.orderNumber || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (order.customerName || "").toLowerCase().includes(searchQuery.toLowerCase());

    let matchesDate = true;
    if ((startDate || endDate) && order.createdAt) {
      try {
        const orderDate = new Date(order.createdAt).toISOString().slice(0, 10);
        if (startDate && orderDate < startDate) matchesDate = false;
        if (endDate && orderDate > endDate) matchesDate = false;
      } catch (e) {
        matchesDate = true;
      }
    }

    return matchesSearch && matchesDate;
  });

  const filteredProducts = products.filter(p =>
    (p.title || "").toLowerCase().includes(searchQuery.toLowerCase())
  );

  const setQuickRange = (range: "today" | "yesterday" | "week" | "all") => {
    const now = new Date();
    const d = new Date();

    if (range === "today") {
      const dateStr = now.toISOString().slice(0, 10);
      setStartDate(dateStr);
      setEndDate(dateStr);
    } else if (range === "yesterday") {
      d.setDate(d.getDate() - 1);
      const dateStr = d.toISOString().slice(0, 10);
      setStartDate(dateStr);
      setEndDate(dateStr);
    } else if (range === "week") {
      d.setDate(d.getDate() - 7);
      setStartDate(d.toISOString().slice(0, 10));
      setEndDate(now.toISOString().slice(0, 10));
    } else {
      setStartDate("");
      setEndDate("");
    }
  };

  // ─── LOGIN GATE ────────────────────────────────────────────────────────
  if (!isAuthenticated) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="w-full max-w-sm"
        >
          <div className="text-center mb-10">
            <div className="mx-auto mb-6 h-14 w-14 rounded-2xl bg-neutral-900 flex items-center justify-center">
              <ShieldCheck className="h-7 w-7 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-neutral-900 tracking-tight">Welcome back</h1>
            <p className="text-sm text-neutral-400 mt-1">Enter your password to continue</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="relative">
              <input
                type="password"
                placeholder="Password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full h-13 px-4 bg-neutral-50 rounded-xl border border-neutral-200 text-sm font-medium focus:ring-2 focus:ring-neutral-900 focus:border-transparent outline-none transition-all placeholder:text-neutral-300"
                required
                autoFocus
              />
            </div>

            <button
              type="submit"
              disabled={isLoginLoading}
              className="w-full h-13 rounded-xl bg-neutral-900 text-white text-sm font-semibold hover:bg-neutral-800 active:scale-[0.98] transition-all disabled:opacity-40 flex items-center justify-center gap-2"
            >
              {isLoginLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>Sign in <ArrowRight className="h-4 w-4" /></>
              )}
            </button>
          </form>

          <p className="text-[11px] text-neutral-300 text-center mt-8 leading-relaxed">
            Protected admin area · All sessions encrypted
          </p>
        </motion.div>
      </div>
    );
  }

  // ─── MAIN DASHBOARD ────────────────────────────────────────────────────
  return (
    <div className="max-w-[1400px] mx-auto">
      {/* Top bar — minimal, functional */}
      <div className="flex items-center justify-between py-4 mb-2">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
          {[
            { key: "overview", label: "Overview", icon: <BarChart3 className="h-4 w-4" /> },
            { key: "history", label: "Orders", icon: <History className="h-4 w-4" /> },
            { key: "products", label: "Products", icon: <Package className="h-4 w-4" /> },
            { key: "coupons", label: "Coupons", icon: <Ticket className="h-4 w-4" /> },
            { key: "locations", label: "Zones", icon: <MapPin className="h-4 w-4" /> },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${activeTab === tab.key
                ? "bg-neutral-900 text-white shadow-sm"
                : "text-neutral-500 hover:text-neutral-900 hover:bg-neutral-50"
                }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 ml-4 shrink-0">
          {activeTab === "products" && (
            <>
              <button onClick={() => setIsCsvModalOpen(true)} className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium text-neutral-500 hover:text-neutral-900 hover:bg-neutral-50 transition-all border border-neutral-200">
                <Upload className="h-3.5 w-3.5" /> CSV
              </button>
              <button onClick={openAddProduct} className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium bg-neutral-900 text-white hover:bg-neutral-800 transition-all">
                <Plus className="h-3.5 w-3.5" /> Add
              </button>
            </>
          )}
          {activeTab === "coupons" && (
            <button onClick={openAddCoupon} className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium bg-neutral-900 text-white hover:bg-neutral-800 transition-all">
              <Plus className="h-3.5 w-3.5" /> New
            </button>
          )}
          <button onClick={() => fetchStats(false)} className="p-2 rounded-lg text-neutral-400 hover:text-neutral-900 hover:bg-neutral-50 transition-all">
            <RefreshCw className="h-4 w-4" />
          </button>
          <button onClick={handleLogout} className="p-2 rounded-lg text-neutral-300 hover:text-rose-500 hover:bg-rose-50 transition-all" title="Sign out">
            <Lock className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* ─── OVERVIEW TAB ──────────────────────────────── */}
      {activeTab === "overview" && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="space-y-6">
          {/* Date filter — unobtrusive */}
          <div className="flex flex-wrap items-center gap-2">
            {["today", "yesterday", "week"].map((r) => (
              <button key={r} onClick={() => setQuickRange(r as any)} className="px-3 py-1.5 rounded-lg text-xs font-medium text-neutral-400 hover:text-neutral-900 hover:bg-neutral-100 transition-all capitalize">
                {r === "week" ? "7 days" : r}
              </button>
            ))}
            <div className="flex items-center gap-2 ml-1">
              <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="h-8 px-2.5 bg-neutral-50 rounded-lg border border-neutral-200 text-xs font-medium text-neutral-600 focus:ring-1 focus:ring-neutral-300 outline-none w-[130px]" />
              <span className="text-neutral-300 text-xs">→</span>
              <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="h-8 px-2.5 bg-neutral-50 rounded-lg border border-neutral-200 text-xs font-medium text-neutral-600 focus:ring-1 focus:ring-neutral-300 outline-none w-[130px]" />
            </div>
            {(startDate || endDate) && (
              <button onClick={() => { setStartDate(""); setEndDate(""); }} className="text-xs text-rose-400 hover:text-rose-600 font-medium transition-colors ml-1">
                Clear
              </button>
            )}
          </div>

          {/* KPI row — large numbers, minimal labels */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard label="Revenue" value={`৳${(stats?.totalRevenue || 0).toLocaleString()}`} accent="text-emerald-600" icon={<TrendingUp className="h-4 w-4" />} />
            <KPICard label="Orders" value={stats?.totalOrders || 0} accent="text-sky-600" icon={<ShoppingBag className="h-4 w-4" />} />
            <KPICard label="Products" value={stats?.totalProducts || 0} accent="text-violet-600" icon={<Package className="h-4 w-4" />} />
            <KPICard label="Customers" value={stats?.uniqueCustomers || 0} accent="text-amber-600" icon={<Users className="h-4 w-4" />} />
          </div>

          {/* Recent orders — compact table */}
          <LWOrderTable
            title="Recent"
            count={stats?.recentOrders?.length || 0}
            orders={stats?.recentOrders || []}
            onStatusUpdate={updateOrderStatus}
            onEdit={handleEditOrderClick}
            onDelete={deleteOrder}
            onViewDetails={(order: any) => setSelectedOrder(order)}
            isUpdating={isUpdating}
          />
        </motion.div>
      )}

      {/* ─── HISTORY TAB ──────────────────────────────── */}
      {activeTab === "history" && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="space-y-4">
          <LWSearch value={searchQuery} onChange={setSearchQuery} placeholder="Search orders…" />
          <LWOrderTable
            title="All orders"
            count={filteredOrders.length}
            orders={filteredOrders}
            onStatusUpdate={updateOrderStatus}
            onEdit={handleEditOrderClick}
            onDelete={deleteOrder}
            onViewDetails={(order: any) => setSelectedOrder(order)}
            isUpdating={isUpdating}
            isLoading={isDataLoading}
          />
        </motion.div>
      )}

      {/* ─── PRODUCTS TAB ──────────────────────────────── */}
      {activeTab === "products" && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="space-y-4">
          <LWSearch value={searchQuery} onChange={setSearchQuery} placeholder="Search products…" />
          <LWProductGrid
            products={filteredProducts}
            onEdit={handleEditProduct}
            onDelete={deleteProduct}
            isUpdating={isUpdating}
            isLoading={isDataLoading}
          />
        </motion.div>
      )}

      {/* ─── COUPONS TAB ──────────────────────────────── */}
      {activeTab === "coupons" && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
          <LWCouponList
            coupons={coupons}
            onEdit={handleEditCoupon}
            onDelete={deleteCoupon}
            onToggle={toggleCouponActive}
            isUpdating={isUpdating}
            isLoading={isDataLoading}
          />
        </motion.div>
      )}

      {/* ─── ZONES TAB ──────────────────────────────── */}
      {activeTab === "locations" && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {locations.map((loc: any) => (
            <div key={loc.id || loc._id} className="bg-white rounded-xl border border-neutral-100 p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-base font-semibold text-neutral-900">{loc.name}</h3>
                  <p className="text-xs text-neutral-400 mt-0.5">Delivery Zone</p>
                </div>
                <div className="p-2 rounded-lg bg-neutral-50">
                  <MapPin className="h-4 w-4 text-neutral-400" />
                </div>
              </div>
              <div className="flex items-baseline justify-between pt-3 border-t border-neutral-50">
                <div>
                  <p className="text-2xl font-bold text-neutral-900 tabular-nums">{loc.orders}</p>
                  <p className="text-[11px] text-neutral-400 mt-0.5">total orders</p>
                </div>
                <span className="text-xs font-medium text-neutral-400 bg-neutral-50 px-2.5 py-1 rounded-md">{loc.status}</span>
              </div>
            </div>
          ))}
        </motion.div>
      )}

      {/* ─── MODALS ──────────────────────────────── */}

      {/* CSV Import */}
      <Dialog open={isCsvModalOpen} onOpenChange={setIsCsvModalOpen}>
        <DialogContent className="sm:max-w-[440px] rounded-2xl p-0 overflow-hidden border border-neutral-100">
          <div className="p-6 pb-0">
            <DialogTitle className="text-lg font-semibold text-neutral-900">Import CSV</DialogTitle>
            <DialogDescription className="text-sm text-neutral-400 mt-1">Upload a Shopify-format product CSV.</DialogDescription>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex flex-col items-center justify-center border border-dashed border-neutral-200 rounded-xl p-8 bg-neutral-50/50 relative group hover:border-neutral-300 transition-all cursor-pointer">
              <Upload className="h-8 w-8 text-neutral-300 mb-3" />
              <input type="file" accept=".csv" onChange={(e) => e.target.files && setCsvFile(e.target.files[0])} className="absolute inset-0 opacity-0 cursor-pointer" />
              <p className="text-sm font-medium text-neutral-600">{csvFile ? csvFile.name : "Select file"}</p>
              {!csvFile && <p className="text-xs text-neutral-300 mt-1">Click to browse</p>}
            </div>
            <div className="flex gap-3">
              <button onClick={() => setIsCsvModalOpen(false)} className="flex-1 h-11 rounded-xl text-sm font-medium text-neutral-500 bg-neutral-50 hover:bg-neutral-100 transition-all">Cancel</button>
              <button onClick={handleCsvUpload} disabled={!csvFile || isCsvUploading} className="flex-1 h-11 rounded-xl text-sm font-medium bg-neutral-900 text-white hover:bg-neutral-800 transition-all disabled:opacity-40 flex items-center justify-center">
                {isCsvUploading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Import"}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Coupon Modal */}
      <Dialog open={isCouponModalOpen} onOpenChange={setIsCouponModalOpen}>
        <DialogContent className="sm:max-w-[440px] rounded-2xl p-0 overflow-hidden border border-neutral-100">
          <div className="p-6 pb-0">
            <DialogTitle className="text-lg font-semibold text-neutral-900">{editingCoupon ? "Edit coupon" : "New coupon"}</DialogTitle>
            <DialogDescription className="text-sm text-neutral-400 mt-1">{editingCoupon ? "Update coupon details." : "Create a promo code."}</DialogDescription>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Code</label>
              <Input value={couponFormData.code} onChange={(e) => setCouponFormData({ ...couponFormData, code: e.target.value.toUpperCase() })} placeholder="e.g. SAVE20" className="h-11 rounded-xl bg-neutral-50 border-neutral-200 font-semibold uppercase tracking-wider" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Type</label>
                <div className="flex gap-2">
                  <button onClick={() => setCouponFormData({ ...couponFormData, type: "percentage" })} className={`flex-1 h-10 rounded-lg text-sm font-medium transition-all ${couponFormData.type === "percentage" ? "bg-neutral-900 text-white" : "bg-neutral-50 text-neutral-500 border border-neutral-200"}`}>%</button>
                  <button onClick={() => setCouponFormData({ ...couponFormData, type: "fixed" })} className={`flex-1 h-10 rounded-lg text-sm font-medium transition-all ${couponFormData.type === "fixed" ? "bg-neutral-900 text-white" : "bg-neutral-50 text-neutral-500 border border-neutral-200"}`}>৳</button>
                </div>
              </div>
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Value</label>
                <Input type="number" value={couponFormData.value} onChange={(e) => setCouponFormData({ ...couponFormData, value: Number(e.target.value) })} className="h-10 rounded-lg bg-neutral-50 border-neutral-200 font-semibold" />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Min. order (৳)</label>
              <Input type="number" value={couponFormData.minOrder} onChange={(e) => setCouponFormData({ ...couponFormData, minOrder: Number(e.target.value) })} placeholder="0" className="h-10 rounded-lg bg-neutral-50 border-neutral-200" />
            </div>
          </div>
          <div className="p-6 pt-0 flex gap-3">
            <button onClick={() => setIsCouponModalOpen(false)} className="flex-1 h-11 rounded-xl text-sm font-medium text-neutral-500 bg-neutral-50 hover:bg-neutral-100 transition-all">Cancel</button>
            <button onClick={handleCouponSubmit} disabled={isDataLoading || !couponFormData.code} className="flex-1 h-11 rounded-xl text-sm font-medium bg-neutral-900 text-white hover:bg-neutral-800 transition-all disabled:opacity-40 flex items-center justify-center">
              {isDataLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : (editingCoupon ? "Save" : "Create")}
            </button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Product Modal */}
      <Dialog open={isProductModalOpen} onOpenChange={setIsProductModalOpen}>
        <DialogContent className="sm:max-w-[640px] rounded-2xl p-0 overflow-hidden border border-neutral-100">
          <div className="p-6 pb-0">
            <DialogTitle className="text-lg font-semibold text-neutral-900">{editingProduct ? "Edit product" : "New product"}</DialogTitle>
            <DialogDescription className="text-sm text-neutral-400 mt-1">Define title, price, variants, and stock.</DialogDescription>
          </div>
          <div className="p-6 space-y-5 max-h-[65vh] overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Title</label>
                  <Input value={productFormData.title} onChange={(e) => setProductFormData({ ...productFormData, title: e.target.value })} placeholder="Product name" className="h-11 rounded-xl bg-neutral-50 border-neutral-200 font-medium" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Price</label>
                    <Input type="number" value={productFormData.price} onChange={(e) => setProductFormData({ ...productFormData, price: Number(e.target.value) })} className="h-11 rounded-xl bg-neutral-50 border-neutral-200 font-semibold" />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Compare at</label>
                    <Input type="number" value={productFormData.compareAtPrice} onChange={(e) => setProductFormData({ ...productFormData, compareAtPrice: Number(e.target.value) })} className="h-11 rounded-xl bg-neutral-50 border-neutral-200 text-neutral-400" />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Image URL</label>
                  <Input value={productFormData.imageSrc} onChange={(e) => setProductFormData({ ...productFormData, imageSrc: e.target.value })} placeholder="https://…" className="h-11 rounded-xl bg-neutral-50 border-neutral-200" />
                </div>
                <div>
                  <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Total Stock</label>
                  <Input type="number" value={productFormData.stock ?? 0} onChange={(e) => setProductFormData({ ...productFormData, stock: Number(e.target.value) })} className="h-11 rounded-xl bg-neutral-50 border-neutral-200 font-semibold text-emerald-600" />
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Variant name</label>
                  <Input value={productFormData.options?.[0]?.name || "Variant"} onChange={(e) => { const currentOpt = productFormData.options?.[0] || { name: "", values: [] }; setProductFormData({ ...productFormData, options: [{ name: e.target.value, values: [...currentOpt.values] }] }); }} placeholder="e.g. Size, Color" className="h-11 rounded-xl bg-neutral-50 border-neutral-200 font-medium" />
                </div>
                <div>
                  <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Variant values</label>
                  <div className="flex flex-wrap gap-1.5 mb-2 min-h-[40px] p-2.5 rounded-xl border border-dashed border-neutral-200 bg-neutral-50/50">
                    {productFormData.options?.[0]?.values.map(val => (
                      <span key={val} className="inline-flex items-center gap-1 px-2.5 py-1 bg-white text-neutral-700 border border-neutral-100 rounded-lg text-xs font-medium">
                        {val}
                        <button type="button" onClick={() => removeVariantValue(val)} className="hover:text-rose-500 transition-colors"><X className="h-3 w-3" /></button>
                      </span>
                    ))}
                    {(!productFormData.options?.[0]?.values || productFormData.options[0].values.length === 0) && (
                      <span className="text-xs text-neutral-300 italic flex items-center">No variants yet</span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Input value={variantInput} onChange={(e) => setVariantInput(e.target.value)} placeholder="Type variant…" onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); addVariantValue(); } }} className="h-10 rounded-xl bg-white border-neutral-200 flex-1" />
                    <button type="button" onClick={addVariantValue} disabled={!variantInput.trim()} className="h-10 px-3 rounded-xl bg-neutral-900 text-white text-xs font-medium disabled:opacity-30 hover:bg-neutral-800 transition-all flex items-center gap-1"><Plus className="h-3.5 w-3.5" /> Add</button>
                  </div>
                </div>
                {productFormData.options?.[0]?.values && productFormData.options[0].values.length > 0 && (
                  <div>
                    <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Stock per variant</label>
                    <div className="space-y-1.5">
                      {productFormData.options[0].values.map(val => (
                        <div key={val} className="flex items-center justify-between gap-3 bg-neutral-50 p-2.5 rounded-lg">
                          <span className="text-sm font-medium text-neutral-700 truncate flex-1">{val}</span>
                          <Input type="number" value={productFormData.variantStock?.[val] ?? 0} onChange={(e) => updateVariantStock(val, Number(e.target.value))} className="w-20 h-8 rounded-lg text-center font-semibold text-emerald-600 bg-white border-neutral-200 text-xs" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className="p-6 pt-0 flex gap-3">
            <button onClick={() => setIsProductModalOpen(false)} className="flex-1 h-11 rounded-xl text-sm font-medium text-neutral-500 bg-neutral-50 hover:bg-neutral-100 transition-all">Cancel</button>
            <button onClick={handleProductSubmit} disabled={isDataLoading} className="flex-1 h-11 rounded-xl text-sm font-medium bg-neutral-900 text-white hover:bg-neutral-800 transition-all disabled:opacity-40 flex items-center justify-center">
              {isDataLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : (editingProduct ? "Save" : "Publish")}
            </button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Order Detail Modal — progressive disclosure */}
      <Dialog open={!!selectedOrder} onOpenChange={(open) => !open && setSelectedOrder(null)}>
        <DialogContent className="sm:max-w-[560px] rounded-2xl p-0 overflow-hidden border border-neutral-100">
          {/* Header — essential info first */}
          <div className="p-6 pb-4 border-b border-neutral-50">
            <div className="flex items-start justify-between">
              <div>
                <DialogTitle className="text-lg font-semibold text-neutral-900 tabular-nums">{selectedOrder?.orderNumber}</DialogTitle>
                <p className="text-xs text-neutral-400 mt-0.5">{selectedOrder ? new Date(selectedOrder.createdAt).toLocaleString() : ""}</p>
              </div>
              <div className="flex items-center gap-1.5">
                <span className={`h-2 w-2 rounded-full ${STATUS_DOT[selectedOrder?.status] || "bg-neutral-300"}`} />
                <span className="text-sm font-medium text-neutral-700">{selectedOrder?.status}</span>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-5 max-h-[65vh] overflow-y-auto">
            {/* Customer + Reliability — the most important context */}
            <div className="flex gap-4">
              <div className="flex-1 space-y-1">
                <p className="text-xs text-neutral-400 font-medium">Customer</p>
                <p className="text-sm font-semibold text-neutral-900">{selectedOrder?.customerName}</p>
                <p className="text-xs text-neutral-400">{selectedOrder?.customerPhone}</p>
                {selectedOrder?.customerEmail && <p className="text-xs text-neutral-400">{selectedOrder?.customerEmail}</p>}
              </div>

              {/* Reliability score — a single, glanceable number */}
              {isHistoryLoading ? (
                <div className="flex items-center justify-center w-20"><Loader2 className="h-4 w-4 animate-spin text-neutral-300" /></div>
              ) : customerHistory ? (
                <div className="text-right shrink-0">
                  <p className="text-xs text-neutral-400 font-medium mb-1">Reliability</p>
                  <p className={`text-3xl font-bold tabular-nums ${customerHistory.reliability >= 80 ? "text-emerald-600" :
                    customerHistory.reliability >= 50 ? "text-amber-500" : "text-rose-500"
                    }`}>{customerHistory.reliability}<span className="text-lg">%</span></p>
                  <p className="text-[11px] text-neutral-300 mt-0.5 tabular-nums">{customerHistory.globalStats?.totalOrders || customerHistory.stats.totalOrders} orders</p>
                </div>
              ) : null}
            </div>

            {/* Global stats row + FraudBD — revealed only when data exists */}
            {customerHistory && (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-neutral-50 rounded-lg py-2.5">
                    <p className="text-lg font-bold text-neutral-900 tabular-nums">{customerHistory.globalStats?.totalOrders || customerHistory.stats.totalOrders}</p>
                    <p className="text-[10px] text-neutral-400 font-medium">Total</p>
                  </div>
                  <div className="bg-emerald-50/50 rounded-lg py-2.5">
                    <p className="text-lg font-bold text-emerald-600 tabular-nums">{customerHistory.globalStats?.delivered ?? customerHistory.stats.delivered}</p>
                    <p className="text-[10px] text-neutral-400 font-medium">Delivered</p>
                  </div>
                  <div className="bg-rose-50/50 rounded-lg py-2.5">
                    <p className="text-lg font-bold text-rose-500 tabular-nums">{customerHistory.globalStats?.failed ?? (customerHistory.stats.returned + customerHistory.stats.cancelled)}</p>
                    <p className="text-[10px] text-neutral-400 font-medium">Failed</p>
                  </div>
                </div>

                {/* FraudBD network — secondary detail, progressively disclosed */}
                {customerHistory.network && customerHistory.network.totalSummary && (
                  <div className="bg-neutral-50 rounded-xl p-3 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Globe className="h-3.5 w-3.5 text-neutral-400" />
                        <span className="text-xs font-medium text-neutral-500">FraudBD Network</span>
                      </div>
                      <span className={`text-xs font-semibold tabular-nums ${customerHistory.network.totalSummary.successRate >= 80 ? "text-emerald-600" :
                        customerHistory.network.totalSummary.successRate >= 50 ? "text-amber-600" : "text-rose-600"
                        }`}>{customerHistory.network.totalSummary.successRate}% success</span>
                    </div>
                    <div className="space-y-1">
                      {Object.entries(customerHistory.network.Summaries || {}).map(([name, data]: any) => (
                        <div key={name} className="flex items-center justify-between py-1.5">
                          <span className="text-xs font-medium text-neutral-600">{name}</span>
                          {data.data_type === "rating" ? (
                            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${data.risk_level === "high" || data.risk_level === "very_high" ? "bg-rose-100 text-rose-700" :
                              data.risk_level === "low" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"
                              }`}>{data.customer_rating?.replace(/_/g, " ")}</span>
                          ) : (
                            <span className="text-xs tabular-nums text-neutral-500 font-medium">
                              <span className="text-emerald-600">{data.success}</span>/{data.total}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Delivery */}
            <div>
              <p className="text-xs text-neutral-400 font-medium mb-1">Delivery</p>
              <p className="text-sm font-medium text-neutral-900">{selectedOrder?.location || "General Area"}</p>
              <p className="text-xs text-neutral-500 mt-0.5">{selectedOrder?.address}</p>
            </div>

            {/* Courier tracking logic */}
            {selectedOrder?.trackingCode ? (
              <div className="bg-sky-50/60 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1.5">
                    <Truck className="h-3.5 w-3.5 text-sky-600" />
                    <span className="text-xs font-semibold text-sky-700">Courier Logistics</span>
                  </div>
                  {selectedOrder.status === "In Review" && (
                    <div className="flex items-center gap-1.5 bg-sky-100/50 px-2 py-1 rounded-md">
                      <div className="h-1.5 w-1.5 bg-sky-500 rounded-full animate-ping" />
                      <span className="text-[9px] font-black uppercase tracking-widest text-sky-600">Verification Active</span>
                    </div>
                  )}
                </div>

                {selectedOrder.status === "In Review" && (
                  <p className="text-[10px] text-sky-600/70 font-medium mb-3 pl-1 italic">
                    {INTERNAL_STATUS_DESCRIPTIONS["In Review"]}
                  </p>
                )}

                <div className="flex items-center justify-between mb-3">
                  <div className="text-[10px] font-black uppercase tracking-widest text-sky-400">Real-time Status</div>
                  <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all shadow-sm ${isSteadfastLoading
                      ? "bg-slate-50 text-slate-400 border-slate-100"
                      : (STEADFAST_STATUS_THEMES[Object.keys(STEADFAST_STATUS_MAP).find(k => STEADFAST_STATUS_MAP[k] === steadfastStatus) || ""] || "bg-sky-50 text-sky-700 border-sky-100")
                    }`}>
                    {isSteadfastLoading && <Loader2 className="h-3 w-3 animate-spin" />}
                    <span className="text-[10px] font-black uppercase tracking-widest whitespace-nowrap">
                      {isSteadfastLoading ? "Syncing..." : (steadfastStatus || "UNKNOWN")}
                    </span>
                    {!isSteadfastLoading && (
                      <button
                        onClick={() => fetchSteadfastStatus(selectedOrder._id)}
                        className="ml-1 hover:scale-110 active:scale-95 transition-transform opacity-60 hover:opacity-100"
                        title="Force status refresh"
                      >
                        <RefreshCw className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-white/50 p-4 rounded-xl border border-sky-100/50">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 opacity-60">
                      <History className="h-3 w-3 text-sky-400" />
                      <p className="text-[10px] text-sky-500 font-black uppercase tracking-wider">Tracking Code</p>
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <p className="text-sm font-black text-sky-900 tabular-nums break-all">{selectedOrder.trackingCode}</p>
                      <a
                        href={`https://steadfast.com.bd/t/${selectedOrder.trackingCode}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 text-[10px] text-sky-600 font-bold hover:text-sky-800 transition-colors group/link"
                      >
                        Visit Tracking Portal <ArrowUpRight className="h-3 w-3 transition-transform group-hover/link:-translate-y-0.5 group-hover/link:translate-x-0.5" />
                      </a>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 opacity-60">
                      <Package className="h-3 w-3 text-sky-400" />
                      <p className="text-[10px] text-sky-500 font-black uppercase tracking-wider">Consignment ID</p>
                    </div>
                    <p className="text-sm font-black text-sky-900 tabular-nums">{selectedOrder.consignmentId}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-sky-50/50 border border-sky-100 rounded-2xl p-4 flex items-center justify-between group/courier">
                <div className="flex items-center gap-3">
                  <div className="bg-white p-2 rounded-xl border border-sky-100 shadow-sm transition-transform group-hover/courier:scale-110">
                    <Truck className="h-4 w-4 text-sky-600" />
                  </div>
                  <div>
                    <p className="text-[10px] text-sky-400 font-bold uppercase tracking-wider leading-none mb-1">Logistics Status</p>
                    <p className="text-sm font-bold text-sky-800 leading-none">Awaiting Dispatch</p>
                  </div>
                </div>
                <button
                  onClick={handlePushToCourier}
                  disabled={isPushingCourier}
                  className="relative group/btn flex items-center gap-2 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest bg-neutral-900 text-white hover:bg-sky-600 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-sky-200 active:scale-95 disabled:opacity-40 disabled:pointer-events-none overflow-hidden"
                >
                  <div className="absolute inset-x-0 bottom-0 h-1 bg-white/20 scale-x-0 group-hover/btn:scale-x-100 transition-transform origin-left" />
                  {isPushingCourier ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <>
                      <span>Ship Order</span>
                      <ArrowUpRight className="h-3 w-3 transition-transform group-hover/btn:-translate-y-0.5 group-hover/btn:translate-x-0.5" />
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Line items — compact list */}
            <div>
              <p className="text-xs text-neutral-400 font-medium mb-2">Items · {(selectedOrder?.items || []).length}</p>
              <div className="space-y-1.5">
                {(selectedOrder?.items || []).map((item: any) => (
                  <div key={item._id} className="flex items-center justify-between py-2 px-3 rounded-lg bg-neutral-50/80">
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-bold text-neutral-400 tabular-nums w-6">{item.quantity}×</span>
                      <div>
                        <p className="text-sm font-medium text-neutral-900 line-clamp-1">{item.title}</p>
                        {item.variant && <span className="text-[10px] text-neutral-400">{item.variant}</span>}
                      </div>
                    </div>
                    <span className="text-sm font-semibold text-neutral-900 tabular-nums">৳{(item.price * item.quantity).toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Totals */}
            <div className="bg-neutral-50 rounded-xl p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-neutral-500">Subtotal</span>
                <span className="font-medium text-neutral-700 tabular-nums">৳{((selectedOrder?.items || []).reduce((sum: number, item: any) => sum + (item.price * item.quantity), 0)).toLocaleString()}</span>
              </div>
              {selectedOrder?.discountAmount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-emerald-600 flex items-center gap-1"><Ticket className="h-3 w-3" /> Discount {selectedOrder.couponCode ? `(${selectedOrder.couponCode})` : ""}</span>
                  <span className="font-medium text-emerald-600 tabular-nums">−৳{(selectedOrder?.discountAmount || 0).toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-neutral-500">Delivery {selectedOrder?.deliveryZone ? `(${selectedOrder.deliveryZone.replace("_", " ")})` : ""}</span>
                <span className="font-medium text-neutral-700 tabular-nums">৳{(selectedOrder?.deliveryCharge || 0).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-base pt-2 border-t border-neutral-100">
                <span className="font-semibold text-neutral-900">Total</span>
                <span className="font-bold text-neutral-900 tabular-nums">৳{(selectedOrder?.totalAmount || 0).toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Footer actions */}
          <div className="p-5 border-t border-neutral-100 flex gap-4 bg-neutral-50/30">
            <button
              onClick={() => setSelectedOrder(null)}
              className="flex-1 h-11 rounded-xl text-[11px] font-black uppercase tracking-widest text-neutral-400 bg-white border border-neutral-100 hover:text-neutral-900 hover:bg-neutral-50 hover:border-neutral-200 transition-all active:scale-95"
            >
              Close Panel
            </button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex-[1.5] h-11 px-6 rounded-xl text-[10px] font-black uppercase tracking-widest bg-neutral-900 text-white hover:bg-indigo-600 hover:shadow-xl hover:shadow-indigo-200 transition-all duration-300 flex items-center justify-center gap-2 active:scale-95 shadow-lg shadow-neutral-200">
                  Update Order Status <ChevronDown className="h-3.5 w-3.5 transition-transform group-data-[state=open]:rotate-180" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="rounded-2xl p-2 border border-neutral-100 shadow-2xl w-52 bg-white/95 backdrop-blur-md">
                <div className="px-3 py-2 mb-1">
                  <p className="text-[10px] font-bold text-neutral-400 uppercase tracking-tighter">Transition To</p>
                </div>
                <DropdownMenuItem onClick={() => updateOrderStatus(selectedOrder._id, "Pending")} className="rounded-xl px-3 py-2.5 text-xs font-medium hover:bg-neutral-50 cursor-pointer transition-colors">Pending Review</DropdownMenuItem>
                <DropdownMenuItem onClick={() => updateOrderStatus(selectedOrder._id, "Shipped")} className="rounded-xl px-3 py-2.5 text-xs font-medium hover:bg-neutral-50 cursor-pointer transition-colors">Shipped / Dispatched</DropdownMenuItem>
                <DropdownMenuItem onClick={() => updateOrderStatus(selectedOrder._id, "Delivered")} className="rounded-xl px-3 py-2.5 text-xs font-bold text-emerald-600 hover:bg-emerald-50 cursor-pointer transition-colors flex items-center justify-between">
                  Mark Delivered <span className="h-2 w-2 bg-emerald-500 rounded-full" />
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-neutral-100 my-1" />
                <DropdownMenuItem onClick={() => updateOrderStatus(selectedOrder._id, "Returned")} className="rounded-xl px-3 py-2.5 text-xs font-medium text-amber-600 hover:bg-amber-50 cursor-pointer transition-colors">Return Received</DropdownMenuItem>
                <DropdownMenuItem onClick={() => updateOrderStatus(selectedOrder._id, "Cancelled")} className="rounded-xl px-3 py-2.5 text-xs font-medium text-rose-600 hover:bg-rose-50 cursor-pointer transition-colors">Cancel Transaction</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Order Modal */}
      <Dialog open={!!editingOrder} onOpenChange={(open) => !open && setEditingOrder(null)}>
        <DialogContent className="sm:max-w-[440px] rounded-2xl p-0 overflow-hidden border border-neutral-100">
          <div className="p-6 pb-0">
            <DialogTitle className="text-lg font-semibold text-neutral-900">Edit order</DialogTitle>
            <DialogDescription className="text-sm text-neutral-400 mt-1">Update details for {editingOrder?.orderNumber}</DialogDescription>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Name</label>
              <Input value={editFormData.customerName} onChange={(e) => setEditFormData({ ...editFormData, customerName: e.target.value })} className="h-11 rounded-xl bg-neutral-50 border-neutral-200 font-medium" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Email</label>
                <Input value={editFormData.customerEmail} onChange={(e) => setEditFormData({ ...editFormData, customerEmail: e.target.value })} className="h-10 rounded-lg bg-neutral-50 border-neutral-200" />
              </div>
              <div>
                <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Phone</label>
                <Input value={editFormData.customerPhone} onChange={(e) => setEditFormData({ ...editFormData, customerPhone: e.target.value })} className="h-10 rounded-lg bg-neutral-50 border-neutral-200" />
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Address</label>
              <Input value={editFormData.address} onChange={(e) => setEditFormData({ ...editFormData, address: e.target.value })} className="h-11 rounded-xl bg-neutral-50 border-neutral-200 font-medium" />
            </div>
            <div>
              <label className="text-xs font-medium text-neutral-500 mb-1.5 block">Delivery zone</label>
              <div className="grid grid-cols-2 gap-2">
                <button type="button" onClick={() => setEditFormData({ ...editFormData, deliveryZone: "inside_dhaka", deliveryCharge: 80 })} className={`p-3 rounded-xl border transition-all text-left ${editFormData.deliveryZone === "inside_dhaka" ? "border-neutral-900 bg-neutral-50" : "border-neutral-200 hover:border-neutral-300"}`}>
                  <p className="text-sm font-semibold text-neutral-900">Inside Dhaka</p>
                  <p className="text-xs text-neutral-400 mt-0.5">৳80</p>
                </button>
                <button type="button" onClick={() => setEditFormData({ ...editFormData, deliveryZone: "outside_dhaka", deliveryCharge: 120 })} className={`p-3 rounded-xl border transition-all text-left ${editFormData.deliveryZone === "outside_dhaka" ? "border-neutral-900 bg-neutral-50" : "border-neutral-200 hover:border-neutral-300"}`}>
                  <p className="text-sm font-semibold text-neutral-900">Outside Dhaka</p>
                  <p className="text-xs text-neutral-400 mt-0.5">৳120</p>
                </button>
              </div>
            </div>
          </div>
          <div className="p-6 pt-0 flex gap-3">
            <button onClick={() => setEditingOrder(null)} className="flex-1 h-11 rounded-xl text-sm font-medium text-neutral-500 bg-neutral-50 hover:bg-neutral-100 transition-all">Cancel</button>
            <button onClick={saveOrderEdit} disabled={!!isUpdating} className="flex-1 h-11 rounded-xl text-sm font-medium bg-neutral-900 text-white hover:bg-neutral-800 transition-all disabled:opacity-40">Save</button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Sub-components: LW-style ─────────────────────────────────────────────

function KPICard({ label, value, accent, icon }: any) {
  return (
    <div className="bg-white rounded-xl border border-neutral-100 p-5 hover:shadow-sm transition-shadow group">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs text-neutral-400 font-medium">{label}</p>
        <div className={`${accent} opacity-40 group-hover:opacity-100 transition-opacity`}>{icon}</div>
      </div>
      <p className={`text-2xl font-bold text-neutral-900 tabular-nums tracking-tight`}>{value}</p>
    </div>
  );
}

function LWSearch({ value, onChange, placeholder }: any) {
  return (
    <div className="relative">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-300" />
      <input
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-11 pl-10 pr-4 bg-white rounded-xl border border-neutral-200 text-sm font-medium focus:ring-2 focus:ring-neutral-200 focus:border-transparent outline-none transition-all placeholder:text-neutral-300"
      />
    </div>
  );
}

function LWOrderTable({ title, count, orders, onStatusUpdate, onEdit, onDelete, onViewDetails, isUpdating, isLoading }: any) {
  return (
    <div className="bg-white rounded-xl border border-neutral-100 overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-50">
        <h2 className="text-sm font-semibold text-neutral-900">{title}</h2>
        <span className="text-xs text-neutral-400 font-medium tabular-nums">{count}</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-neutral-50">
              <th className="text-left text-[11px] text-neutral-400 font-medium px-5 py-3">Order</th>
              <th className="text-left text-[11px] text-neutral-400 font-medium px-5 py-3">Customer</th>
              <th className="text-left text-[11px] text-neutral-400 font-medium px-5 py-3">Amount</th>
              <th className="text-left text-[11px] text-neutral-400 font-medium px-5 py-3">Status</th>
              <th className="text-right text-[11px] text-neutral-400 font-medium px-5 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={5} className="text-center py-16"><Loader2 className="h-6 w-6 animate-spin text-neutral-300 mx-auto" /></td></tr>
            ) : orders.length === 0 ? (
              <tr><td colSpan={5} className="text-center py-16 text-sm text-neutral-400">No orders found.</td></tr>
            ) : orders.map((order: any) => (
              <tr key={order._id} className="border-b border-neutral-50 last:border-0 hover:bg-neutral-50/50 transition-colors group">
                <td className="px-5 py-3.5">
                  <button onClick={() => onViewDetails(order)} className="text-sm font-semibold text-neutral-900 tabular-nums hover:text-sky-600 transition-colors">{order.orderNumber}</button>
                  <p className="text-[11px] text-neutral-400 mt-0.5">{new Date(order.createdAt).toLocaleDateString()}</p>
                </td>
                <td className="px-5 py-3.5">
                  <p className="text-sm font-medium text-neutral-800">{order.customerName}</p>
                  <p className="text-[11px] text-neutral-400 mt-0.5">{order.location || "—"}</p>
                </td>
                <td className="px-5 py-3.5 font-semibold text-neutral-900 tabular-nums">৳{(order.totalAmount || 0).toLocaleString()}</td>
                <td className="px-5 py-3.5">
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium ${STATUS_COLORS[order.status] || ""}`}>
                    <span className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[order.status] || "bg-neutral-300"}`} />
                    {order.status}
                  </span>
                </td>
                <td className="px-5 py-3.5 text-right">
                  <div className="flex items-center justify-end gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => onViewDetails(order)} className="p-1.5 rounded-md hover:bg-neutral-100 transition-colors text-neutral-400 hover:text-neutral-700"><Eye className="h-3.5 w-3.5" /></button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button disabled={isUpdating === order._id} className="p-1.5 rounded-md hover:bg-neutral-100 transition-colors text-neutral-400 hover:text-neutral-700"><MoreVertical className="h-3.5 w-3.5" /></button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48 rounded-xl p-1.5 border border-neutral-100 shadow-lg">
                        <DropdownMenuItem onClick={() => onEdit(order)} className="rounded-lg px-3 py-2 text-sm">Edit info</DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-neutral-100 mx-1" />
                        <DropdownMenuItem onClick={() => onStatusUpdate(order._id, "Shipped")} className="rounded-lg px-3 py-2 text-sm">Mark shipped</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onStatusUpdate(order._id, "Delivered")} className="rounded-lg px-3 py-2 text-sm text-emerald-600">Mark delivered</DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-neutral-100 mx-1" />
                        <DropdownMenuItem onClick={() => onDelete(order._id)} className="rounded-lg px-3 py-2 text-sm text-rose-500">Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function LWProductGrid({ products, onEdit, onDelete, isUpdating, isLoading }: any) {
  const stockLabel = (s: number) => s <= 0 ? "Out of stock" : s <= 5 ? `Low: ${s}` : `${s} in stock`;
  const stockColor = (s: number) => s <= 0 ? "text-rose-500" : s <= 5 ? "text-amber-600" : "text-emerald-600";

  return (
    <div className="bg-white rounded-xl border border-neutral-100 overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-50">
        <h2 className="text-sm font-semibold text-neutral-900">Products</h2>
        <span className="text-xs text-neutral-400 font-medium tabular-nums">{products.length}</span>
      </div>
      <div className="p-4">
        {isLoading ? (
          <div className="py-16 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-neutral-300" /></div>
        ) : products.length === 0 ? (
          <div className="py-16 text-center text-sm text-neutral-400">No products found.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {products.map((product: Product) => {
              const totalStock = product.stock || 0;
              const variantStock = product.variantStock || {};
              const hasVariants = product.options?.[0]?.values && product.options[0].values.length > 0;

              return (
                <div key={product._id} className="group rounded-xl border border-neutral-100 overflow-hidden hover:shadow-md transition-all">
                  <div className="relative aspect-square overflow-hidden bg-neutral-50">
                    <img src={product.imageSrc} alt={product.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-4 space-y-2">
                    <div>
                      <p className="text-[10px] text-neutral-400 font-medium">{product.vendor}</p>
                      <h4 className="text-sm font-semibold text-neutral-900 line-clamp-1 mt-0.5">{product.title}</h4>
                    </div>
                    <div className="flex items-baseline justify-between">
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-base font-bold text-neutral-900 tabular-nums">৳{(product.price || 0).toLocaleString()}</span>
                        {product.compareAtPrice ? <span className="text-xs text-neutral-300 line-through tabular-nums">৳{product.compareAtPrice.toLocaleString()}</span> : null}
                      </div>
                      <span className={`text-[10px] font-medium ${stockColor(totalStock)}`}>{stockLabel(totalStock)}</span>
                    </div>

                    {hasVariants && (
                      <div className="flex flex-wrap gap-1">
                        {product.options![0].values.map((v: string) => {
                          const vStock = (variantStock as any)[v] ?? 0;
                          return (
                            <span key={v} className={`px-2 py-0.5 rounded text-[10px] font-medium ${vStock > 0 ? "bg-neutral-50 text-neutral-600" : "bg-rose-50 text-rose-400"}`}>{v} ({vStock})</span>
                          );
                        })}
                      </div>
                    )}

                    <div className="flex gap-2 pt-1">
                      <button onClick={() => onEdit(product)} className="flex-1 h-8 rounded-lg text-xs font-medium text-neutral-500 border border-neutral-200 hover:border-neutral-900 hover:text-neutral-900 transition-all">Edit</button>
                      <button onClick={() => onDelete(product._id)} className="h-8 w-8 rounded-lg text-neutral-300 hover:text-rose-500 hover:bg-rose-50 transition-all flex items-center justify-center"><Trash2 className="h-3.5 w-3.5" /></button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function LWCouponList({ coupons, onEdit, onDelete, onToggle, isUpdating, isLoading }: any) {
  return (
    <div className="bg-white rounded-xl border border-neutral-100 overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-50">
        <h2 className="text-sm font-semibold text-neutral-900">Coupons</h2>
        <span className="text-xs text-neutral-400 font-medium tabular-nums">{coupons.length}</span>
      </div>
      {isLoading ? (
        <div className="py-16 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-neutral-300" /></div>
      ) : coupons.length === 0 ? (
        <div className="py-16 text-center text-sm text-neutral-400">No coupons yet.</div>
      ) : (
        <div className="divide-y divide-neutral-50">
          {coupons.map((coupon: CouponItem) => (
            <div key={coupon._id} className="flex items-center justify-between px-5 py-4 hover:bg-neutral-50/50 transition-colors group">
              <div className="flex items-center gap-4">
                <div className={`h-2 w-2 rounded-full shrink-0 ${coupon.active ? "bg-emerald-400" : "bg-neutral-300"}`} />
                <div>
                  <p className="text-sm font-semibold text-neutral-900 tracking-wider">{coupon.code}</p>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {coupon.type === "percentage" ? `${coupon.value}% off` : `৳${coupon.value} off`}
                    {coupon.minOrder > 0 && ` · min ৳${coupon.minOrder.toLocaleString()}`}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => onToggle(coupon)} className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${coupon.active ? "text-amber-600 hover:bg-amber-50" : "text-emerald-600 hover:bg-emerald-50"}`}>{coupon.active ? "Disable" : "Enable"}</button>
                <button onClick={() => onEdit(coupon)} className="p-1.5 rounded-md text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-all"><Edit3 className="h-3.5 w-3.5" /></button>
                <button onClick={() => onDelete(coupon._id)} className="p-1.5 rounded-md text-neutral-300 hover:text-rose-500 hover:bg-rose-50 transition-all"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CalendarIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 2v4" /><path d="M16 2v4" /><rect width="18" height="18" x="3" y="4" rx="2" /><path d="M3 10h18" />
    </svg>
  );
}
