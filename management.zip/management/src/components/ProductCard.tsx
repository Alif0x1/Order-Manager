import { useState } from "react";
import { ShoppingBag } from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";

interface Product {
  _id: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  category: string;
  vendor: string;
  stock?: number;
  options?: Array<{ name: string; values: string[] }>;
  variantStock?: Record<string, number>;
}

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, variant?: string) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const hasVariants = product.options && 
    product.options.length > 0 && 
    product.options[0].values && 
    product.options[0].values.length > 0;

  const [selectedVariant, setSelectedVariant] = useState<string>(
    hasVariants ? product.options![0].values[0] : ""
  );
  const [isAdding, setIsAdding] = useState(false);

  const discount = product.compareAtPrice 
    ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
    : 0;

  // Stock check: product-level OR variant-level
  const isOutOfStock = (() => {
    // If product has variants, check selected variant stock
    if (hasVariants && selectedVariant) {
      const vStock = product.variantStock?.[selectedVariant] ?? 0;
      return vStock <= 0;
    }
    // Otherwise check total product stock
    if (product.stock !== undefined) {
      return product.stock <= 0;
    }
    return false;
  })();

  const handleAdd = () => {
    if (isOutOfStock) return;
    setIsAdding(true);
    onAddToCart(product, selectedVariant || undefined);
    setTimeout(() => setIsAdding(false), 600);
  };

  return (
    <div className={`group rounded-xl border overflow-hidden bg-white transition-all duration-300 ${isOutOfStock ? "border-neutral-100 opacity-75" : "border-neutral-100 hover:shadow-md"}`}>
      <div className="relative aspect-square overflow-hidden bg-neutral-50">
        <img
          src={product.imageSrc}
          alt={product.title}
          className={`object-cover w-full h-full transition-transform duration-500 ${isOutOfStock ? "" : "group-hover:scale-105"}`}
          referrerPolicy="no-referrer"
        />
        {isOutOfStock && (
          <div className="absolute inset-0 bg-white/40" />
        )}
        {discount > 0 && !isOutOfStock && (
          <span className="absolute top-3 left-3 bg-neutral-900 text-white text-[10px] font-semibold px-2 py-1 rounded-md">
            −{discount}%
          </span>
        )}
      </div>

      <div className="p-4 space-y-3">
        <div>
          <p className="text-[10px] text-neutral-400 font-medium">{product.vendor}</p>
          <h3 className="text-sm font-semibold text-neutral-900 line-clamp-1 mt-0.5">{product.title}</h3>
        </div>

        <div className="flex items-baseline gap-2">
          <span className="text-base font-bold text-neutral-900 tabular-nums">৳{product.price.toLocaleString()}</span>
          {product.compareAtPrice && (
            <span className="text-xs text-neutral-300 line-through tabular-nums">৳{product.compareAtPrice.toLocaleString()}</span>
          )}
        </div>

        {hasVariants && (
          <div>
            <p className="text-[10px] text-neutral-400 font-medium mb-1.5">
              {product.options![0].name}
            </p>
            <Select value={selectedVariant} onValueChange={setSelectedVariant}>
              <SelectTrigger className="h-9 text-xs border-neutral-200 rounded-lg bg-neutral-50 font-medium">
                <SelectValue placeholder={`Select ${product.options![0].name}`} />
              </SelectTrigger>
              <SelectContent className="rounded-xl border-neutral-100 shadow-lg">
                {product.options![0].values.map((val) => {
                  const vStock = product.variantStock?.[val] ?? 0;
                  return (
                    <SelectItem key={val} value={val} className="text-xs rounded-lg font-medium">
                      {val} {vStock > 0 ? `(${vStock})` : "(Out)"}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
        )}

        <button 
          onClick={handleAdd}
          disabled={isAdding || isOutOfStock}
          className={`w-full h-10 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-all ${
            isOutOfStock
              ? "bg-neutral-100 text-neutral-400 cursor-not-allowed"
              : isAdding 
                ? "bg-emerald-50 text-emerald-600" 
                : "bg-neutral-900 text-white hover:bg-neutral-800 active:scale-[0.97]"
          }`}
        >
          {isOutOfStock ? "Out of stock" : isAdding ? (<>✓ Added</>) : (<><ShoppingBag className="h-3.5 w-3.5" /> Add to cart</>)}
        </button>
      </div>
    </div>
  );
}
