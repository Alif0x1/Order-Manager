import * as React from "react";
import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { MapPin, ArrowLeft, Loader2, Ticket, CheckCircle2, Check, ChevronDown, Plus, ArrowRight, Truck } from "lucide-react";
import { toast } from "sonner";

interface Location {
  id: number;
  name: string;
}

interface OrderFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  total: number;
  discount: number;
  locations: Location[];
  onApplyCoupon: (couponData: any) => void;
  appliedCoupon?: any;
  initialLocation?: string;
}

export default function OrderForm({ 
  onSubmit, onCancel, total, discount, locations, onApplyCoupon, appliedCoupon, initialLocation = ""
}: OrderFormProps) {
  const [formData, setFormData] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    address: "",
    location: initialLocation,
    customerNote: "",
    deliveryZone: "" as "inside_dhaka" | "outside_dhaka" | ""
  });
  const [couponCode, setCouponCode] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [locationOpen, setLocationOpen] = useState(false);
  const locationRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (locationRef.current && !locationRef.current.contains(e.target as Node)) {
        setLocationOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (appliedCoupon?.code) {
      setCouponCode(appliedCoupon.code);
    }
  }, [appliedCoupon]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.customerName.trim()) { toast.error("Please enter your name"); return; }
    if (!formData.customerPhone.trim()) { toast.error("Please enter your phone number"); return; }
    if (!formData.deliveryZone) { toast.error("Please select a delivery zone"); return; }
    if (!formData.address.trim()) { toast.error("Please enter your delivery address"); return; }

    setIsSubmitting(true);
    const deliveryCharge = formData.deliveryZone === "inside_dhaka" ? 80 : 120;
    onSubmit({ ...formData, deliveryCharge });
  };

  const handleApplyCoupon = async () => {
    if (!couponCode) return;
    setIsValidating(true);
    try {
      const response = await fetch("/api/coupons/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: couponCode, cartTotal: total })
      });
      if (response.ok) {
        const data = await response.json();
        onApplyCoupon(data);
        toast.success(`Coupon ${data.code} applied!`);
      } else {
        const err = await response.json();
        toast.error(err.error || "Invalid coupon code");
      }
    } catch (error) {
      toast.error("Failed to validate coupon");
    } finally {
      setIsValidating(false);
    }
  };

  const deliveryCharge = formData.deliveryZone === "inside_dhaka" ? 80 : formData.deliveryZone === "outside_dhaka" ? 120 : 0;
  const finalTotal = total - discount + deliveryCharge;

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 pb-4 border-b border-neutral-100 mb-6">
        <button onClick={onCancel} className="p-2 rounded-lg text-neutral-400 hover:text-neutral-900 hover:bg-neutral-50 transition-colors">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <h2 className="text-base font-semibold text-neutral-900">Checkout</h2>
      </div>
      
      <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto space-y-6 pr-1">
        {/* Customer */}
        <section className="space-y-3">
          <p className="text-xs text-neutral-400 font-medium">Customer details</p>
          <div>
            <label className="text-xs text-neutral-500 font-medium mb-1 block">Name <span className="text-rose-400">*</span></label>
            <Input required value={formData.customerName} onChange={(e) => setFormData({ ...formData, customerName: e.target.value })} placeholder="Full name" className="h-11 rounded-xl bg-neutral-50 border-neutral-200 text-sm font-medium" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-neutral-500 font-medium mb-1 block">Email</label>
              <Input type="email" value={formData.customerEmail} onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })} placeholder="Optional" className="h-10 rounded-lg bg-neutral-50 border-neutral-200 text-sm" />
            </div>
            <div>
              <label className="text-xs text-neutral-500 font-medium mb-1 block">Phone <span className="text-rose-400">*</span></label>
              <Input required value={formData.customerPhone} onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })} placeholder="01XXXXXXXX" className="h-10 rounded-lg bg-neutral-50 border-neutral-200 text-sm" />
            </div>
          </div>
        </section>

        {/* Delivery */}
        <section className="space-y-3">
          <p className="text-xs text-neutral-400 font-medium">Delivery</p>
          
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => setFormData({...formData, deliveryZone: "inside_dhaka"})} className={`p-3 rounded-xl border text-left transition-all ${formData.deliveryZone === "inside_dhaka" ? "border-neutral-900 bg-neutral-50" : "border-neutral-200 hover:border-neutral-300"}`}>
              <p className="text-sm font-semibold text-neutral-900">Inside Dhaka</p>
              <p className="text-xs text-neutral-400 mt-0.5">৳80 · 2–3 days</p>
            </button>
            <button type="button" onClick={() => setFormData({...formData, deliveryZone: "outside_dhaka"})} className={`p-3 rounded-xl border text-left transition-all ${formData.deliveryZone === "outside_dhaka" ? "border-neutral-900 bg-neutral-50" : "border-neutral-200 hover:border-neutral-300"}`}>
              <p className="text-sm font-semibold text-neutral-900">Outside Dhaka</p>
              <p className="text-xs text-neutral-400 mt-0.5">৳120 · 3–5 days</p>
            </button>
          </div>

          {/* Location combo */}
          <div ref={locationRef} className="relative">
            <label className="text-xs text-neutral-500 font-medium mb-1 block">Area</label>
            <div className="relative">
              <Input value={formData.location} onChange={(e) => { setFormData({ ...formData, location: e.target.value }); setLocationOpen(true); }} onFocus={() => setLocationOpen(true)} placeholder="Type or select area" className="h-10 rounded-lg bg-neutral-50 border-neutral-200 text-sm font-medium pr-9" />
              <button type="button" onClick={() => setLocationOpen(!locationOpen)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400">
                <ChevronDown className={`h-3.5 w-3.5 transition-transform ${locationOpen ? "rotate-180" : ""}`} />
              </button>
            </div>
            {locationOpen && locations.length > 0 && (
              <div className="absolute z-50 w-full mt-1 bg-white rounded-xl shadow-lg border border-neutral-100 overflow-hidden">
                <div className="max-h-40 overflow-y-auto py-1">
                  {locations.filter(loc => !formData.location || loc.name.toLowerCase().includes(formData.location.toLowerCase())).map((loc) => (
                    <button key={loc.id} type="button" onClick={() => { setFormData({ ...formData, location: loc.name }); setLocationOpen(false); }}
                      className={`w-full flex items-center gap-2 px-3 py-2 text-left text-xs hover:bg-neutral-50 transition-colors ${formData.location === loc.name ? "font-semibold text-neutral-900 bg-neutral-50" : "text-neutral-600 font-medium"}`}
                    >
                      <span className={`h-1.5 w-1.5 rounded-full ${formData.location === loc.name ? "bg-neutral-900" : "bg-neutral-200"}`} />
                      {loc.name}
                      {formData.location === loc.name && <Check className="h-3 w-3 text-neutral-900 ml-auto" />}
                    </button>
                  ))}
                  {formData.location && !locations.some(loc => loc.name.toLowerCase() === formData.location.toLowerCase()) && (
                    <div className="px-3 py-2 text-[11px] text-neutral-400 border-t border-neutral-50 font-medium flex items-center gap-1.5">
                      <Plus className="h-3 w-3" /> Use "{formData.location}"
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="text-xs text-neutral-500 font-medium mb-1 block">Address <span className="text-rose-400">*</span></label>
            <Input required value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} placeholder="House, road, apartment…" className="h-11 rounded-xl bg-neutral-50 border-neutral-200 text-sm font-medium" />
          </div>
        </section>

        {/* Note */}
        <section>
          <label className="text-xs text-neutral-500 font-medium mb-1 block">Order note</label>
          <textarea value={formData.customerNote} onChange={(e) => setFormData({ ...formData, customerNote: e.target.value })} placeholder="Special instructions (optional)" rows={2} className="w-full rounded-xl bg-neutral-50 border border-neutral-200 focus:ring-1 focus:ring-neutral-300 outline-none transition-all text-sm p-3 resize-none placeholder:text-neutral-300" />
        </section>

        {/* Coupon */}
        {!appliedCoupon?.code ? (
          <div className="flex gap-2">
            <Input placeholder="Promo code" value={couponCode} onChange={(e) => setCouponCode(e.target.value.toUpperCase())} className="h-10 rounded-lg bg-neutral-50 border-neutral-200 text-xs font-medium uppercase tracking-wider flex-1" />
            <button type="button" onClick={handleApplyCoupon} disabled={isValidating || !couponCode} className="h-10 px-4 rounded-lg bg-neutral-900 text-white text-xs font-medium hover:bg-neutral-800 disabled:opacity-30 transition-all">
              {isValidating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Apply"}
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-between bg-emerald-50 rounded-lg px-3 py-2">
            <div className="flex items-center gap-2">
              <Check className="h-3.5 w-3.5 text-emerald-600" />
              <span className="text-xs font-semibold text-emerald-700">{appliedCoupon.code} · −৳{discount.toLocaleString()}</span>
            </div>
            <button type="button" onClick={() => { onApplyCoupon({code: null, discount: 0}); setCouponCode(""); }} className="text-[11px] font-medium text-emerald-600 hover:text-rose-500 transition-colors">Remove</button>
          </div>
        )}

        {/* Summary + Submit */}
        <section className="bg-neutral-50 rounded-xl p-4 space-y-2.5 mb-8">
          <div className="flex justify-between text-sm">
            <span className="text-neutral-500">Subtotal</span>
            <span className="font-medium text-neutral-700 tabular-nums">৳{total.toLocaleString()}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-emerald-600">Discount</span>
              <span className="font-medium text-emerald-600 tabular-nums">−৳{discount.toLocaleString()}</span>
            </div>
          )}
          <div className="flex justify-between text-sm">
            <span className="text-neutral-500 flex items-center gap-1"><Truck className="h-3 w-3" /> Delivery</span>
            <span className="font-medium text-neutral-700 tabular-nums">{deliveryCharge > 0 ? `৳${deliveryCharge}` : "৳0"}</span>
          </div>
          <div className="border-t border-neutral-100 pt-2.5 flex justify-between">
            <span className="text-sm font-semibold text-neutral-900">Total</span>
            <span className="text-lg font-bold text-neutral-900 tabular-nums">৳{finalTotal.toLocaleString()}</span>
          </div>
          
          <button type="submit" disabled={isSubmitting} className="w-full h-12 mt-2 bg-neutral-900 text-white rounded-xl text-sm font-semibold hover:bg-neutral-800 active:scale-[0.98] transition-all disabled:opacity-40 flex items-center justify-center gap-2">
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : (<>Place order <ArrowRight className="h-4 w-4" /></>)}
          </button>
          <p className="text-center text-[10px] text-neutral-300 pt-1">Secure checkout · Cash on delivery</p>
        </section>
      </form>
    </div>
  );
}
