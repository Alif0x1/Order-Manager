import React, { useState, useEffect, useRef } from "react";
import { Plus, Minus, ShoppingCart, ArrowRight, Ticket, CheckCircle2, Loader2, X, MapPin, ChevronDown, Check, Trash2 } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { AnimatePresence, motion } from "motion/react";
import { toast } from "sonner";

interface CartItem {
  _id: string;
  title: string;
  price: number;
  imageSrc: string;
  quantity: number;
  selectedVariant?: string;
}

interface CartProps {
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number, variant?: string) => void;
  onRemove: (id: string, variant?: string) => void;
  onCheckout: () => void;
  discount: number;
  appliedCoupon: any;
  onApplyCoupon: (couponData: any) => void;
  locations: any[];
  selectedLocation: string;
  onLocationChange: (location: string) => void;
}

export default function Cart({ 
  items, onUpdateQuantity, onRemove, onCheckout, discount, appliedCoupon, onApplyCoupon,
  locations, selectedLocation, onLocationChange
}: CartProps) {
  const [couponCode, setCouponCode] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const [locDropdownOpen, setLocDropdownOpen] = useState(false);
  const locRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (locRef.current && !locRef.current.contains(e.target as Node)) {
        setLocDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal - discount;
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  const handleApplyCoupon = async () => {
    if (!couponCode) return;
    setIsValidating(true);
    try {
      const response = await fetch("/api/coupons/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: couponCode, cartTotal: subtotal })
      });
      if (response.ok) {
        const data = await response.json();
        onApplyCoupon(data);
        toast.success(`Coupon ${data.code} applied! You saved ৳${data.discount.toLocaleString()}`);
      } else {
        const err = await response.json();
        toast.error(err.error || "Invalid coupon code");
      }
    } catch (error) {
      toast.error("Failed to validate coupon");
    } finally {
      setIsValidating(false);
    }
  };

  const handleRemoveCoupon = () => {
    onApplyCoupon({ code: null, discount: 0 });
    setCouponCode("");
    toast.info("Coupon removed");
  };

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] text-center px-6">
        <div className="bg-neutral-50 p-6 rounded-2xl mb-6">
          <ShoppingCart className="h-10 w-10 text-neutral-300" />
        </div>
        <h3 className="text-lg font-semibold text-neutral-900 mb-1">Your cart is empty</h3>
        <p className="text-sm text-neutral-400 max-w-[240px]">
          Browse our products and add items to get started.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
        <div>
          <p className="text-sm font-semibold text-neutral-900">{itemCount} {itemCount === 1 ? "item" : "items"}</p>
        </div>
        <button onClick={onCheckout} className="text-sm font-medium text-neutral-900 hover:underline flex items-center gap-1">
          Checkout <ArrowRight className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Item list */}
      <ScrollArea className="flex-grow">
        <div className="divide-y divide-neutral-50 py-2">
          <AnimatePresence initial={false}>
            {items.map((item) => (
              <motion.div 
                key={`${item._id}-${item.selectedVariant || "default"}`}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                layout
                className="py-4"
              >
                <div className="flex gap-3">
                  <div className="h-16 w-16 rounded-lg overflow-hidden bg-neutral-50 flex-shrink-0">
                    <img src={item.imageSrc} alt={item.title} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="text-sm font-medium text-neutral-900 line-clamp-1">{item.title}</h4>
                        {item.selectedVariant && <span className="text-[11px] text-neutral-400">{item.selectedVariant}</span>}
                      </div>
                      <button onClick={() => onRemove(item._id, item.selectedVariant)} className="text-neutral-300 hover:text-rose-500 transition-colors shrink-0 p-0.5">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-sm font-semibold text-neutral-900 tabular-nums">৳{(item.price * item.quantity).toLocaleString()}</span>
                      <div className="flex items-center gap-0 bg-neutral-50 rounded-lg border border-neutral-100">
                        <button onClick={() => onUpdateQuantity(item._id, -1, item.selectedVariant)} disabled={item.quantity <= 1} className="h-7 w-7 flex items-center justify-center text-neutral-500 hover:text-neutral-900 disabled:opacity-30 transition-colors">
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="text-xs font-semibold text-neutral-800 w-6 text-center tabular-nums">{item.quantity}</span>
                        <button onClick={() => onUpdateQuantity(item._id, 1, item.selectedVariant)} className="h-7 w-7 flex items-center justify-center text-neutral-500 hover:text-neutral-900 transition-colors">
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </ScrollArea>
      
      {/* Bottom */}
      <div className="pt-4 space-y-4 border-t border-neutral-100">
        {/* Coupon */}
        <div className="space-y-2">
          {!appliedCoupon?.code ? (
            <div className="flex gap-2">
              <Input
                placeholder="Promo code"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                className="h-10 rounded-lg bg-neutral-50 border-neutral-200 text-xs font-medium uppercase tracking-wider flex-1"
              />
              <button onClick={handleApplyCoupon} disabled={isValidating || !couponCode} className="h-10 px-4 rounded-lg bg-neutral-900 text-white text-xs font-medium hover:bg-neutral-800 disabled:opacity-30 transition-all">
                {isValidating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Apply"}
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between bg-emerald-50 rounded-lg px-3 py-2">
              <div className="flex items-center gap-2">
                <Check className="h-3.5 w-3.5 text-emerald-600" />
                <span className="text-xs font-semibold text-emerald-700">{appliedCoupon.code} · −৳{discount.toLocaleString()}</span>
              </div>
              <button onClick={handleRemoveCoupon} className="text-[11px] font-medium text-emerald-600 hover:text-rose-500 transition-colors">Remove</button>
            </div>
          )}
        </div>

        {/* Location */}
        <div ref={locRef} className="relative">
          <p className="text-xs text-neutral-400 font-medium mb-1.5">Delivery area</p>
          <div className="relative">
            <Input
              value={selectedLocation}
              onChange={(e) => { onLocationChange(e.target.value); setLocDropdownOpen(true); }}
              onFocus={() => setLocDropdownOpen(true)}
              placeholder="Select or type area…"
              className="h-10 rounded-lg bg-neutral-50 border-neutral-200 text-xs font-medium pl-3 pr-9"
            />
            <button type="button" onClick={() => setLocDropdownOpen(!locDropdownOpen)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400">
              <ChevronDown className={`h-3.5 w-3.5 transition-transform ${locDropdownOpen ? "rotate-180" : ""}`} />
            </button>
          </div>
          <AnimatePresence>
            {locDropdownOpen && locations.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 4 }} className="absolute bottom-full left-0 right-0 mb-1 z-50 bg-white rounded-xl shadow-lg border border-neutral-100 overflow-hidden">
                <div className="max-h-40 overflow-y-auto py-1">
                  {locations.filter(loc => !selectedLocation || loc.name.toLowerCase().includes(selectedLocation.toLowerCase())).map((loc: any) => (
                    <button key={loc._id || loc.id} type="button" onClick={() => { onLocationChange(loc.name); setLocDropdownOpen(false); }}
                      className={`w-full flex items-center gap-2 px-3 py-2 text-left text-xs transition-colors hover:bg-neutral-50 ${selectedLocation === loc.name ? "text-neutral-900 font-semibold bg-neutral-50" : "text-neutral-600 font-medium"}`}
                    >
                      <span className={`h-1.5 w-1.5 rounded-full ${selectedLocation === loc.name ? "bg-neutral-900" : "bg-neutral-200"}`} />
                      {loc.name}
                    </button>
                  ))}
                  {selectedLocation && !locations.some(l => l.name.toLowerCase() === selectedLocation.toLowerCase()) && (
                    <button type="button" onClick={() => setLocDropdownOpen(false)} className="w-full flex items-center gap-2 px-3 py-2 text-left text-[11px] font-medium text-neutral-500 bg-neutral-50 border-t border-neutral-100">
                      <Plus className="h-3 w-3" /> Use "{selectedLocation}"
                    </button>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Summary */}
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-neutral-400">Subtotal</span>
            <span className="font-medium text-neutral-700 tabular-nums">৳{subtotal.toLocaleString()}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between">
              <span className="text-emerald-600">Discount</span>
              <span className="font-medium text-emerald-600 tabular-nums">−৳{discount.toLocaleString()}</span>
            </div>
          )}
          <div className="flex justify-between text-xs text-neutral-300">
            <span>Shipping</span>
            <span>Calculated at checkout</span>
          </div>
        </div>

        {/* CTA */}
        <div className="pb-6 space-y-3">
          <div className="flex items-baseline justify-between">
            <span className="text-xs text-neutral-400">Total</span>
            <span className="text-xl font-bold text-neutral-900 tabular-nums">৳{total.toLocaleString()}</span>
          </div>
          <button onClick={onCheckout} className="w-full h-12 bg-neutral-900 text-white rounded-xl text-sm font-semibold hover:bg-neutral-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2">
            Checkout <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
