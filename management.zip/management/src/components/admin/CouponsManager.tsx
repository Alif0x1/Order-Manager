import React, { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Ticket, Loader2, Edit3, Trash2, Plus, Zap, Award, Target, Percent, DollarSign, ArrowRight, ShieldCheck } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

interface CouponItem {
  _id?: string;
  code: string;
  type: "percentage" | "fixed";
  value: number;
  minOrder: number;
  active: boolean;
}

export default function CouponsManager() {
  const [coupons, setCoupons] = useState<CouponItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDataLoading, setIsDataLoading] = useState(false);
  const [isUpdating, setIsUpdating] = useState<string | null>(null);

  const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<CouponItem | null>(null);
  const [couponFormData, setCouponFormData] = useState<CouponItem>({
    code: "",
    type: "percentage",
    value: 0,
    minOrder: 0,
    active: true
  });

  useEffect(() => {
    fetchCoupons();
  }, []);

  const fetchCoupons = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/coupons");
      if (response.ok) {
        const data = await response.json();
        setCoupons(data);
      }
    } catch (error) {
      toast.error("Incentive sync failed");
    } finally {
      setIsLoading(false);
      setIsDataLoading(false);
    }
  };

  const handleCouponSubmit = async () => {
    if (!couponFormData.code) {
      toast.error("Voucher identification required");
      return;
    }
    setIsDataLoading(true);
    const method = editingCoupon ? "PATCH" : "POST";
    const url = editingCoupon ? `/api/coupons/${editingCoupon._id}` : "/api/coupons";
    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...couponFormData, code: couponFormData.code.toUpperCase() })
      });
      if (response.ok) {
        toast.success(`Incentive ${editingCoupon ? "re-calibrated" : "authorized"} successfully!`);
        setIsCouponModalOpen(false);
        fetchCoupons();
      } else {
        const err = await response.json();
        toast.error("Authorization protocol rejected");
      }
    } catch (error) {
      toast.error("Database connectivity interrupted");
    } finally {
      setIsDataLoading(false);
    }
  };

  const toggleCouponActive = async (coupon: CouponItem) => {
    try {
      const response = await fetch(`/api/coupons/${coupon._id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active: !coupon.active })
      });
      if (response.ok) {
        toast.success(`Token ${coupon.code} ${coupon.active ? "deactivated" : "reactivated"}`);
        fetchCoupons();
      }
    } catch (error) {
      toast.error("Status toggle failed");
    }
  };

  const deleteCoupon = async (couponId: string) => {
    if (!confirm("Caution: Decommissioning this yield-optimization token is irreversible. Proceed?")) return;
    setIsUpdating(couponId);
    try {
      const response = await fetch(`/api/coupons/${couponId}`, { method: "DELETE" });
      if (response.ok) {
        toast.success("Incentive purged from registry");
        fetchCoupons();
      }
    } catch (error) {
      toast.error("Decommissioning failed");
    } finally {
      setIsUpdating(null);
    }
  };

  const openAddCoupon = () => {
    setEditingCoupon(null);
    setCouponFormData({ code: "", type: "percentage", value: 0, minOrder: 0, active: true });
    setIsCouponModalOpen(true);
  };

  const handleEditCoupon = (coupon: CouponItem) => {
    setEditingCoupon(coupon);
    setCouponFormData(coupon);
    setIsCouponModalOpen(true);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="space-y-8 pb-12">
      {/* Premium Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-1">
        <div className="space-y-1.5 outline-none">
          <div className="flex items-center gap-2 mb-2">
            <div className="bg-indigo-600 h-2 w-8 rounded-full" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-500">Revenue Optimization</span>
          </div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tighter">Incentive Registry</h2>
          <p className="text-slate-400 font-bold max-w-lg">Architect and deploy strategic fulfillment incentives to optimize conversion metrics.</p>
        </div>
        
        <Button onClick={openAddCoupon} className="bg-slate-900 hover:bg-indigo-600 text-white rounded-2xl h-14 px-8 font-black text-xs uppercase tracking-widest shadow-xl shadow-slate-200 transition-all flex items-center gap-3 active:scale-95">
          <div className="bg-white/10 p-1.5 rounded-lg">
            <Plus className="h-4 w-4" />
          </div>
          Authorize Token
        </Button>
      </div>

      {/* Incentive Overview */}
      <Card className="border-none shadow-sm rounded-[3rem] overflow-hidden bg-white/50 backdrop-blur-sm border border-white">
        <CardHeader className="p-10 pb-2">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                 <div className="bg-indigo-600 p-2.5 rounded-xl shadow-lg shadow-indigo-100">
                    <Award className="h-6 w-6 text-white" />
                 </div>
                 <h3 className="text-2xl font-black text-slate-800 tracking-tight">Voucher Manifest</h3>
              </div>
              <p className="text-slate-400 font-bold text-sm ml-11">Manage active economic levers across the distribution grid.</p>
            </div>
            <Badge className="bg-slate-900 text-white border-none font-black uppercase text-[10px] tracking-[0.2em] px-5 py-2 rounded-full shadow-lg shadow-slate-100">{coupons.length} Active Modules</Badge>
          </div>
        </CardHeader>
        <CardContent className="p-10">
          {isLoading && coupons.length === 0 ? (
            <div className="py-32 flex flex-col items-center justify-center space-y-4">
               <Loader2 className="h-10 w-10 animate-spin text-indigo-600 opacity-20" />
               <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-300">Auditing Token State...</p>
            </div>
          ) : coupons.length === 0 ? (
            <div className="py-32 text-center space-y-6">
               <div className="bg-slate-50 h-24 w-24 rounded-full flex items-center justify-center mx-auto mb-4 border border-slate-100">
                  <Ticket className="h-10 w-10 text-slate-200" />
               </div>
               <div className="space-y-2">
                  <h4 className="text-xl font-black text-slate-700">No Authorized Incentives</h4>
                  <p className="text-slate-400 font-bold text-sm max-w-xs mx-auto">Authorize your first economic token to begin optimizing revenue streams.</p>
               </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <AnimatePresence mode="popLayout">
                {coupons.map((coupon: CouponItem) => (
                  <motion.div
                    key={coupon._id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ type: "spring", damping: 25, stiffness: 300 }}
                    className={`relative rounded-[2.5rem] border-2 p-8 transition-all duration-500 group overflow-hidden ${
                      coupon.active 
                        ? "bg-white border-slate-100 hover:border-indigo-600 hover:shadow-2xl hover:shadow-indigo-50/50" 
                        : "bg-slate-50 border-slate-50 opacity-60 grayscale"
                    }`}
                  >
                    {/* Status Dot */}
                    <div className={`absolute top-8 right-8 h-4 w-4 rounded-full ${
                      coupon.active ? "bg-emerald-500 shadow-lg shadow-emerald-200 animate-pulse" : "bg-slate-300"
                    }`} />

                    <div className="space-y-6">
                      <div className="space-y-1">
                        <span className="text-[10px] text-slate-300 font-black uppercase tracking-[0.3em] block mb-2">Token Identification</span>
                        <div className="flex items-center gap-3">
                           <div className={`p-2 rounded-lg ${coupon.active ? "bg-indigo-50 text-indigo-600" : "bg-slate-200 text-slate-400"}`}>
                              <Zap className="h-4 w-4" />
                           </div>
                           <span className="text-3xl font-black text-slate-900 tracking-tighter group-hover:text-indigo-600 transition-colors">{coupon.code}</span>
                        </div>
                      </div>

                      <div className="bg-slate-50/50 p-6 rounded-3xl border border-slate-100 flex items-center justify-between group-hover:bg-indigo-50/30 group-hover:border-indigo-100 transition-all duration-500">
                        <div className="space-y-1">
                           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Yield Impact</p>
                           <div className="flex items-baseline gap-1">
                              <span className="text-3xl font-black text-indigo-600">
                                {coupon.type === "percentage" ? `${coupon.value}%` : `৳${coupon.value}`}
                              </span>
                              <span className="text-[10px] font-black text-slate-400 uppercase">Off</span>
                           </div>
                        </div>
                        <div className="h-10 w-px bg-slate-100" />
                        <div className="text-right space-y-1">
                           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Activation</p>
                           <p className="text-sm font-black text-slate-900">৳{coupon.minOrder.toLocaleString()}</p>
                           <p className="text-[9px] font-black text-slate-400 uppercase">Threshold</p>
                        </div>
                      </div>

                      <div className="flex gap-3 pt-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => toggleCouponActive(coupon)}
                          disabled={isUpdating === coupon._id}
                          className={`flex-1 rounded-2xl h-12 font-black text-[10px] uppercase tracking-widest transition-all active:scale-95 shadow-sm ${
                            coupon.active 
                              ? "bg-slate-50 border-transparent text-slate-500 hover:bg-rose-50 hover:text-rose-600" 
                              : "bg-emerald-600 border-transparent text-white hover:bg-emerald-700 shadow-emerald-100"
                          }`}
                        >
                          {coupon.active ? "Decommission" : "Authorize"}
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleEditCoupon(coupon)}
                          className="rounded-2xl h-12 w-12 bg-white border border-slate-100 hover:border-indigo-600 hover:text-indigo-600 shadow-sm transition-all active:scale-95 group/edit"
                        >
                          <Edit3 className="h-4 w-4 group-hover/edit:rotate-12 transition-transform" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => deleteCoupon(coupon._id!)}
                          disabled={isUpdating === coupon._id}
                          className="rounded-2xl h-12 w-12 bg-white border border-slate-100 hover:bg-rose-50 hover:text-rose-600 shadow-sm transition-all active:scale-95"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    {/* Decorative Background Elements */}
                    <div className="absolute -bottom-4 -right-4 opacity-[0.03] group-hover:scale-110 group-hover:opacity-[0.07] transition-all duration-700 pointer-events-none">
                       <Award className="h-40 w-40 rotate-12" />
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Strategic Token Parameters Modal */}
      <Dialog open={isCouponModalOpen} onOpenChange={setIsCouponModalOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-[3rem] p-0 overflow-hidden border-none shadow-2xl bg-white">
          <div className="bg-slate-900 p-10 text-white relative">
             <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none">
                <Target className="h-24 w-24" />
             </div>
            <DialogHeader className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                 <div className="h-2 w-2 bg-indigo-500 rounded-full animate-pulse" />
                 <span className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-400">Yield Management Protocol</span>
              </div>
              <DialogTitle className="text-3xl font-black tracking-tighter">{editingCoupon ? "Re-calibrate Token" : "Authorize New Strategic Incentive"}</DialogTitle>
              <DialogDescription className="text-slate-400 font-bold text-[10px] uppercase tracking-widest pt-1 flex items-center gap-2">
                Define the economic logic for this fulfillment asset.
                <ArrowRight className="h-3 w-3" />
              </DialogDescription>
            </DialogHeader>
          </div>
          
          <div className="p-10 space-y-8 bg-[#fdfdfd]">
            <div className="space-y-3">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Voucher Identification</Label>
              <div className="relative group">
                 <Zap className="absolute left-5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-300 group-focus-within:text-indigo-600 transition-colors" />
                 <Input
                   value={couponFormData.code}
                   onChange={(e) => setCouponFormData({...couponFormData, code: e.target.value.toUpperCase()})}
                   placeholder="e.g. STRATEGY2026"
                   className="h-14 pl-14 rounded-2xl bg-white border-transparent shadow-sm focus:ring-2 focus:ring-indigo-100 transition-all font-black text-lg uppercase tracking-widest placeholder:font-medium placeholder:normal-case placeholder:text-sm placeholder:tracking-normal"
                 />
              </div>
            </div>

            <div className="space-y-4">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Discount Classification</Label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setCouponFormData({...couponFormData, type: "percentage"})}
                  className={`flex items-center justify-center gap-3 h-14 rounded-2xl border-2 transition-all duration-300 ${
                    couponFormData.type === "percentage" ? "border-indigo-600 bg-indigo-50 text-indigo-700 shadow-md shadow-indigo-100" : "border-slate-100 bg-white text-slate-400 hover:border-indigo-100"
                  }`}
                >
                  <Percent className="h-4 w-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Percentage Yield</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCouponFormData({...couponFormData, type: "fixed"})}
                  className={`flex items-center justify-center gap-3 h-14 rounded-2xl border-2 transition-all duration-300 ${
                    couponFormData.type === "fixed" ? "border-indigo-600 bg-indigo-50 text-indigo-700 shadow-md shadow-indigo-100" : "border-slate-100 bg-white text-slate-400 hover:border-indigo-100"
                  }`}
                >
                  <DollarSign className="h-4 w-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Fixed Amount</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
               <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Economic Value</Label>
                  <Input
                    type="number"
                    value={couponFormData.value}
                    onChange={(e) => setCouponFormData({...couponFormData, value: Number(e.target.value)})}
                    className="h-14 rounded-2xl bg-white border-slate-100 focus:ring-2 focus:ring-indigo-100 transition-all font-black text-indigo-600 text-lg px-6"
                  />
               </div>
               <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Activation Threshold</Label>
                  <Input
                    type="number"
                    value={couponFormData.minOrder}
                    onChange={(e) => setCouponFormData({...couponFormData, minOrder: Number(e.target.value)})}
                    placeholder="৳0"
                    className="h-14 rounded-2xl bg-white border-slate-100 focus:ring-2 focus:ring-indigo-100 transition-all font-black text-slate-900 text-lg px-6"
                  />
               </div>
            </div>
          </div>

          <div className="p-10 border-t border-slate-100 flex gap-4 bg-white">
            <Button variant="ghost" onClick={() => setIsCouponModalOpen(false)} className="flex-1 h-14 rounded-[1.5rem] bg-slate-50 font-black text-xs uppercase tracking-widest text-slate-400 hover:bg-slate-100 transition-all">Abort Update</Button>
            <Button 
               onClick={handleCouponSubmit} 
               disabled={isDataLoading || !couponFormData.code} 
               className="flex-1 h-14 bg-indigo-600 hover:bg-black text-white rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] shadow-lg shadow-indigo-100 transition-all flex items-center justify-center gap-3"
            >
              {isDataLoading ? <Loader2 className="animate-spin h-5 w-5" /> : (
                 <>
                    <ShieldCheck className="h-4 w-4" />
                    {editingCoupon ? "Commit Calibration" : "Authorize Strategic Token"}
                 </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
