import React, { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { MapPin, Plus, Edit3, Trash2, Loader2, ShoppingBag, X, Globe, Zap, Target, Network } from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

export default function ZonesManager() {
  const [locations, setLocations] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingZone, setEditingZone] = useState<any | null>(null);
  const [formData, setFormData] = useState({ name: "", status: "Active" });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/locations");
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      }
    } catch (error) {
      toast.error("Network synchronization failed");
    } finally {
      setIsLoading(false);
    }
  };

  const openAddZone = () => {
    setEditingZone(null);
    setFormData({ name: "", status: "Active" });
    setIsModalOpen(true);
  };

  const openEditZone = (zone: any) => {
    setEditingZone(zone);
    setFormData({ name: zone.name, status: zone.status || "Active" });
    setIsModalOpen(true);
  };

  const handleSubmit = async () => {
    if (!formData.name.trim()) {
      toast.error("Node designation is required");
      return;
    }
    setIsSaving(true);
    const method = editingZone ? "PATCH" : "POST";
    const url = editingZone ? `/api/locations/${editingZone._id}` : "/api/locations";

    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        toast.success(`Logistics Point ${editingZone ? "re-initialized" : "established"} successfully!`);
        setIsModalOpen(false);
        fetchLocations();
      } else {
        const err = await response.json();
        toast.error("Protocol error during node sync");
      }
    } catch (error) {
      toast.error("Connectivity failure in logistics chain");
    } finally {
      setIsSaving(false);
    }
  };

  const deleteZone = async (zoneId: string) => {
    if (!confirm("Caution: Decommissioning this distribution node will interrupt local logistics. Proceed?")) return;
    try {
      const response = await fetch(`/api/locations/${zoneId}`, { method: "DELETE" });
      if (response.ok) {
        toast.success("Node decommissioned");
        fetchLocations();
      }
    } catch (error) {
      toast.error("Decommissioning sequence failed");
    }
  };

  const totalOrders = locations.reduce((s, l) => s + (l.orders || 0), 0);

  return (
    <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="space-y-8 pb-12">
      {/* Premium Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-1">
        <div className="space-y-1.5 outline-none">
          <div className="flex items-center gap-2 mb-2">
            <div className="bg-indigo-600 h-2 w-8 rounded-full" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-500">Logistics Network</span>
          </div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tighter">Distribution Grid</h2>
          <p className="text-slate-400 font-bold max-w-lg">Audit regional fulfillment nodes and optimize delivery coverage across your supply network.</p>
        </div>
        
        <Button onClick={openAddZone} className="bg-slate-900 hover:bg-indigo-600 text-white rounded-2xl h-14 px-8 font-black text-xs uppercase tracking-widest shadow-xl shadow-slate-200 transition-all flex items-center gap-3">
          <div className="bg-white/10 p-1.5 rounded-lg">
            <Plus className="h-4 w-4" />
          </div>
          Establish Node
        </Button>
      </div>

      {/* Logistics Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 px-1">
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100 flex items-center gap-6 group hover:shadow-lg transition-all duration-500">
          <div className="h-16 w-16 bg-indigo-50 rounded-[1.5rem] flex items-center justify-center border border-indigo-100 group-hover:scale-105 transition-transform">
             <Network className="h-8 w-8 text-indigo-600" />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Points</p>
            <p className="text-3xl font-black text-slate-900">{locations.length}</p>
          </div>
        </div>
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100 flex items-center gap-6 group hover:shadow-lg transition-all duration-500">
          <div className="h-16 w-16 bg-blue-50 rounded-[1.5rem] flex items-center justify-center border border-blue-100 group-hover:scale-105 transition-transform">
             <Target className="h-8 w-8 text-blue-600" />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Unit Throughput</p>
            <p className="text-3xl font-black text-blue-600">{totalOrders.toLocaleString()}</p>
          </div>
        </div>
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100 flex items-center gap-6 group hover:shadow-lg transition-all duration-500">
          <div className="h-16 w-16 bg-emerald-50 rounded-[1.5rem] flex items-center justify-center border border-emerald-100 group-hover:scale-105 transition-transform">
             <Zap className="h-8 w-8 text-emerald-600" />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Operational</p>
            <p className="text-3xl font-black text-emerald-600">{locations.filter(l => l.status === "Active" || l.status === "Operational").length}</p>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-32 space-y-4">
           <Loader2 className="animate-spin h-10 w-10 text-indigo-600 opacity-20" />
           <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-300">Auditing Node Network...</p>
        </div>
      ) : locations.length === 0 ? (
        <div className="bg-white rounded-[3rem] p-20 shadow-sm border border-slate-100 text-center space-y-6">
            <div className="bg-slate-50 h-24 w-24 rounded-full flex items-center justify-center mx-auto">
              <Globe className="h-10 w-10 text-slate-200" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-black text-slate-800">No Distribution Points</h3>
              <p className="text-slate-400 font-bold text-sm max-w-xs mx-auto">Establish your first regional node to begin tracking fulfillment metrics.</p>
            </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-1">
          {locations.map((loc: any) => (
            <motion.div 
              key={loc._id || loc.id}
              layout
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:shadow-indigo-50/50 hover:-translate-y-2 transition-all duration-500 flex flex-col group overflow-hidden"
            >
              <div className="h-2 bg-gradient-to-r from-indigo-500 to-indigo-700 w-full opacity-30 group-hover:opacity-100 transition-opacity"></div>
              
              <div className="p-8 space-y-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <h3 className="text-2xl font-black text-slate-800 tracking-tighter truncate group-hover:text-indigo-600 transition-colors uppercase">{loc.name}</h3>
                    <Badge className={`text-[9px] font-black uppercase tracking-[0.15em] border-none px-3 py-1 rounded-lg ${
                      loc.status === "Active" || loc.status === "Operational" ? "bg-emerald-50 text-emerald-600" : "bg-slate-50 text-slate-400"
                    }`}>
                      Stage: {loc.status || "Active"}
                    </Badge>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-2xl group-hover:bg-indigo-600 group-hover:text-white group-hover:rotate-12 transition-all duration-500 shrink-0">
                    <MapPin className="h-6 w-6" />
                  </div>
                </div>

                <div className="bg-slate-50/50 p-6 rounded-3xl border border-slate-100 flex items-center justify-between group-hover:bg-white group-hover:border-indigo-100 transition-all duration-500">
                  <div className="flex items-center gap-4">
                    <div className="bg-indigo-50 p-3 rounded-2xl">
                      <ShoppingBag className="h-5 w-5 text-indigo-600" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Throughput</p>
                      <p className="text-2xl font-black text-slate-900 tracking-tight">{loc.orders || 0} Units</p>
                    </div>
                  </div>
                  <div className="h-10 w-px bg-slate-100" />
                  <div className="text-right">
                     <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Efficiency</p>
                     <p className="text-sm font-black text-emerald-500">98.4%</p>
                  </div>
                </div>

                <div className="pt-2 flex gap-3 mt-2">
                  <Button variant="outline" onClick={() => openEditZone(loc)} className="flex-1 bg-white rounded-2xl h-12 border-slate-100 hover:border-indigo-600 hover:text-indigo-600 transition-all font-black text-[10px] uppercase tracking-widest active:scale-95 group">
                    <Edit3 className="mr-2 h-4 w-4 text-slate-300 group-hover:text-indigo-500 transition-colors" /> Audit Node
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => deleteZone(loc._id)} className="h-12 w-12 rounded-2xl hover:bg-rose-50 hover:text-rose-500 text-slate-300 active:scale-95">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Logistics Point Optimization Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[500px] rounded-[3rem] p-0 overflow-hidden border-none shadow-2xl bg-white">
          <div className="bg-slate-900 p-10 text-white relative">
             <div className="absolute top-0 right-0 p-10 opacity-5">
               <Globe className="h-24 w-24" />
            </div>
            <DialogHeader className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                 <div className="h-2 w-2 bg-indigo-500 rounded-full animate-pulse" />
                 <span className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-400">Node Configuration</span>
              </div>
              <DialogTitle className="text-3xl font-black tracking-tighter">{editingZone ? "Recalibrate Node" : "Establish New Grid Point"}</DialogTitle>
              <DialogDescription className="text-slate-400 font-bold text-[10px] uppercase tracking-widest pt-1">
                Define regional parameters and fulfillment status.
              </DialogDescription>
            </DialogHeader>
          </div>
          <div className="p-10 space-y-8 bg-[#fdfdfd]">
            <div className="space-y-3">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Location Designation</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Region identifier..."
                className="h-14 rounded-2xl bg-white border-transparent shadow-sm focus:ring-2 focus:ring-indigo-100 transition-all font-black text-sm px-6 uppercase tracking-wider"
              />
            </div>
            <div className="space-y-4">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Lifecycle Stage</Label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {["Active", "Operational", "Expanding"].map(s => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setFormData({ ...formData, status: s })}
                    className={`p-4 rounded-2xl border-2 text-center text-[10px] font-black uppercase tracking-wider transition-all duration-300 ${
                      formData.status === s
                        ? "border-indigo-600 bg-indigo-50 text-indigo-700 shadow-md shadow-indigo-100"
                        : "border-slate-100 bg-white text-slate-400 hover:border-indigo-200"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="p-10 border-t border-slate-100 flex gap-4 bg-white">
            <Button variant="ghost" onClick={() => setIsModalOpen(false)} className="flex-1 h-14 rounded-[1.5rem] bg-slate-50 font-black text-xs uppercase tracking-widest text-slate-400 hover:bg-slate-100 transition-all">Abort Update</Button>
            <Button onClick={handleSubmit} disabled={isSaving} className="flex-1 h-14 bg-indigo-600 hover:bg-black text-white rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] shadow-lg shadow-indigo-100 transition-all">
              {isSaving ? <Loader2 className="animate-spin h-5 w-5" /> : (editingZone ? "Commit Re-calibration" : "Establish Network Node")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
