import React, { useState, useEffect, useMemo } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Search, Loader2, History, MapPin, Eye, MoreVertical, Calendar, User, Package, Ticket, Truck, ChevronRight, StickyNote, ChevronDown, CalendarDays, Receipt, BadgeDollarSign, Wallet, ArrowUpRight, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

const STATUS_COLORS: Record<string, string> = {
  "Pending": "bg-amber-100/80 text-amber-700 border-amber-200 shadow-sm shadow-amber-100/50",
  "In Review": "bg-sky-100/80 text-sky-700 border-sky-200 shadow-sm shadow-sky-100/50",
  "Shipped": "bg-indigo-100/80 text-indigo-700 border-indigo-200 shadow-sm shadow-indigo-100/50",
  "Delivered": "bg-emerald-100/80 text-emerald-700 border-emerald-200 shadow-sm shadow-emerald-100/50",
  "Returned": "bg-rose-100/80 text-rose-700 border-rose-200 shadow-sm shadow-rose-100/50",
  "Cancelled": "bg-slate-100/80 text-slate-500 border-slate-200 shadow-sm"
};

function formatZone(zone?: string) {
  if (!zone) return "";
  return zone.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

function formatDateKey(dateStr: string) {
  const d = new Date(dateStr);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);

  if (d.toDateString() === today.toDateString()) return "Today's Fulfillment";
  if (d.toDateString() === yesterday.toDateString()) return "Yesterday's Activity";
  return d.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function getDateSortKey(dateStr: string) {
  return new Date(dateStr).toDateString();
}

const STEADFAST_STATUS_MAP: Record<string, string> = {
  "pending": "Pending",
  "delivered_approval_pending": "Delivered (Approval Pending)",
  "partial_delivered_approval_pending": "Partial Delivered (Approval Pending)",
  "cancelled_approval_pending": "Cancelled (Approval Pending)",
  "unknown_approval_pending": "Unknown Pending",
  "delivered": "Delivered",
  "partial_delivered": "Partially Delivered",
  "cancelled": "Cancelled",
  "hold": "Hold",
  "in_review": "In Review",
  "unknown": "Unknown"
};

const STEADFAST_STATUS_THEMES: Record<string, string> = {
  "pending": "bg-neutral-100 text-neutral-600 border-neutral-200",
  "delivered_approval_pending": "bg-indigo-50 text-indigo-600 border-indigo-100",
  "partial_delivered_approval_pending": "bg-indigo-50 text-indigo-600 border-indigo-100",
  "cancelled_approval_pending": "bg-rose-50 text-rose-600 border-rose-100",
  "unknown_approval_pending": "bg-slate-50 text-slate-600 border-slate-200",
  "delivered": "bg-emerald-50 text-emerald-700 border-emerald-100",
  "partial_delivered": "bg-emerald-50 text-emerald-600 border-emerald-100",
  "cancelled": "bg-rose-100 text-rose-700 border-rose-200",
  "hold": "bg-amber-50 text-amber-700 border-amber-100",
  "in_review": "bg-sky-50 text-sky-700 border-sky-100",
  "unknown": "bg-slate-100 text-slate-500 border-slate-200"
};

export default function OrdersManager() {
  const [allOrders, setAllOrders] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDataLoading, setIsDataLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isUpdating, setIsUpdating] = useState<string | null>(null);
  const [dateFilter, setDateFilter] = useState("");

  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [steadfastStatus, setSteadfastStatus] = useState<string | null>(null);
  const [isSteadfastLoading, setIsSteadfastLoading] = useState(false);

  const [editingOrder, setEditingOrder] = useState<any | null>(null);
  const [editFormData, setEditFormData] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    address: "",
    deliveryZone: "",
    deliveryCharge: 0
  });

  const fetchSteadfastStatus = React.useCallback(async (orderId: string) => {
    setIsSteadfastLoading(true);
    try {
      const res = await fetch(`/api/steadfast/status/${orderId}`);
      const data = await res.json();
      
      if (res.status === 200) {
        const rawStatus: string = data.delivery_status;
        if (rawStatus) {
          setSteadfastStatus(STEADFAST_STATUS_MAP[rawStatus.toLowerCase()] || rawStatus.replace(/_/g, ' '));
        } else {
          setSteadfastStatus("Unknown/Pending");
        }
      } else if (res.status === 404) {
        setSteadfastStatus("Not found in Courier system");
      } else {
        setSteadfastStatus("Courier sync error");
      }
    } catch (error) {
      setSteadfastStatus("Connection error");
    } finally {
      setIsSteadfastLoading(false);
    }
  }, []);

  useEffect(() => {
    if (selectedOrder) {
      if (selectedOrder.consignmentId || selectedOrder.trackingCode || selectedOrder.orderNumber) {
        fetchSteadfastStatus(selectedOrder._id);
      } else {
        setSteadfastStatus("Not dispatched via courier");
      }
    } else {
      setSteadfastStatus(null);
    }
  }, [selectedOrder, fetchSteadfastStatus]);

  useEffect(() => {
    fetchAllOrders();
  }, []);

  const fetchAllOrders = async () => {
    setIsDataLoading(true);
    setIsLoading(true);
    try {
      const response = await fetch("/api/orders");
      if (response.ok) {
        const data = await response.json();
        setAllOrders(data);
      }
    } catch (error) {
      toast.error("Failed to sync transaction records");
    } finally {
      setIsDataLoading(false);
      setIsLoading(false);
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    setIsUpdating(orderId);
    try {
      const response = await fetch(`/api/orders/${orderId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });

      if (response.ok) {
        toast.success(`Fulfillment status: ${newStatus}`);
        fetchAllOrders();
        if (selectedOrder && selectedOrder._id === orderId) {
          setSelectedOrder({...selectedOrder, status: newStatus});
        }
      } else {
        toast.error("Process synchronization failed");
      }
    } catch (error) {
      toast.error("Connectivity error during update");
    } finally {
      setIsUpdating(null);
    }
  };

  const handleEditOrderClick = (order: any) => {
    setEditingOrder(order);
    setEditFormData({
      customerName: order.customerName,
      customerEmail: order.customerEmail,
      customerPhone: order.customerPhone,
      address: order.address,
      deliveryZone: order.deliveryZone || "",
      deliveryCharge: order.deliveryCharge || 0
    });
  };

  const saveOrderEdit = async () => {
    if (!editingOrder) return;
    setIsUpdating(editingOrder._id);
    try {
      const response = await fetch(`/api/orders/${editingOrder._id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editFormData)
      });

      if (response.ok) {
        toast.success("Client archives updated");
        setEditingOrder(null);
        fetchAllOrders();
      } else {
        toast.error("Data persistence error");
      }
    } catch (error) {
      toast.error("Network instability detected");
    } finally {
      setIsUpdating(null);
    }
  };

  const deleteOrder = async (orderId: string) => {
    if (!confirm("Caution: Are you sure you wish to purge this transaction record? This action is irreversible.")) return;
    
    setIsUpdating(orderId);
    try {
      const response = await fetch(`/api/orders/${orderId}`, {
        method: "DELETE"
      });

      if (response.ok) {
        toast.success("Record purged from ledger");
        fetchAllOrders();
        if (selectedOrder && selectedOrder._id === orderId) setSelectedOrder(null);
      } else {
        toast.error("Administrative bypass rejected");
      }
    } catch (error) {
      toast.error("Deletion protocol interrupted");
    } finally {
      setIsUpdating(null);
    }
  };

  const filteredOrders = useMemo(() => {
    let orders = allOrders.filter(order => 
      (order.orderNumber || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (order.customerName || "").toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    if (dateFilter) {
      orders = orders.filter(order => {
        const orderDate = new Date(order.createdAt).toISOString().slice(0, 10);
        return orderDate === dateFilter;
      });
    }
    
    return orders;
  }, [allOrders, searchQuery, dateFilter]);

  const groupedOrders = useMemo(() => {
    const groups: { label: string; orders: any[] }[] = [];
    const dateMap = new Map<string, any[]>();
    
    filteredOrders.forEach(order => {
      const key = getDateSortKey(order.createdAt);
      if (!dateMap.has(key)) {
        dateMap.set(key, []);
      }
      dateMap.get(key)!.push(order);
    });

    dateMap.forEach((orders, dateKey) => {
      groups.push({
        label: formatDateKey(orders[0].createdAt),
        orders
      });
    });

    return groups.sort((a, b) => new Date(b.orders[0].createdAt).getTime() - new Date(a.orders[0].createdAt).getTime());
  }, [filteredOrders]);

  const totalRevenue = filteredOrders.reduce((s, o) => s + (o.totalAmount || 0), 0);
  const totalDeliveryFees = filteredOrders.reduce((s, o) => s + (o.deliveryCharge || 0), 0);

  return (
    <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="space-y-8 pb-12">
      {/* Premium Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-1">
        <div className="space-y-1.5 outline-none">
          <div className="flex items-center gap-2 mb-2">
            <div className="bg-indigo-600 h-2 w-8 rounded-full" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-500">Operation Center</span>
          </div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tighter">Order Fulfillment</h2>
          <p className="text-slate-400 font-bold max-w-lg">Monitor, audit, and manage your global transaction flow with real-time analytics.</p>
        </div>
        
        <div className="flex gap-3">
          <Button onClick={fetchAllOrders} disabled={isDataLoading} variant="outline" className="h-12 rounded-2xl border-slate-100 bg-white font-black text-xs uppercase tracking-widest hover:bg-slate-50 shadow-sm transition-all group">
            {isDataLoading ? <Loader2 className="h-3 w-3 animate-spin mr-2" /> : <History className="h-3 w-3 mr-2 group-hover:rotate-180 transition-transform duration-500" />}
            Sync Reports
          </Button>
        </div>
      </div>

      {/* Analytics Dashboard Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 px-1">
        <motion.div whileHover={{ y: -5 }} className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform">
            <Receipt className="h-16 w-16 text-indigo-900" />
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Total Volume</p>
          <div className="flex items-end gap-2">
            <p className="text-3xl font-black text-slate-900">{filteredOrders.length}</p>
            <span className="text-[10px] font-bold text-emerald-500 mb-1 flex items-center bg-emerald-50 px-1.5 py-0.5 rounded-lg">
              <ArrowUpRight className="h-3 w-3" /> 12%
            </span>
          </div>
          <p className="text-[10px] font-bold text-slate-400 mt-2 italic">Active transaction count</p>
        </motion.div>

        <motion.div whileHover={{ y: -5 }} className="bg-gradient-to-br from-slate-900 to-indigo-950 rounded-[2.5rem] p-6 shadow-xl shadow-indigo-100 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
            <Wallet className="h-16 w-16 text-white" />
          </div>
          <p className="text-[10px] font-black text-indigo-300 uppercase tracking-[0.2em] mb-4">Gross Revenue</p>
          <p className="text-3xl font-black text-white">৳{totalRevenue.toLocaleString()}</p>
          <p className="text-[10px] font-bold text-indigo-300/60 mt-2 italic">Combined aggregate total</p>
        </motion.div>

        <motion.div whileHover={{ y: -5 }} className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:-rotate-12 transition-transform">
            <Truck className="h-16 w-16 text-indigo-900" />
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Logistics Yield</p>
          <p className="text-3xl font-black text-indigo-600">৳{totalDeliveryFees.toLocaleString()}</p>
          <p className="text-[10px] font-bold text-slate-400 mt-2 italic">Shipping & service fees</p>
        </motion.div>

        <motion.div whileHover={{ y: -5 }} className="bg-indigo-50 border border-indigo-100 rounded-[2.5rem] p-6 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-125 transition-transform duration-700">
            <BadgeDollarSign className="h-16 w-16 text-indigo-900" />
          </div>
          <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] mb-4">Profit Margin</p>
          <p className="text-3xl font-black text-indigo-700">৳{(totalRevenue - totalDeliveryFees).toLocaleString()}</p>
          <p className="text-[10px] font-bold text-indigo-400 mt-2 italic">Net asset accumulation</p>
        </motion.div>
      </div>

      {/* Advanced Control Row */}
      <div className="flex flex-col lg:flex-row gap-4 px-1 sticky top-0 z-20 bg-[#fdfdfd]/80 backdrop-blur-md py-2 -mx-1">
        <div className="relative group flex-1">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
          <Input 
            placeholder="Filter by Transaction ID or Client Name..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-14 h-14 bg-white rounded-[1.5rem] border-transparent focus:ring-2 focus:ring-indigo-100 shadow-sm text-sm font-black transition-all placeholder:font-bold placeholder:text-slate-300"
          />
        </div>
        <div className="flex gap-2">
          <div className="relative group">
            <CalendarDays className="absolute left-5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors pointer-events-none" />
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="h-14 pl-14 pr-6 bg-white rounded-[1.5rem] border-none shadow-sm text-xs font-black uppercase tracking-widest hover:bg-slate-50 transition-all focus:ring-2 focus:ring-indigo-100 outline-none text-slate-700 appearance-none cursor-pointer min-w-[220px]"
            />
          </div>
          {dateFilter && (
            <Button 
              variant="outline" 
              onClick={() => setDateFilter("")} 
              className="h-14 rounded-[1.5rem] bg-rose-50 border-none text-rose-500 font-black px-6 hover:bg-rose-100 transition-all text-xs uppercase"
            >
              Reset
            </Button>
          )}
        </div>
      </div>

      {/* Grouped Fulfillment Ledger */}
      <div className="space-y-10">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-4">
            <Loader2 className="animate-spin h-12 w-12 text-indigo-600 opacity-20" />
            <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-300">Synchronizing Ledger...</p>
          </div>
        ) : groupedOrders.length === 0 ? (
          <div className="bg-white rounded-[3rem] p-20 shadow-sm border border-slate-100 text-center space-y-6">
            <div className="bg-slate-50 h-24 w-24 rounded-full flex items-center justify-center mx-auto">
              <History className="h-10 w-10 text-slate-200" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-black text-slate-800">No Records Discovered</h3>
              <p className="text-slate-400 font-bold text-sm max-w-xs mx-auto">Our database could not verify any fulfillment records matching your criteria.</p>
            </div>
            <Button onClick={() => {setSearchQuery(""); setDateFilter("");}} className="h-12 rounded-2xl bg-indigo-600 hover:bg-black font-black text-xs uppercase tracking-widest text-white px-8">Refresh Index</Button>
          </div>
        ) : groupedOrders.map((group) => (
          <motion.div 
            key={group.label}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between px-4">
               <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-2xl bg-indigo-50 flex items-center justify-center border border-indigo-100 shadow-inner">
                    <Calendar className="h-4 w-4 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-800 tracking-tight">{group.label}</h3>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Batch: {group.orders.length} Fulfillment Units</p>
                  </div>
               </div>
               <div className="text-right">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Yield Aggregate</p>
                  <p className="text-xl font-black text-slate-900">৳{group.orders.reduce((s: number, o: any) => s + (o.totalAmount || 0), 0).toLocaleString()}</p>
               </div>
            </div>

            <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left align-middle border-collapse">
                  <thead className="bg-slate-50/50">
                    <tr className="text-[9px] text-slate-400 font-black uppercase tracking-[0.25em] border-b border-slate-100">
                      <th className="px-8 py-5">Trace Reference</th>
                      <th className="px-8 py-5">Client Profile</th>
                      <th className="px-8 py-5">Financial Details</th>
                      <th className="px-8 py-5">Logistics</th>
                      <th className="px-8 py-5">Process Stage</th>
                      <th className="px-8 py-5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {group.orders.map((order: any) => (
                      <motion.tr 
                        key={order._id} 
                        whileHover={{ backgroundColor: "rgba(248, 250, 252, 0.5)" }}
                        className="group transition-all"
                      >
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-3">
                            <button 
                              onClick={() => setSelectedOrder(order)}
                              className="font-black text-indigo-600 hover:text-black transition-colors text-sm underline decoration-indigo-200 decoration-2 underline-offset-4"
                            >
                              {order.orderNumber}
                            </button>
                            <span className="text-[9px] font-black text-slate-300 uppercase">{new Date(order.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                            <p className="font-black text-slate-900 text-sm leading-tight">{order.customerName}</p>
                            <div className="flex items-center gap-1.5 mt-1">
                              <div className="h-1 w-1 rounded-full bg-slate-300" />
                              <p className="text-[10px] text-slate-400 font-bold lowercase tracking-wider">{order.customerPhone}</p>
                            </div>
                        </td>
                        <td className="px-8 py-6">
                           <div className="space-y-0.5">
                              <p className="font-black text-slate-900">৳{(order.totalAmount || 0).toLocaleString()}</p>
                              {(order.discountAmount || 0) > 0 && (
                                <p className="text-[9px] text-emerald-600 font-black uppercase tracking-tighter">Savings: ৳{order.discountAmount}</p>
                              )}
                           </div>
                        </td>
                        <td className="px-8 py-6">
                           <div className="flex flex-col gap-1">
                              <div className="flex items-center gap-1.5">
                                <MapPin className="h-3 w-3 text-indigo-400" />
                                <span className="text-[11px] font-black text-slate-800">{order.location || "General"}</span>
                              </div>
                              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-4">{formatZone(order.deliveryZone)}</span>
                           </div>
                        </td>
                        <td className="px-8 py-6">
                          <Badge variant="outline" className={`${STATUS_COLORS[order.status] || ""} rounded-xl px-4 py-1.5 font-black border-none uppercase text-[9px] tracking-[0.15em] transition-all`}>
                            {order.status}
                          </Badge>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <div className="flex items-center justify-end gap-2">
                             <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => setSelectedOrder(order)}
                              className="h-10 px-4 rounded-xl font-black text-[10px] uppercase tracking-widest text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-all"
                             >
                               Inspect Record
                             </Button>
                             <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-10 w-10 rounded-xl hover:bg-slate-50 transition-all border-none">
                                    <MoreVertical className="h-4 w-4 text-slate-300" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-56 rounded-[1.5rem] p-2 border border-slate-100 shadow-2xl">
                                  <DropdownMenuItem onClick={() => handleEditOrderClick(order)} className="rounded-xl px-4 py-3 font-black text-[10px] uppercase tracking-widest flex items-center gap-3">
                                    <History className="h-3.5 w-3.5 text-slate-400" /> Archive Update
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator className="bg-slate-100" />
                                  <DropdownMenuItem onClick={() => updateOrderStatus(order._id, "In Review")} className="rounded-xl px-4 py-2.5 font-black text-[10px] uppercase tracking-widest text-sky-600 bg-sky-50">Move to Review</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => updateOrderStatus(order._id, "Shipped")} className="rounded-xl px-4 py-2.5 font-black text-[10px] uppercase tracking-widest text-indigo-600">Dispatch Unit</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => updateOrderStatus(order._id, "Delivered")} className="rounded-xl px-4 py-2.5 font-black text-[10px] uppercase tracking-widest text-emerald-600 bg-emerald-50">Mark Delivered</DropdownMenuItem>
                                  <DropdownMenuSeparator className="bg-slate-100" />
                                  <DropdownMenuItem onClick={() => updateOrderStatus(order._id, "Returned")} className="rounded-xl px-4 py-2.5 font-black text-[10px] uppercase tracking-widest text-rose-500">Mark Returned</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => updateOrderStatus(order._id, "Cancelled")} className="rounded-xl px-4 py-2.5 font-black text-[10px] uppercase tracking-widest text-rose-600 italic">Mark Cancelled</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => deleteOrder(order._id)} className="rounded-xl px-4 py-2.5 font-black text-[10px] uppercase tracking-widest text-slate-400 hover:bg-rose-50 italic">Purge Data Entry</DropdownMenuItem>
                                </DropdownMenuContent>
                             </DropdownMenu>
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Dynamic Detail Panel Overlay */}
      <Dialog open={!!selectedOrder} onOpenChange={(open) => !open && setSelectedOrder(null)}>
        <DialogContent className="sm:max-w-[700px] rounded-[3rem] p-0 overflow-hidden border-none shadow-[0_50px_100px_-20px_rgba(0,0,0,0.3)] bg-white">
          <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-10 text-white relative">
            <div className="absolute top-0 right-0 p-10 opacity-5">
               <Receipt className="h-32 w-32" />
            </div>
            <div className="relative z-10 flex items-center justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                   <div className="h-2 w-2 bg-indigo-500 rounded-full animate-pulse" />
                   <span className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-400">Transaction Profile</span>
                </div>
                <DialogTitle className="text-4xl font-black tracking-tighter">{selectedOrder?.orderNumber}</DialogTitle>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-3.5 w-3.5 text-slate-400" />
                    <span className="text-xs text-slate-300 font-bold uppercase tracking-widest">{selectedOrder ? new Date(selectedOrder.createdAt).toLocaleString() : ""}</span>
                  </div>
                  <div className="h-3 w-px bg-white/20" />
                  <span className="text-[10px] font-black uppercase text-indigo-400">Ledger Entry #{(selectedOrder?._id || "").slice(-8)}</span>
                </div>
              </div>
              <div className="text-right space-y-3">
                 <Badge className={`${STATUS_COLORS[selectedOrder?.status] || ""} border-none font-black px-6 py-2.5 rounded-2xl uppercase text-[10px] tracking-widest`}>
                  {selectedOrder?.status}
                 </Badge>
              </div>
            </div>
          </div>
          
          <div className="p-10 space-y-10 max-h-[65vh] overflow-y-auto custom-scrollbar bg-[#fdfdfd]">
            {/* Grid Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-indigo-600">
                    <User className="h-5 w-5" />
                    <span className="text-[10px] font-black uppercase tracking-[0.3em]">Client Credentials</span>
                  </div>
                  <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Name</p>
                      <p className="font-extrabold text-slate-900 text-lg leading-none">{selectedOrder?.customerName}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Contact</p>
                        <p className="text-sm font-bold text-slate-700">{selectedOrder?.customerPhone}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Email</p>
                        <p className="text-sm font-bold text-slate-700 truncate">{selectedOrder?.customerEmail || "N/A"}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                 <div className="space-y-4">
                  <div className="flex items-center gap-3 text-indigo-600">
                    <Truck className="h-5 w-5" />
                    <span className="text-[10px] font-black uppercase tracking-[0.3em]">Logistics Payload</span>
                  </div>
                  <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-5">
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Delivery Coordinates</p>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-3.5 w-3.5 text-indigo-500" />
                        <p className="font-extrabold text-slate-900">{selectedOrder?.location || "Metro Area"}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Mailing Address</p>
                      <p className="text-xs font-bold text-slate-500 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100 italic">{selectedOrder?.address}</p>
                    </div>
                    {selectedOrder?.trackingCode && (
                      <div className="pt-2 border-t border-slate-100">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-1.5 grayscale opacity-60">
                            <Truck className="h-3.5 w-3.5" />
                            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Logistics Status</p>
                          </div>
                          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border transition-all shadow-sm ${
                            isSteadfastLoading 
                              ? "bg-slate-50 text-slate-400 border-slate-100" 
                              : (STEADFAST_STATUS_THEMES[Object.keys(STEADFAST_STATUS_MAP).find(k => STEADFAST_STATUS_MAP[k] === steadfastStatus) || ""] || "bg-indigo-50 text-indigo-600 border-indigo-100")
                          }`}>
                            {isSteadfastLoading && <Loader2 className="h-3 w-3 animate-spin" />}
                            <span className="text-[10px] font-black uppercase tracking-widest whitespace-nowrap">
                              {isSteadfastLoading ? "SYNCING..." : (steadfastStatus || "UNKNOWN")}
                            </span>
                            {!isSteadfastLoading && (
                              <button 
                                onClick={() => fetchSteadfastStatus(selectedOrder._id)}
                                className="ml-1 hover:rotate-180 transition-transform duration-500 opacity-60 hover:opacity-100 p-0.5"
                                title="Force sync from courier"
                              >
                                <RefreshCw className="h-3 w-3" />
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-slate-50/50 p-4 rounded-2xl border border-slate-100/50">
                          <div className="space-y-1">
                            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Tracking Code</p>
                            <div className="flex flex-col gap-1.5">
                              <p className="text-sm font-black text-slate-800 break-all tabular-nums">{selectedOrder.trackingCode}</p>
                              <a 
                                href={`https://steadfast.com.bd/t/${selectedOrder.trackingCode}`}
                                target="_blank" 
                                rel="noreferrer"
                                className="inline-flex items-center gap-1 text-[9px] font-black text-indigo-600 uppercase tracking-widest hover:text-black transition-colors"
                              >
                                View Portal <ArrowUpRight className="h-3 w-3" />
                              </a>
                            </div>
                          </div>
                          <div className="space-y-1">
                            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Consignment ID</p>
                            <p className="text-sm font-black text-slate-800 tabular-nums">{selectedOrder.consignmentId}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Itemized Inventory List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-indigo-600">
                  <Package className="h-5 w-5" />
                  <span className="text-[10px] font-black uppercase tracking-[0.3em]">Consignment Manifest</span>
                </div>
                <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{(selectedOrder?.items || []).length} Units</span>
              </div>
              
              <div className="space-y-3">
                {(selectedOrder?.items || []).map((item: any, idx: number) => (
                  <div key={item._id || idx} className="flex items-center justify-between p-4 rounded-3xl bg-white border border-slate-100 shadow-sm transition-all hover:border-indigo-200">
                    <div className="flex items-center gap-4">
                      <div className="bg-indigo-600 h-10 w-10 rounded-2xl flex items-center justify-center font-black text-white text-xs shadow-lg shadow-indigo-100">
                        {item.quantity}
                      </div>
                      <div>
                        <p className="font-black text-slate-900 text-sm leading-tight">{item.title}</p>
                        {item.variant && (
                          <Badge className="bg-indigo-50 text-indigo-500 text-[8px] uppercase tracking-widest py-0.5 mt-1 font-black border-none px-2">
                            {item.variant}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-black text-slate-900">৳{((item.price || 0) * (item.quantity || 0)).toLocaleString()}</p>
                      <p className="text-[9px] text-slate-400 font-black uppercase tracking-tighter">৳{item.price} per Unit</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Summary & Processing */}
            <div className="bg-slate-900/5 p-8 rounded-[3rem] border border-slate-100 space-y-6">
               <div className="flex items-center gap-3 text-indigo-600 mb-2">
                  <Receipt className="h-5 w-5" />
                  <span className="text-[10px] font-black uppercase tracking-[0.3em]">Transaction Audit</span>
               </div>
               <div className="space-y-4">
                  <div className="flex justify-between items-center text-xs font-bold text-slate-500">
                    <span>Gross Subtotal</span>
                    <span className="text-slate-800">৳{((selectedOrder?.items || []).reduce((sum: number, item: any) => sum + ((item.price || 0) * (item.quantity || 0)), 0)).toLocaleString()}</span>
                  </div>
                  
                  {(selectedOrder?.discountAmount || 0) > 0 && (
                    <div className="flex justify-between items-center text-xs font-black text-emerald-600">
                      <span className="flex items-center gap-2 uppercase tracking-widest">
                        <SparklesIcon /> Applied Discounts
                      </span>
                      <span>-৳{(selectedOrder?.discountAmount || 0).toLocaleString()}</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center text-xs font-black text-indigo-600 bg-indigo-50 -mx-4 px-4 py-3 rounded-2xl border border-indigo-100 outline-none">
                    <span className="flex items-center gap-2 uppercase tracking-widest">
                      <Truck className="h-4 w-4" /> Logistics Adjustment
                    </span>
                    <span className="text-base font-black">৳{(selectedOrder?.deliveryCharge || 0).toLocaleString()}</span>
                  </div>

                  <hr className="border-slate-200 border-dashed" />

                  <div className="flex justify-between items-center pt-2">
                    <div className="space-y-0.5">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Final Net Total</p>
                      <p className="text-4xl font-black text-slate-900 tracking-tighter">৳{(selectedOrder?.totalAmount || 0).toLocaleString()}</p>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] font-black text-emerald-500 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-100 uppercase tracking-widest">Verified Payment</p>
                    </div>
                  </div>
               </div>
            </div>
          </div>
          
          <div className="p-10 border-t border-slate-100 bg-white flex gap-4">
            <Button variant="ghost" onClick={() => setSelectedOrder(null)} className="flex-1 h-14 rounded-[1.5rem] bg-slate-50 font-black text-xs uppercase tracking-[0.2em] text-slate-400 hover:bg-slate-100 transition-all">
              Dismiss Archive
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="flex-1 h-14 bg-slate-900 hover:bg-black rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] text-white gap-3 shadow-xl transition-all">
                  Update Lifecycle Stage
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="rounded-[1.5rem] p-2 border-none shadow-[0_30px_60px_-15px_rgba(0,0,0,0.2)] w-64 mb-2">
                <DropdownMenuItem onClick={() => selectedOrder && updateOrderStatus(selectedOrder._id, "Pending")} className="rounded-xl px-5 py-3 font-black text-[10px] uppercase tracking-widest">Restore Pending</DropdownMenuItem>
                <DropdownMenuItem onClick={() => selectedOrder && updateOrderStatus(selectedOrder._id, "In Review")} className="rounded-xl px-5 py-3 font-black text-[10px] uppercase tracking-widest text-sky-600 bg-sky-50">Move to Review</DropdownMenuItem>
                <DropdownMenuItem onClick={() => selectedOrder && updateOrderStatus(selectedOrder._id, "Shipped")} className="rounded-xl px-5 py-3 font-black text-[10px] uppercase tracking-widest text-indigo-600">Authorize Dispatch</DropdownMenuItem>
                <DropdownMenuItem onClick={() => selectedOrder && updateOrderStatus(selectedOrder._id, "Delivered")} className="rounded-xl px-5 py-3 font-black text-[10px] uppercase tracking-widest text-emerald-600 bg-emerald-50">Mark Delivered</DropdownMenuItem>
                <DropdownMenuSeparator className="bg-slate-100 mx-2" />
                <DropdownMenuItem onClick={() => selectedOrder && updateOrderStatus(selectedOrder._id, "Returned")} className="rounded-xl px-5 py-3 font-black text-[10px] uppercase tracking-widest text-rose-500">Mark Returned</DropdownMenuItem>
                <DropdownMenuItem onClick={() => selectedOrder && updateOrderStatus(selectedOrder._id, "Cancelled")} className="rounded-xl px-5 py-3 font-black text-[10px] uppercase tracking-widest text-rose-600 italic">Mark Cancelled</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modernized Archive Editor */}
      <Dialog open={!!editingOrder} onOpenChange={(open) => !open && setEditingOrder(null)}>
        <DialogContent className="sm:max-w-[550px] rounded-[3rem] p-0 overflow-hidden border-none shadow-2xl bg-white">
          <div className="bg-slate-900 p-10 text-white space-y-2">
             <div className="h-1 w-12 bg-indigo-500 rounded-full mb-4" />
             <DialogTitle className="text-3xl font-black tracking-tight">Record Modification</DialogTitle>
             <DialogDescription className="text-slate-400 font-bold uppercase text-[10px] tracking-widest">Synchronizing Client Archives: {editingOrder?.orderNumber}</DialogDescription>
          </div>
          <div className="p-10 space-y-6 bg-slate-50/50">
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] ml-1">Client Identifier</Label>
              <Input 
                value={editFormData.customerName} 
                onChange={(e) => setEditFormData({...editFormData, customerName: e.target.value})}
                className="h-14 rounded-2xl bg-white border-transparent shadow-sm font-black text-sm px-6 py-2 transition-all focus:ring-2 focus:ring-indigo-100"
                placeholder="Name"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] ml-1">Sync Email</Label>
                <Input 
                  value={editFormData.customerEmail} 
                  onChange={(e) => setEditFormData({...editFormData, customerEmail: e.target.value})}
                  className="h-14 rounded-2xl bg-white border-transparent shadow-sm font-black text-sm px-6"
                  placeholder="Email"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] ml-1">Sync Reach</Label>
                <Input 
                  value={editFormData.customerPhone} 
                  onChange={(e) => setEditFormData({...editFormData, customerPhone: e.target.value})}
                  className="h-14 rounded-2xl bg-white border-transparent shadow-sm font-black text-sm px-6"
                  placeholder="Phone"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] ml-1">Logistics coordinates</Label>
              <Input 
                value={editFormData.address} 
                onChange={(e) => setEditFormData({...editFormData, address: e.target.value})}
                className="h-14 rounded-2xl bg-white border-transparent shadow-sm font-bold text-sm px-6"
                placeholder="Full Shipping Address"
              />
            </div>
          </div>
          <div className="p-10 border-t border-slate-100 flex gap-4 bg-white">
            <Button variant="ghost" onClick={() => setEditingOrder(null)} className="flex-1 h-14 rounded-[1.5rem] bg-slate-50 font-black text-xs uppercase tracking-widest text-slate-400">Abort Changes</Button>
            <Button onClick={saveOrderEdit} disabled={!!isUpdating} className="flex-1 h-14 bg-indigo-600 hover:bg-black text-white rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] shadow-lg shadow-indigo-100 transition-all">Commit Archives</Button>
          </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}

function SparklesIcon() {
  return (
    <svg className="h-3.5 w-3.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
      <path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/>
    </svg>
  );
}
