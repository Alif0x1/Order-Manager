import React, { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Package, Search, Plus, Edit3, Trash2, Loader2, X, Archive, Box, Layers, BarChart3, Database, Globe2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

interface Product {
  _id?: string;
  handle: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  vendor: string;
  category: string;
  status: string;
  stock?: number;
  options?: Array<{ name: string; values: string[] }>;
  variantStock?: Record<string, number>;
}

export default function InventoryManager() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDataLoading, setIsDataLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isUpdating, setIsUpdating] = useState<string | null>(null);

  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [variantInput, setVariantInput] = useState("");
  const [productFormData, setProductFormData] = useState<Product>({
    handle: "",
    title: "",
    price: 0,
    compareAtPrice: 0,
    imageSrc: "",
    vendor: "Online lifestyle",
    category: "General",
    status: "active",
    stock: 0,
    options: [{ name: "Variant", values: [] }],
    variantStock: {}
  });

  useEffect(() => {
    fetchAllProducts();
  }, []);

  const fetchAllProducts = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/products?all=true");
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
    } catch (error) {
      toast.error("Cloud synchronization failed");
    } finally {
      setIsLoading(false);
      setIsDataLoading(false);
    }
  };

  const handleProductSubmit = async () => {
    setIsDataLoading(true);
    const method = editingProduct ? "PATCH" : "POST";
    const url = editingProduct ? `/api/products/${editingProduct._id}` : "/api/products";
    
    const finalData = { 
      ...productFormData,
      options: productFormData.options?.map(opt => ({
        name: opt.name,
        values: opt.values
      })) || [],
      stock: productFormData.stock || 0,
       variantStock: productFormData.variantStock || {}
    };
    if (!finalData.handle) finalData.handle = finalData.title.toLowerCase().replace(/ /g, "-");
    
    if (!editingProduct) {
      delete (finalData as any)._id;
    }

    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(finalData)
      });

      if (response.ok) {
        toast.success(`Asset ${editingProduct ? "re-initialized" : "provisioned"} successfully!`);
        setIsProductModalOpen(false);
        fetchAllProducts();
      } else {
        toast.error("Integrity error during save");
      }
    } catch (error) {
      toast.error("Server protocol violation");
    } finally {
      setIsDataLoading(false);
    }
  };

  const deleteProduct = async (productId: string) => {
    if (!confirm("Attention: Decommissioning this asset is irreversible. Proceed?")) return;
    setIsUpdating(productId);
    try {
      const response = await fetch(`/api/products/${productId}`, { method: "DELETE" });
      if (response.ok) {
        toast.success("Asset decommissioned from archives");
        fetchAllProducts();
      }
    } catch (error) {
      toast.error("Decommissioning sequence failed");
    } finally {
      setIsUpdating(null);
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    const cleanedProduct: Product = {
      ...product,
      stock: product.stock || 0,
      options: product.options?.map(opt => ({
        name: opt.name,
        values: [...opt.values]
      })) || [{ name: "Variant", values: [] }],
      variantStock: product.variantStock ? { ...product.variantStock } : {}
    };
    setProductFormData(cleanedProduct);
    setVariantInput("");
    setIsProductModalOpen(true);
  };

  const openAddProduct = () => {
    setEditingProduct(null);
    setProductFormData({
      handle: "",
      title: "",
      price: 0,
      compareAtPrice: 0,
      imageSrc: "",
      vendor: "Online lifestyle",
      category: "General",
      status: "active",
      stock: 0,
      options: [{ name: "Variant", values: [] }],
      variantStock: {}
    });
    setVariantInput("");
    setIsProductModalOpen(true);
  };

  const addVariantValue = () => {
    const trimmed = variantInput.trim();
    if (!trimmed) return;
    const currentOptions = productFormData.options || [];
    const currentOpt = currentOptions[0] || { name: "Variant", values: [] };
    
    if (currentOpt.values.includes(trimmed)) {
      toast.error("Instance already indexed");
      return;
    }
    
    const newOptions = [{
      name: currentOpt.name,
      values: [...currentOpt.values, trimmed]
    }];
    const newVarStock = { ...(productFormData.variantStock || {}), [trimmed]: 0 };
    setProductFormData({ ...productFormData, options: newOptions, variantStock: newVarStock });
    setVariantInput("");
  };

  const removeVariantValue = (val: string) => {
    const currentOptions = productFormData.options || [];
    const currentOpt = currentOptions[0] || { name: "Variant", values: [] };
    
    const newOptions = [{
      name: currentOpt.name,
      values: currentOpt.values.filter(v => v !== val)
    }];
    const newVarStock = { ...(productFormData.variantStock || {}) };
    delete newVarStock[val];
    setProductFormData({ ...productFormData, options: newOptions, variantStock: newVarStock });
  };

  const updateVariantStock = (variant: string, stock: number) => {
    const newVarStock = { ...(productFormData.variantStock || {}), [variant]: stock };
    setProductFormData({ ...productFormData, variantStock: newVarStock });
  };

  const getStockColor = (stock: number) => {
    if (stock <= 0) return "bg-rose-50 text-rose-600 border-rose-100";
    if (stock <= 5) return "bg-amber-50 text-amber-600 border-amber-100";
    return "bg-emerald-50 text-emerald-600 border-emerald-100";
  };

  const getStockLabel = (stock: number) => {
    if (stock <= 0) return "Depleted";
    if (stock <= 5) return `Critical: ${stock}`;
    return `Available: ${stock}`;
  };

  const filteredProducts = products.filter(p => 
    (p.title || "").toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} className="space-y-8 pb-12">
      {/* Premium Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-1">
        <div className="space-y-1.5 outline-none">
          <div className="flex items-center gap-2 mb-2">
            <div className="bg-indigo-600 h-2 w-8 rounded-full" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-500">Asset Management</span>
          </div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tighter">Inventory Ledger</h2>
          <p className="text-slate-400 font-bold max-w-lg">Manage global SKU assets, monitor stock velocity, and provision new inventory units.</p>
        </div>
        
        <Button onClick={openAddProduct} className="bg-slate-900 hover:bg-black text-white rounded-2xl h-14 px-8 font-black text-xs uppercase tracking-widest shadow-xl shadow-slate-200 transition-all flex items-center gap-3">
          <div className="bg-white/10 p-1.5 rounded-lg">
            <Plus className="h-4 w-4" />
          </div>
          Provision Asset
        </Button>
      </div>

      {/* Analytics Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 px-1">
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100 flex items-center gap-6">
          <div className="h-16 w-16 bg-indigo-50 rounded-[1.5rem] flex items-center justify-center border border-indigo-100">
             <Layers className="h-8 w-8 text-indigo-600" />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Index count</p>
            <p className="text-3xl font-black text-slate-900">{products.length} SKUs</p>
          </div>
        </div>
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100 flex items-center gap-6">
          <div className="h-16 w-16 bg-emerald-50 rounded-[1.5rem] flex items-center justify-center border border-emerald-100">
             <BarChart3 className="h-8 w-8 text-emerald-600" />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Active Assets</p>
            <p className="text-3xl font-black text-slate-900">{products.filter(p => p.status === 'active').length} units</p>
          </div>
        </div>
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-slate-100 flex items-center gap-6">
          <div className="h-16 w-16 bg-amber-50 rounded-[1.5rem] flex items-center justify-center border border-amber-100">
             <Box className="h-8 w-8 text-amber-600" />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Low-Stock alerts</p>
            <p className="text-3xl font-black text-slate-900">{products.filter(p => (p.stock || 0) <= 5).length} items</p>
          </div>
        </div>
      </div>

      <div className="relative group max-w-xl px-1">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
        <Input 
          placeholder="Filter SKU Index by title or handle..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-14 h-16 bg-white rounded-[1.5rem] border-transparent focus:ring-2 focus:ring-indigo-100 shadow-sm text-sm font-black transition-all placeholder:text-slate-300 uppercase tracking-widest"
        />
      </div>

      <Card className="border-none shadow-sm rounded-[3rem] overflow-hidden bg-white">
        <CardHeader className="px-10 py-10 bg-slate-50/50">
          <div className="flex items-center justify-between">
            <div className="space-y-1.5">
              <div className="flex items-center gap-3">
                <Globe2 className="h-5 w-5 text-indigo-600" />
                <CardTitle className="text-2xl font-black text-slate-900 tracking-tight">Global Inventory Manifest</CardTitle>
              </div>
              <CardDescription className="text-xs font-bold text-slate-400 uppercase tracking-widest leading-none">Status Audit & Fulfillment Readiness</CardDescription>
            </div>
            <div className="bg-white px-5 py-2 rounded-2xl border border-slate-100 shadow-sm">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{filteredProducts.length} Entries indexed</span>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-8">
            {isLoading ? (
               <div className="col-span-full py-32 flex flex-col items-center gap-4">
                  <Loader2 className="animate-spin h-10 w-10 text-indigo-600 opacity-20" />
                  <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-300">Filtering index records...</p>
               </div>
            ) : filteredProducts.length === 0 ? (
              <div className="col-span-full py-32 text-center space-y-4">
                  <div className="h-16 w-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto">
                    <Archive className="h-8 w-8 text-slate-200" />
                  </div>
                  <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest">No matching assets discovered.</p>
              </div>
            ) : filteredProducts.map((product: Product) => {
              const totalStock = product.stock || 0;
              const variantStock = product.variantStock || {};
              const hasVariants = product.options?.[0]?.values && product.options[0].values.length > 0;

              return (
                <motion.div 
                  key={product._id} 
                  layout
                  className="group bg-white rounded-[2.5rem] border border-slate-100 overflow-hidden shadow-sm hover:shadow-2xl hover:shadow-indigo-50 hover:-translate-y-2 transition-all duration-500 flex flex-col"
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-slate-50 shrink-0">
                    <img src={product.imageSrc} alt={product.title} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-1000" />
                    <div className="absolute inset-0 bg-black/5 group-hover:bg-transparent transition-colors" />
                    
                    <div className="absolute top-4 left-4 flex flex-col gap-2">
                       <Badge className={`border px-3 py-1.5 rounded-xl text-[9px] font-black tracking-widest shadow-lg ${getStockColor(totalStock)}`}>
                        {getStockLabel(totalStock)}
                      </Badge>
                    </div>
                    <Badge className="absolute bottom-4 right-4 bg-white/90 text-slate-900 border-none backdrop-blur-md shadow-xl px-3 py-1.5 rounded-xl uppercase text-[9px] font-black tracking-[0.1em]">{product.status}</Badge>
                  </div>

                  <div className="p-7 flex flex-col flex-1 space-y-5">
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.25em]">{product.vendor || 'Global Asset'}</p>
                      <h4 className="font-extrabold text-slate-800 line-clamp-1 text-lg tracking-tight group-hover:text-indigo-600 transition-colors uppercase">{product.title}</h4>
                    </div>

                    <div className="flex items-center justify-between">
                       <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-black text-slate-900 tracking-tighter">৳{(product.price || 0).toLocaleString()}</span>
                          {product.compareAtPrice && <span className="text-[10px] text-slate-300 font-bold line-through">৳{product.compareAtPrice.toLocaleString()}</span>}
                        </div>
                        <div className="text-right">
                           <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Asset Valuation</p>
                        </div>
                    </div>
                    
                    {hasVariants && (
                      <div className="space-y-3 pt-2">
                        <div className="flex items-center justify-between">
                           <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Instance Manifest</p>
                           <span className="text-[8px] font-black px-1.5 py-0.5 bg-slate-100 rounded text-slate-400 capitalize">{product.options![0].name}</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {product.options![0].values.map((v: string) => {
                            const vStock = (variantStock as any)[v] ?? 0;
                            return (
                              <span key={v} className={`px-2.5 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 shadow-sm border ${
                                vStock > 0 ? "bg-emerald-50 text-emerald-700 border-emerald-100" : "bg-rose-50 text-rose-500 border-rose-100"
                              }`}>
                                {v} <span className="h-1 w-1 bg-current opacity-30 rounded-full" /> {vStock}
                              </span>
                            );
                          })}
                        </div>
                      </div>
                    )}
                    {!hasVariants && <div className="flex-1 min-h-[40px]" />}

                    <div className="pt-6 flex gap-3 border-t border-slate-50 mt-auto">
                      <Button variant="outline" onClick={() => handleEditProduct(product)} className="flex-1 bg-white rounded-2xl h-12 border-slate-100 hover:border-indigo-600 hover:text-indigo-600 transition-all font-black text-[10px] uppercase tracking-widest group shadow-sm active:scale-95">
                        <Edit3 className="mr-2 h-4 w-4 text-slate-300 group-hover:text-indigo-500 transition-colors" /> Edit Audit
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => deleteProduct(product._id!)} className="h-12 w-12 rounded-2xl hover:bg-rose-50 hover:text-rose-500 text-slate-300 active:scale-95">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Asset Optimization Modal */}
      <Dialog open={isProductModalOpen} onOpenChange={setIsProductModalOpen}>
        <DialogContent className="sm:max-w-[800px] rounded-[3rem] p-0 overflow-hidden border-none shadow-2xl bg-white">
          <div className="bg-slate-900 p-10 text-white relative">
            <div className="absolute top-0 right-0 p-10 opacity-5">
               <Database className="h-32 w-32" />
            </div>
            <DialogHeader className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                 <div className="h-2 w-2 bg-indigo-500 rounded-full animate-pulse" />
                 <span className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-400">Inventory Sync Protocol</span>
              </div>
              <DialogTitle className="text-4xl font-black tracking-tighter">{editingProduct ? "Optimize SKU Asset" : "Provision New Registry"}</DialogTitle>
              <DialogDescription className="text-slate-400 font-bold text-[10px] uppercase tracking-widest pt-1">
                Establish critical parameters: pricing, variant instances, and fulfillment readiness.
              </DialogDescription>
            </DialogHeader>
          </div>
          <div className="p-10 space-y-10 max-h-[65vh] overflow-y-auto custom-scrollbar bg-[#fdfdfd]">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-8">
                <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Asset Nomenclature</Label>
                  <Input 
                    value={productFormData.title} 
                    onChange={(e) => setProductFormData({...productFormData, title: e.target.value})}
                    placeholder="Enter professional title..."
                    className="h-14 rounded-2xl bg-white border-transparent shadow-sm focus:ring-2 focus:ring-indigo-100 transition-all font-black text-sm px-6 uppercase tracking-wider"
                  />
                </div>
                <div className="grid grid-cols-2 gap-5">
                  <div className="space-y-3">
                    <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Valuation (৳)</Label>
                    <Input 
                      type="number"
                      value={productFormData.price} 
                      onChange={(e) => setProductFormData({...productFormData, price: Number(e.target.value)})}
                      className="h-14 rounded-2xl bg-white border-transparent shadow-sm focus:ring-2 focus:ring-indigo-100 transition-all font-black text-indigo-600 text-lg px-6"
                    />
                  </div>
                  <div className="space-y-3">
                    <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Comparison Index</Label>
                    <Input 
                      type="number"
                      value={productFormData.compareAtPrice} 
                      onChange={(e) => setProductFormData({...productFormData, compareAtPrice: Number(e.target.value)})}
                      className="h-14 rounded-2xl bg-white border-transparent shadow-sm focus:ring-2 focus:ring-indigo-100 transition-all text-slate-400 font-black px-6"
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Master Media Vector (URL)</Label>
                  <Input 
                    value={productFormData.imageSrc} 
                    onChange={(e) => setProductFormData({...productFormData, imageSrc: e.target.value})}
                    placeholder="Source identifier..."
                    className="h-14 rounded-2xl bg-white border-transparent shadow-sm focus:ring-2 focus:ring-indigo-100 transition-all font-bold text-xs"
                  />
                </div>
                <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">Consolidated Unit Count</Label>
                  <Input 
                    type="number"
                    value={productFormData.stock ?? 0} 
                    onChange={(e) => setProductFormData({...productFormData, stock: Number(e.target.value)})}
                    placeholder="0"
                    className="h-14 rounded-2xl bg-white border-transparent shadow-sm focus:ring-2 focus:ring-indigo-100 transition-all font-black text-emerald-600 text-lg px-6"
                  />
                </div>
              </div>

              <div className="space-y-8">
                <div className="bg-indigo-50/50 p-6 rounded-[2rem] border border-indigo-100 space-y-6">
                  <div className="space-y-3">
                    <Label className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-400">Variant Categorization</Label>
                    <Input 
                      value={productFormData.options?.[0]?.name || "Variant"} 
                      onChange={(e) => {
                        const currentOpt = productFormData.options?.[0] || { name: "", values: [] };
                        setProductFormData({
                          ...productFormData, 
                          options: [{ name: e.target.value, values: [...currentOpt.values] }]
                        });
                      }}
                      className="h-11 rounded-xl bg-white border-transparent shadow-sm font-black text-[10px] uppercase tracking-widest px-4 focus:ring-2 focus:ring-indigo-200"
                    />
                  </div>
                  <div className="space-y-4">
                    <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-400">Instance Registry</Label>
                    <div className="flex flex-wrap gap-2 p-4 min-h-16 rounded-2xl bg-white border border-indigo-100 shadow-inner">
                      {productFormData.options?.[0]?.values.map(val => (
                        <Badge key={val} className="px-3 py-1.5 bg-indigo-600 text-white border-none rounded-xl flex items-center gap-2 font-black text-[9px] uppercase tracking-widest shadow-md">
                          {val}
                          <button type="button" className="h-4 w-4 bg-white/20 rounded-md hover:bg-white/40 flex items-center justify-center transition-all" onClick={() => removeVariantValue(val)}>
                            <X className="h-2.5 w-2.5" />
                          </button>
                        </Badge>
                      ))}
                      {(!productFormData.options?.[0]?.values || productFormData.options[0].values.length === 0) && (
                        <span className="text-[9px] text-indigo-300 flex items-center italic uppercase font-black">No instances recorded...</span>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Input 
                        value={variantInput}
                        onChange={(e) => setVariantInput(e.target.value)}
                        placeholder="Log new variant instance..." 
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            addVariantValue();
                          }
                        }}
                        className="h-12 rounded-xl bg-white border-transparent focus:ring-2 focus:ring-indigo-100 flex-1 font-bold text-xs"
                      />
                      <Button 
                        type="button" 
                        onClick={addVariantValue}
                        disabled={!variantInput.trim()}
                        className="h-12 w-12 rounded-xl bg-slate-900 hover:bg-black text-white shadow-lg active:scale-95 transition-all"
                      >
                        <Plus className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>

                  {/* Per-Variant Stock Matrix */}
                  {productFormData.options?.[0]?.values && productFormData.options[0].values.length > 0 && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="space-y-3 pt-2">
                      <Label className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-400">Fulfillment Thresholds</Label>
                      <div className="space-y-2 max-h-48 overflow-y-auto no-scrollbar py-1">
                        {productFormData.options[0].values.map(val => (
                          <div key={val} className="flex items-center justify-between gap-4 bg-white p-3 rounded-2xl border border-indigo-50 shadow-sm">
                            <span className="text-[10px] font-black text-slate-700 uppercase tracking-widest truncate flex-1">{val}</span>
                            <Input 
                              type="number"
                              value={productFormData.variantStock?.[val] ?? 0}
                              onChange={(e) => updateVariantStock(val, Number(e.target.value))}
                              className="w-24 h-9 rounded-xl text-center font-black text-indigo-600 bg-indigo-50/50 border-transparent focus:bg-white"
                            />
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="p-10 border-t border-slate-100 flex gap-4 bg-white">
            <Button variant="ghost" onClick={() => setIsProductModalOpen(false)} className="flex-1 h-14 rounded-[1.5rem] bg-slate-50 font-black text-xs uppercase tracking-widest text-slate-400 hover:bg-slate-100 transition-all">Abort Provisioning</Button>
            <Button onClick={handleProductSubmit} disabled={isDataLoading} className="flex-1 h-14 bg-indigo-600 hover:bg-black text-white rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] shadow-[0_20px_40px_-10px_rgba(79,70,229,0.3)] transition-all">
              {isDataLoading ? <Loader2 className="animate-spin h-5 w-5" /> : (editingProduct ? "Update Asset Ledger" : "Release Inventory Asset")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
