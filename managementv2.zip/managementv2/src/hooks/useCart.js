import React, { createContext, useContext, useState, useEffect, useMemo } from "react";
import { toast } from "sonner";

/**
 * simpleCart.js - High-Fidelity Global Cart Context
 * Provides a unified order state across the entire administrative ecosystem.
 */

const CartContext = createContext();

export function CartProvider({ children }) {
  const [items, setItems] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("cart_items");
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });

  const [appliedCoupon, setAppliedCoupon] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("applied_coupon");
      return saved ? JSON.parse(saved) : null;
    }
    return null;
  });

  const [discount, setDiscount] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("cart_discount");
      return saved ? Number(saved) : 0;
    }
    return 0;
  });

  const [selectedLocation, setSelectedLocation] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("selected_location") || "";
    }
    return "";
  });

  // Persistence bridge
  useEffect(() => {
    localStorage.setItem("cart_items", JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem("applied_coupon", JSON.stringify(appliedCoupon));
    localStorage.setItem("cart_discount", discount.toString());
  }, [appliedCoupon, discount]);

  useEffect(() => {
    localStorage.setItem("selected_location", selectedLocation);
  }, [selectedLocation]);

  // Derived calculations
  const subtotal = useMemo(() => 
    items.reduce((sum, item) => sum + (item.price * item.quantity), 0),
  [items]);

  const cartCount = useMemo(() => 
    items.reduce((sum, item) => sum + item.quantity, 0),
  [items]);

  const total = useMemo(() => Math.max(0, subtotal - discount), [subtotal, discount]);

  // Core actions
  const addToCart = (product, variant) => {
    setItems((prev) => {
      const existing = prev.find(
        (item) => item._id === product._id && item.selectedVariant === variant
      );
      if (existing) {
        return prev.map((item) =>
          item._id === product._id && item.selectedVariant === variant
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { 
        _id: product._id,
        title: product.title,
        price: product.price,
        imageSrc: product.imageSrc,
        quantity: 1, 
        selectedVariant: variant 
      }];
    });
    
    toast.success("Added to deployment registry", {
      description: `${product.title} has been staged for delivery.`
    });
  };

  const updateQuantity = (id, delta, variant) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item._id === id && item.selectedVariant === variant) {
          return { ...item, quantity: Math.max(1, item.quantity + delta) };
        }
        return item;
      })
    );
  };

  const removeFromCart = (id, variant) => {
    setItems((prev) => prev.filter((item) => !(item._id === id && item.selectedVariant === variant)));
    toast.info("Item removed from registry");
  };

  const applyCoupon = (couponData) => {
    setAppliedCoupon(couponData);
    setDiscount(couponData.discount);
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setDiscount(0);
  };

  const clearCart = () => {
    setItems([]);
    setAppliedCoupon(null);
    setDiscount(0);
    if (typeof window !== "undefined") {
      localStorage.removeItem("cart_items");
      localStorage.removeItem("applied_coupon");
      localStorage.removeItem("cart_discount");
    }
    toast.success("Order registry cleared");
  };

  const value = {
    items,
    cartCount,
    subtotal,
    discount,
    total,
    appliedCoupon,
    selectedLocation,
    addToCart,
    updateQuantity,
    removeFromCart,
    applyCoupon,
    removeCoupon,
    setSelectedLocation,
    clearCart
  };

  return React.createElement(CartContext.Provider, { value: value }, children);
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
