import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import WavyText from "./components/WavyText";
import HeroSection from "./components/HeroSection";
import ProductCard from "./components/ProductCard";
import ProductView from "./components/ProductView";
import Cart from "./components/Cart";
import OrderForm from "./components/OrderForm";
import AdminPortal from "./components/AdminPortal";
import CheckoutPage from "./components/CheckoutPage";
import OrderTracking from "./components/OrderTracking";
import { CartProvider, useCart } from "./hooks/useCart";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "./components/ui/sheet";
import { Toaster } from "./components/ui/sonner";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";
import { Loader2, PackageCheck, Search, ArrowRight, ShoppingBag, Truck, ShieldCheck, Headphones, RotateCcw } from "lucide-react";
import { Button } from "./components/ui/button";

interface Product {
  _id: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  category: string;
  vendor: string;
  stock?: number;
  bodyHtml?: string;
  options?: Array<{ name: string; values: string[] }>;
  variantStock?: Record<string, number>;
}

export default function App() {
  return (
    <CartProvider>
      <AppContent />
    </CartProvider>
  );
}

function AppContent() {
  const [view, setView] = useState<"shop" | "dashboard" | "checkout" | "product" | "tracking">("shop");
  const [products, setProducts] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckout, setIsCheckout] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [orderSuccess, setOrderSuccess] = useState<string | null>(null);
  const [locations, setLocations] = useState<any[]>([]);
  const [shopSearch, setShopSearch] = useState("");
  const [lastOrderTotal, setLastOrderTotal] = useState<number>(0);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);

  const {
    cartCount,
    subtotal,
    discount,
    appliedCoupon,
    addToCart,
    applyCoupon,
    clearCart
  } = useCart();

  useEffect(() => {
    fetchProducts();
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const response = await fetch("/api/locations");
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      }
    } catch (error) {
      console.error("Failed to fetch locations");
    }
  };

  const fetchProducts = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/products");
      if (response.ok) {
        const data = await response.json();
        // Shuffle products for variety
        const shuffled = [...data].sort(() => Math.random() - 0.5);
        setProducts(shuffled);
      }
    } catch (error) {
      console.error("Failed to fetch products");
    } finally {
      setIsLoading(false);
    }
  };

  const handleBuyNow = (product: Product, variant?: string) => {
    addToCart(product, variant);
    setView("checkout");
  };

  const handleOrderSubmit = async (orderData: any) => {
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData)
      });

      if (response.ok) {
        const result = await response.json();
        setLastOrderTotal(orderData.totalAmount);
        clearCart();
        setIsCartOpen(false);
        setIsCheckout(false);
        // We don't set view="shop" here yet, we let the CheckoutPage show success first
        return result;
      } else {
        throw new Error("Failed to place order");
      }
    } catch (error) {
      console.error("Order submission error:", error);
      throw error;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans antialiased flex flex-col">
      {(view === "shop" || view === "product") && (
        <Navbar 
          onOpenCart={() => setIsCartOpen(true)}
          view={view}
          setView={setView}
        />
      )}
      
      <main className={`flex-1 overflow-y-auto ${(view === "shop" || view === "product") ? "container mx-auto px-4 py-6" : ""}`}>
        {orderSuccess ? (
          <motion.div 
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-sm mx-auto text-center py-20"
          >
            <div className="bg-emerald-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <PackageCheck className="h-8 w-8 text-emerald-600" />
            </div>
            <h1 className="text-xl font-bold text-slate-900 mb-1">Order confirmed</h1>
            <p className="text-sm font-medium text-slate-900 tabular-nums mb-4">{orderSuccess}</p>
            {lastOrderTotal > 0 && (
              <p className="text-2xl font-bold text-slate-900 tabular-nums mb-2">৳{lastOrderTotal.toLocaleString()}</p>
            )}
            <p className="text-sm text-slate-400 mb-8">
              We'll contact you shortly for delivery details.
            </p>
            <Button 
              onClick={() => { setOrderSuccess(null); setLastOrderTotal(0); }} 
              className="rounded-xl bg-slate-900 text-white font-bold px-8"
            >
              Continue shopping
            </Button>
          </motion.div>
        ) : view === "shop" ? (
          <div className="pb-12">
            <HeroSection 
              searchValue={shopSearch}
              onSearchChange={setShopSearch}
            />

            {/* Shop Features / Trust Bar */}
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
               {[
                 { icon: ShieldCheck, label: "Secure Payment", sub: "100% encrypted transactions" },
                 { icon: Truck, label: "Fast Shipping", sub: "Reliable delivery to your door" },
                 { icon: RotateCcw, label: "Easy Returns", sub: "30-day money back guarantee" },
                 { icon: Headphones, label: "Expert Support", sub: "Always here to help you" }
               ].map((feat, i) => (
                 <motion.div 
                   key={feat.label}
                   initial={{ opacity: 0, y: 10 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ delay: i * 0.1 }}
                   className="bg-white p-6 rounded-2xl border border-slate-200 flex items-center gap-4 hover:border-indigo-500/50 transition-all group cursor-default shadow-sm"
                 >
                    <div className="bg-indigo-50 p-2.5 rounded-xl group-hover:bg-indigo-600 transition-colors duration-300">
                       <feat.icon className="h-5 w-5 text-indigo-600 group-hover:text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900 leading-tight">{feat.label}</p>
                      <p className="text-xs text-slate-500 mt-0.5">{feat.sub}</p>
                    </div>
                 </motion.div>
               ))}
            </div>
            {isLoading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="h-6 w-6 animate-spin text-indigo-400" />
              </div>
            ) : (() => {
              const filtered = products.filter(p => 
                p.title.toLowerCase().includes(shopSearch.toLowerCase()) ||
                p.vendor.toLowerCase().includes(shopSearch.toLowerCase()) ||
                p.category?.toLowerCase().includes(shopSearch.toLowerCase())
              );
              
              if (filtered.length === 0) {
                return (
                  <div className="text-center py-20">
                    <p className="text-sm text-slate-400">No products found for "{shopSearch}"</p>
                  </div>
                );
              }

              return (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pb-12">
                  <AnimatePresence>
                    {filtered.map((product, index) => (
                      <motion.div
                        key={product._id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.02, duration: 0.2 }}
                      >
                        <ProductCard 
                          product={product} 
                          onViewProduct={(id) => {
                            setSelectedProductId(id);
                            setView("product");
                          }}
                          onBuyNow={handleBuyNow}
                        />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              );
            })()}
          </div>
        </div>
      ) : view === "product" && selectedProductId ? (
          <ProductView 
            product={products.find(p => p._id === selectedProductId)!}
            allProducts={products}
            onBack={() => setView("shop")}
            onBuyNow={handleBuyNow}
            onViewProduct={(id) => setSelectedProductId(id)}
          />
        ) : view === "checkout" ? (
          <CheckoutPage 
            onBackToShop={() => setView("shop")}
            onSubmitOrder={handleOrderSubmit}
            locations={locations}
          />
        ) : view === "tracking" ? (
          <OrderTracking onBack={() => setView("shop")} />
        ) : (
          <AdminPortal 
            onBackToShop={() => setView("shop")} 
            onOpenCart={() => setIsCartOpen(true)} 
          />
        )}
      </main>
 
      <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
        <SheetContent className="w-full sm:max-w-md p-0 border-none shadow-2xl transition-all duration-500 h-[100dvh]">
          <div className="h-full flex flex-col bg-white">
            <SheetHeader className="sr-only">
              <SheetTitle>{isCheckout ? "Checkout" : "Cart"}</SheetTitle>
            </SheetHeader>
            <div className="flex-1 min-h-0">
              <Cart 
                onCheckout={() => {
                  setIsCartOpen(false);
                  setView("checkout");
                }}
              />
            </div>
          </div>
        </SheetContent>
      </Sheet>
      <Toaster position="bottom-right" richColors />
    </div>
  );
}
