import React, { useState } from "react";
import { 
  ArrowLeft, 
  ShoppingBag, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  ChevronRight,
  Plus,
  Minus,
  CheckCircle2,
  Loader2,
  Zap
} from "lucide-react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "./ui/select";
import { Button } from "./ui/button";
import { motion, AnimatePresence } from "motion/react";
import ProductCard from "./ProductCard";

interface Product {
  _id: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  category: string;
  vendor: string;
  stock?: number;
  bodyHtml?: string;
  options?: Array<{ name: string; values: string[] }>;
  variantStock?: Record<string, number>;
}

import { useCart } from "../hooks/useCart";

interface ProductViewProps {
  product: Product;
  allProducts: Product[];
  onBack: () => void;
  onBuyNow: (product: Product, variant?: string) => void;
  onViewProduct: (id: string) => void;
}

export default function ProductView({ product, allProducts, onBack, onBuyNow, onViewProduct }: ProductViewProps) {
  const { addToCart } = useCart();
  const hasVariants = product.options && 
    product.options.length > 0 && 
    product.options[0].values && 
    product.options[0].values.length > 0;

  const [selectedVariant, setSelectedVariant] = useState<string>(
    hasVariants ? product.options![0].values[0] : ""
  );
  const [isAdding, setIsAdding] = useState(false);

  // Scroll to top when product changes
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [product._id]);

  const discount = product.compareAtPrice 
    ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
    : 0;

  const isOutOfStock = (() => {
    if (hasVariants && selectedVariant) {
      const vStock = product.variantStock?.[selectedVariant] ?? 0;
      return vStock <= 0;
    }
    if (product.stock !== undefined) {
      return product.stock <= 0;
    }
    return false;
  })();

  const handleAdd = () => {
    if (isOutOfStock) return;
    setIsAdding(true);
    addToCart(product, selectedVariant || undefined);
    setTimeout(() => setIsAdding(false), 2000);
  };

  const relatedProducts = allProducts
    .filter(p => p.category === product.category && p._id !== product._id)
    .slice(0, 4);

  // If we don't have enough related products in the same category, pick random ones
  const finalRelated = relatedProducts.length >= 4 
    ? relatedProducts 
    : [...relatedProducts, ...allProducts
        .filter(p => p._id !== product._id && !relatedProducts.find(rp => rp._id === p._id))
        .sort(() => Math.random() - 0.5)
      ].slice(0, 4);

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Product Navbar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 md:h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={onBack}
              className="group flex items-center gap-2 text-slate-400 hover:text-slate-900 transition-colors"
            >
              <div className="bg-slate-50 p-2 rounded-xl group-hover:bg-slate-100 transition-colors">
                <ArrowLeft className="h-4 w-4" />
              </div>
              <span className="text-[10px] md:text-xs font-black uppercase tracking-widest">Back to shop</span>
            </button>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-slate-400 capitalize text-[11px] font-bold">
             <span>{product.category}</span>
             <ChevronRight className="h-3 w-3" />
             <span className="text-slate-900">{product.title}</span>
          </div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-emerald-500" />
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 hidden xs:block">Official Store</span>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          
          {/* Image Gallery Column */}
           <div className="space-y-6">
            <motion.div 
               key={product.imageSrc}
               initial={{ opacity: 0, scale: 0.95 }}
               animate={{ opacity: 1, scale: 1 }}
               className="aspect-square rounded-[2rem] md:rounded-[3rem] overflow-hidden bg-white border border-slate-100 shadow-2xl shadow-slate-200/50 group"
            >
              <img 
                src={product.imageSrc} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                alt={product.title}
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </div>

          {/* Product Info Column */}
          <div className="space-y-10 lg:sticky lg:top-32">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                 <span className="bg-indigo-600 px-3 py-1 rounded-full text-[9px] font-black text-white uppercase tracking-[0.15em]">{product.vendor}</span>
                 {discount > 0 && (
                   <span className="bg-rose-50 text-rose-500 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-[0.15em]">Save {discount}%</span>
                 )}
              </div>
              <h1 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tighter leading-[0.9]">{product.title}</h1>
              
              <div className="flex items-baseline gap-4">
                 <div className="text-3xl md:text-4xl font-black text-slate-900 tracking-tighter tabular-nums">৳{product.price.toLocaleString()}</div>
                 {product.compareAtPrice && (
                    <div className="text-lg font-bold text-slate-300 line-through tabular-nums">৳{product.compareAtPrice.toLocaleString()}</div>
                 )}
              </div>
            </div>

            {/* Variant Selector */}
            {hasVariants && (
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block ml-1">Select {product.options![0].name}</label>
                <div className="flex flex-wrap gap-3">
                  {product.options![0].values.map((val) => {
                    const isSelected = selectedVariant === val;
                    const stock = product.variantStock?.[val] ?? 0;
                    return (
                      <button
                        key={val}
                        onClick={() => setSelectedVariant(val)}
                        disabled={stock <= 0}
                        className={`px-6 py-3 rounded-2xl text-xs font-black transition-all border-2 ${
                          isSelected 
                            ? "border-slate-900 bg-white text-slate-900 shadow-xl shadow-slate-100 scale-105" 
                            : stock <= 0
                              ? "border-slate-50 bg-slate-50 text-slate-200 cursor-not-allowed"
                              : "border-slate-100 bg-white text-slate-400 hover:border-slate-200"
                        }`}
                      >
                        {val}
                        {stock > 0 && stock < 10 && <span className="ml-2 text-[9px] opacity-60">({stock} left)</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-4 pt-4">
               <div className="flex items-center gap-3">
                  <Button 
                    onClick={handleAdd}
                    disabled={isAdding || isOutOfStock}
                    className={`flex-1 h-14 md:h-18 rounded-2xl md:rounded-3xl text-[10px] md:text-xs font-black uppercase tracking-widest transition-all shadow-xl ${
                      isAdding 
                        ? "bg-emerald-500 text-white" 
                        : "bg-white border-2 border-slate-900 text-slate-900 hover:bg-slate-50"
                    }`}
                  >
                    <AnimatePresence mode="wait">
                      {isAdding ? (
                        <motion.div 
                          key="added" 
                          initial={{ scale: 0.5, opacity: 0 }} 
                          animate={{ scale: 1, opacity: 1 }} 
                          className="flex items-center gap-1.5"
                        >
                          <CheckCircle2 className="h-4 w-4 md:h-5 md:w-5" />
                          <span className="hidden xs:inline">Added</span>
                          <span className="xs:hidden">✓</span>
                        </motion.div>
                      ) : (
                        <motion.div 
                          key="add" 
                          initial={{ opacity: 0 }} 
                          animate={{ opacity: 1 }} 
                          className="flex items-center gap-1.5"
                        >
                          <ShoppingBag className="h-4 w-4 md:h-5 md:w-5" />
                          <span className="hidden xs:inline">Add to Bag</span>
                          <span className="xs:hidden">Add</span>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </Button>

                  <Button 
                    onClick={() => onBuyNow(product, selectedVariant || undefined)}
                    disabled={isOutOfStock}
                    className="flex-[1.5] h-14 md:h-18 bg-slate-900 hover:bg-black text-white rounded-2xl md:rounded-3xl text-[10px] md:text-xs font-black uppercase tracking-widest transition-all shadow-2xl shadow-indigo-100 flex items-center justify-center gap-1.5 group"
                  >
                     <Zap className="h-4 w-4 md:h-5 md:w-5 text-yellow-400 group-hover:scale-110 transition-transform" />
                     Buy It Now
                  </Button>
               </div>
               
               {isOutOfStock && (
                 <p className="text-center text-[10px] font-black uppercase tracking-widest text-rose-500 bg-rose-50 py-3 rounded-2xl">Currently Out of Stock</p>
               )}
            </div>

            {/* Delivery/Trust Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
               <div className="flex items-start gap-4 p-4 rounded-3xl bg-white border border-slate-100">
                  <div className="bg-indigo-50 p-2.5 rounded-2xl">
                     <Truck className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div>
                    <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-wide">Quick Delivery</h4>
                    <p className="text-[10px] text-slate-500 font-bold">2-4 days across Bangladesh</p>
                  </div>
               </div>
               <div className="flex items-start gap-4 p-4 rounded-3xl bg-white border border-slate-100">
                  <div className="bg-emerald-50 p-2.5 rounded-2xl">
                     <RotateCcw className="h-5 w-5 text-emerald-600" />
                  </div>
                  <div>
                    <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-wide">Easy Returns</h4>
                    <p className="text-[10px] text-slate-500 font-bold">7-day hassle-free replacement</p>
                  </div>
               </div>
            </div>

            {/* Product Description */}
            <div className="pt-6 border-t border-slate-100 space-y-4">
               <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Product Description</h3>
               <div 
                 className="prose prose-slate prose-sm max-w-none text-slate-600 font-medium leading-relaxed
                 prose-img:rounded-3xl prose-headings:text-slate-900 prose-headings:font-black prose-headings:tracking-tight
                 prose-strong:text-slate-900 prose-strong:font-black"
                 dangerouslySetInnerHTML={{ __html: product.bodyHtml || "No description provided." }}
               />
            </div>
          </div>
        </div>

        {/* Recommendations Section */}
        <div className="mt-8 pt-8 border-t border-slate-100">
           <div className="flex flex-col items-center gap-2 mb-4">
              <span className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.4em]">Curated Selection</span>
              <h2 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tighter">You May Also Like</h2>
           </div>
           
           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {finalRelated.map((p) => (
                <ProductCard 
                  key={p._id} 
                  product={p} 
                  onViewProduct={onViewProduct}
                  onBuyNow={onBuyNow}
                />
              ))}
           </div>
        </div>
      </div>
      
      {/* Sticky Bottom Bar (Mobile Only) */}
      {!isOutOfStock && (
        <div className="fixed bottom-0 left-0 right-0 z-[60] p-4 lg:hidden pointer-events-none">
           <motion.div 
             initial={{ y: 100, opacity: 0 }}
             animate={{ y: 0, opacity: 1 }}
             transition={{ type: "spring", damping: 25, stiffness: 200, delay: 0.5 }}
             className="max-w-md mx-auto pointer-events-auto"
           >
              <div className="bg-white/90 backdrop-blur-xl border border-slate-200/50 p-3 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.1)] flex items-center gap-3">
                 <div className="flex-1 pl-4">
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Total Price</p>
                    <p className="text-xl font-black text-slate-900 tabular-nums">৳{product.price.toLocaleString()}</p>
                 </div>
                 <button 
                   onClick={() => onBuyNow(product, selectedVariant || undefined)}
                   className="flex-[1.5] h-14 bg-slate-900 text-white rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all"
                 >
                   <Zap className="h-4 w-4 text-yellow-400" />
                   Buy Now
                 </button>
              </div>
           </motion.div>
        </div>
      )}

      {/* Footer minimal info */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-slate-100 mt-12 flex flex-col items-center gap-4 text-slate-300">
         <p className="text-[9px] font-black uppercase tracking-[0.2em]">Authentic Product Guarantee • Secure Payments</p>
      </footer>
    </div>
  );
}
