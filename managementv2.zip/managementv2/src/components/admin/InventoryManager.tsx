import React, { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../ui/dialog";
import { 
  Package, Search, Plus, Edit3, Trash2, Loader2, X, Archive, Box, 
  Layers, BarChart3, Database, Globe2, Activity, AlertTriangle,
  ArrowUpRight, ShoppingBag, CreditCard, Tag, Info, ArrowLeft
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

interface Product {
  _id?: string;
  handle: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  vendor: string;
  category: string;
  status: string;
  stock?: number;
  options?: Array<{ name: string; values: string[] }>;
  variantStock?: Record<string, number>;
}

export default function InventoryManager() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDataLoading, setIsDataLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isUpdating, setIsUpdating] = useState<string | null>(null);

  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [variantInput, setVariantInput] = useState("");
  const [productFormData, setProductFormData] = useState<Product>({
    handle: "",
    title: "",
    price: 0,
    compareAtPrice: 0,
    imageSrc: "",
    vendor: "Online lifestyle",
    category: "General",
    status: "active",
    stock: 0,
    options: [{ name: "Variant", values: [] }],
    variantStock: {}
  });

  useEffect(() => {
    fetchAllProducts();
  }, []);

  const fetchAllProducts = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/products?all=true");
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
    } catch (error) {
      toast.error("Failed to sync products");
    } finally {
      setIsLoading(false);
      setIsDataLoading(false);
    }
  };

  const handleProductSubmit = async () => {
    setIsDataLoading(true);
    const method = editingProduct ? "PATCH" : "POST";
    const url = editingProduct ? `/api/products/${editingProduct._id}` : "/api/products";
    
    const finalData = { 
      ...productFormData,
      options: productFormData.options?.map(opt => ({
        name: opt.name,
        values: opt.values
      })) || [],
      stock: productFormData.stock || 0,
       variantStock: productFormData.variantStock || {}
    };
    if (!finalData.handle) finalData.handle = finalData.title.toLowerCase().replace(/ /g, "-");
    
    if (!editingProduct) {
      delete (finalData as any)._id;
    }

    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(finalData)
      });

      if (response.ok) {
        toast.success(`Product ${editingProduct ? "updated" : "added"} successfully!`);
        setIsProductModalOpen(false);
        fetchAllProducts();
      } else {
        toast.error("Failed to save product");
      }
    } catch (error) {
      toast.error("Network error");
    } finally {
      setIsDataLoading(false);
    }
  };

  const deleteProduct = async (productId: string) => {
    if (!confirm("Are you sure you want to delete this product? This action cannot be undone.")) return;
    setIsUpdating(productId);
    try {
      const response = await fetch(`/api/products/${productId}`, { method: "DELETE" });
      if (response.ok) {
        toast.success("Product deleted successfully");
        fetchAllProducts();
      }
    } catch (error) {
      toast.error("Failed to delete product");
    } finally {
      setIsUpdating(null);
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    const cleanedProduct: Product = {
      ...product,
      stock: product.stock || 0,
      options: product.options?.map(opt => ({
        name: opt.name,
        values: [...opt.values]
      })) || [{ name: "Variant", values: [] }],
      variantStock: product.variantStock ? { ...product.variantStock } : {}
    };
    setProductFormData(cleanedProduct);
    setVariantInput("");
    setIsProductModalOpen(true);
  };

  const openAddProduct = () => {
    setEditingProduct(null);
    setProductFormData({
      handle: "",
      title: "",
      price: 0,
      compareAtPrice: 0,
      imageSrc: "",
      vendor: "Online lifestyle",
      category: "General",
      status: "active",
      stock: 0,
      options: [{ name: "Variant", values: [] }],
      variantStock: {}
    });
    setVariantInput("");
    setIsProductModalOpen(true);
  };

  const addVariantValue = () => {
    const trimmed = variantInput.trim();
    if (!trimmed) return;
    const currentOptions = productFormData.options || [];
    const currentOpt = currentOptions[0] || { name: "Variant", values: [] };
    
    if (currentOpt.values.includes(trimmed)) {
      toast.error("Variant already exists");
      return;
    }
    
    const newOptions = [{
      name: currentOpt.name,
      values: [...currentOpt.values, trimmed]
    }];
    const newVarStock = { ...(productFormData.variantStock || {}), [trimmed]: 0 };
    setProductFormData({ ...productFormData, options: newOptions, variantStock: newVarStock });
    setVariantInput("");
  };

  const removeVariantValue = (val: string) => {
    const currentOptions = productFormData.options || [];
    const currentOpt = currentOptions[0] || { name: "Variant", values: [] };
    
    const newOptions = [{
      name: currentOpt.name,
      values: currentOpt.values.filter(v => v !== val)
    }];
    const newVarStock = { ...(productFormData.variantStock || {}) };
    delete newVarStock[val];
    setProductFormData({ ...productFormData, options: newOptions, variantStock: newVarStock });
  };

  const updateVariantStock = (variant: string, stock: number) => {
    const newVarStock = { ...(productFormData.variantStock || {}), [variant]: stock };
    setProductFormData({ ...productFormData, variantStock: newVarStock });
  };

  const getStockTheme = (stock: number) => {
    if (stock <= 0) return "text-rose-600 bg-rose-50 border-rose-100";
    if (stock <= 5) return "text-amber-600 bg-amber-50 border-amber-100";
    return "text-emerald-600 bg-emerald-50 border-emerald-100";
  };

  const getStockLabel = (stock: number) => {
    if (stock <= 0) return "Out of Stock";
    if (stock <= 5) return `Low: ${stock}`;
    return `In Stock: ${stock}`;
  };

  const filteredProducts = products.filter(p => 
    (p.title || "").toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-10 pb-20 max-w-7xl mx-auto px-6 sm:px-10">
      
      {/* Header Section */}
      <div className="flex flex-col items-center text-center space-y-8">
        <div className="space-y-3">
           <div className="flex flex-col items-center gap-4">
              <div className="h-14 w-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-200 animate-in zoom-in duration-500">
                 <Box className="h-7 w-7" />
              </div>
              <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tighter">Product Catalog</h1>
           </div>
           <p className="text-sm font-bold text-slate-400 uppercase tracking-[0.2em]">Inventory Control & Global Distribution</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full max-w-2xl">
          <div className="relative group flex-1 w-full">
             <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
             <Input 
               placeholder="Search product registry..." 
               value={searchQuery}
               onChange={(e) => setSearchQuery(e.target.value)}
               className="h-14 pl-12 rounded-[1.25rem] bg-white border-slate-200 focus:ring-8 focus:ring-indigo-50/50 transition-all font-bold text-slate-700"
             />
          </div>
          <Button onClick={openAddProduct} className="w-full sm:w-auto bg-slate-900 hover:bg-black text-white rounded-[1.25rem] h-14 px-8 font-black uppercase text-xs tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95">
            <Plus className="h-5 w-5" />
            New Entry
          </Button>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
         <InventoryMetric label="Total Products" value={products.length} icon={Layers} color="indigo" />
         <InventoryMetric label="Active Status" value={products.filter(p => p.status === 'active').length} icon={Activity} color="emerald" />
         <InventoryMetric label="Low Stock" value={products.filter(p => (p.stock || 0) > 0 && (p.stock || 0) <= 5).length} icon={AlertTriangle} color="amber" />
         <InventoryMetric label="Out of Stock" value={products.filter(p => (p.stock || 0) <= 0).length} icon={Package} color="rose" />
      </div>

      {/* Main Listing */}
      <Card className="rounded-[2.5rem] border-slate-100 shadow-sm overflow-hidden bg-white">
        <CardHeader className="px-8 py-10 border-b border-slate-50 flex flex-col items-center text-center">
           <div className="flex flex-col items-center gap-4">
              <div className="h-12 w-12 bg-indigo-50 rounded-2xl flex items-center justify-center border border-indigo-100/50">
                 <Database className="h-6 w-6 text-indigo-600" />
              </div>
              <div>
                 <CardTitle className="text-xl font-black text-slate-900 tracking-tight">Product Registry</CardTitle>
                 <CardDescription className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1.5">{filteredProducts.length} entries active in directory</CardDescription>
              </div>
           </div>
        </CardHeader>
        <CardContent className="p-8 sm:p-10 bg-slate-50/30">
          {isLoading ? (
            <div className="h-96 flex flex-col items-center justify-center gap-4 text-slate-300">
               <Loader2 className="animate-spin h-10 w-10" />
               <p className="text-sm font-bold uppercase tracking-widest">Loading Catalog...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="h-96 flex flex-col items-center justify-center gap-4 text-slate-200">
               <Box className="h-16 w-16" />
               <p className="text-sm font-bold uppercase tracking-widest text-slate-400">No products found</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              <AnimatePresence>
                {filteredProducts.map((product) => (
                  <ProductNodeCard 
                    key={product._id} 
                    product={product} 
                    onEdit={() => handleEditProduct(product)}
                    onDelete={() => deleteProduct(product._id!)}
                    stockTheme={getStockTheme(product.stock || 0)}
                    stockLabel={getStockLabel(product.stock || 0)}
                  />
                ))}
              </AnimatePresence>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Product Modal */}
      <Dialog open={isProductModalOpen} onOpenChange={setIsProductModalOpen}>
        <DialogContent className="sm:max-w-3xl rounded-[2.5rem] p-0 overflow-hidden border-slate-200 shadow-2xl bg-white">
          <div className="px-10 py-8 border-b border-slate-100 bg-slate-50/50">
             <div className="flex items-center gap-3 mb-2">
                <div className="h-10 w-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
                   <Edit3 className="h-5 w-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-600">Product Editor</span>
             </div>
             <DialogHeader>
                <DialogTitle className="text-2xl font-bold text-slate-900 tracking-tight">
                   {editingProduct ? "Update Product Details" : "Create New Product"}
                </DialogTitle>
                <DialogDescription className="text-slate-500 font-medium text-xs">
                   Configure your product attributes and stock allocation.
                </DialogDescription>
             </DialogHeader>
          </div>

          <div className="p-10 space-y-10 max-h-[60vh] overflow-y-auto no-scrollbar">
            {/* Basic Info */}
            <div className="space-y-6">
               <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-indigo-100 flex items-center justify-center text-[10px] font-bold text-indigo-600">1</div>
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">Basic Information</span>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="text-xs font-bold text-slate-500 ml-1">Product Title</Label>
                    <Input 
                      value={productFormData.title} 
                      onChange={(e) => setProductFormData({...productFormData, title: e.target.value})}
                      placeholder="e.g. Premium Phone Case"
                      className="h-12 border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-50 font-medium"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-bold text-slate-500 ml-1">Thumbnail URL</Label>
                    <Input 
                      value={productFormData.imageSrc} 
                      onChange={(e) => setProductFormData({...productFormData, imageSrc: e.target.value})}
                      placeholder="https://..."
                      className="h-12 border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-50 font-medium text-xs"
                    />
                  </div>
               </div>
            </div>

            {/* Pricing & Stock */}
            <div className="space-y-6">
               <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-indigo-100 flex items-center justify-center text-[10px] font-bold text-indigo-600">2</div>
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">Pricing & Logistics</span>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label className="text-xs font-bold text-slate-500 ml-1">Sale Price (৳)</Label>
                    <Input 
                      type="number"
                      value={productFormData.price} 
                      onChange={(e) => setProductFormData({...productFormData, price: Number(e.target.value)})}
                      className="h-12 bg-indigo-50 border-indigo-100 text-indigo-600 rounded-xl focus:ring-4 focus:ring-indigo-50 font-bold tabular-nums"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-bold text-slate-500 ml-1">Old Price (Optional)</Label>
                    <Input 
                      type="number"
                      value={productFormData.compareAtPrice} 
                      onChange={(e) => setProductFormData({...productFormData, compareAtPrice: Number(e.target.value)})}
                      className="h-12 border-slate-200 text-slate-400 rounded-xl focus:ring-4 focus:ring-indigo-50 font-bold tabular-nums"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-bold text-slate-500 ml-1">Total Stock</Label>
                    <Input 
                      type="number"
                      value={productFormData.stock ?? 0} 
                      onChange={(e) => setProductFormData({...productFormData, stock: Number(e.target.value)})}
                      className="h-12 bg-slate-50 border-slate-100 text-slate-700 rounded-xl focus:ring-4 focus:ring-indigo-50 font-bold tabular-nums"
                    />
                  </div>
               </div>
            </div>

            {/* Variants */}
            <div className="space-y-6">
               <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-indigo-100 flex items-center justify-center text-[10px] font-bold text-indigo-600">3</div>
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">Variant Options</span>
               </div>
               
               <div className="bg-slate-50 p-8 rounded-3xl space-y-6 border border-slate-100">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div className="space-y-2">
                        <Label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Attribute Name</Label>
                        <Input 
                          value={productFormData.options?.[0]?.name || "Size"} 
                          onChange={(e) => {
                            const currentOpt = productFormData.options?.[0] || { name: "", values: [] };
                            setProductFormData({
                              ...productFormData, 
                              options: [{ name: e.target.value, values: [...currentOpt.values] }]
                            });
                          }}
                          placeholder="e.g. Size, Color"
                          className="h-11 rounded-xl border-slate-200 font-bold text-xs"
                        />
                     </div>
                     <div className="space-y-2">
                        <Label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Add Value</Label>
                        <div className="flex gap-2">
                           <Input 
                             value={variantInput}
                             onChange={(e) => setVariantInput(e.target.value)}
                             onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addVariantValue())}
                             placeholder="M, L, XL..."
                             className="h-11 rounded-xl border-slate-200 font-bold text-xs"
                           />
                           <Button type="button" onClick={addVariantValue} className="h-11 w-11 rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-100 shrink-0"><Plus className="h-4 w-4" /></Button>
                        </div>
                     </div>
                  </div>

                  <div className="flex flex-wrap gap-2 py-4 px-5 bg-white rounded-2xl border border-slate-100 min-h-[60px] items-center">
                    {productFormData.options?.[0]?.values.map(val => (
                      <Badge key={val} className="px-3 py-1.5 bg-indigo-50 text-indigo-600 border border-indigo-100 rounded-lg flex items-center gap-2 font-bold text-[10px]">
                        {val}
                        <button type="button" onClick={() => removeVariantValue(val)} className="hover:text-indigo-800 transition-colors">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                    {(!productFormData.options?.[0]?.values || productFormData.options[0].values.length === 0) && (
                      <span className="text-[10px] font-medium text-slate-300 italic">No variant values added yet.</span>
                    )}
                  </div>

                  {productFormData.options?.[0]?.values && productFormData.options[0].values.length > 0 && (
                    <div className="space-y-4 pt-4 border-t border-slate-200">
                      <Label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Per-Variant Supply Allocation</Label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {productFormData.options[0].values.map(val => (
                          <div key={val} className="flex flex-col gap-2 p-3 bg-white rounded-xl border border-slate-100">
                            <span className="text-[10px] font-bold text-slate-500 truncate text-center">{val}</span>
                            <Input 
                              type="number"
                              value={productFormData.variantStock?.[val] ?? 0}
                              onChange={(e) => updateVariantStock(val, Number(e.target.value))}
                              className="h-9 border-none bg-slate-50 text-center font-bold text-indigo-600 rounded-lg text-xs"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
               </div>
            </div>
          </div>

          <div className="p-8 border-t border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row gap-4">
             <Button variant="ghost" onClick={() => setIsProductModalOpen(false)} className="h-12 flex-1 rounded-xl text-slate-500 font-bold uppercase text-[10px] tracking-widest hover:bg-white hover:text-slate-900 border border-transparent">
                Cancel Update
             </Button>
             <Button 
               onClick={handleProductSubmit} 
               disabled={isDataLoading} 
               className="h-12 flex-[2] rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold uppercase text-[10px] tracking-widest shadow-lg shadow-indigo-100 transition-all"
             >
               {isDataLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : (editingProduct ? "Save Changes" : "Create Product")}
             </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ProductNodeCard({ product, onEdit, onDelete, stockTheme, stockLabel }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -4 }}
      className="group bg-white rounded-[2rem] border border-slate-100 overflow-hidden hover:border-indigo-100 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-indigo-50/50 flex flex-col h-full"
    >
      <div className="relative aspect-square overflow-hidden bg-slate-50 group/img">
        <img src={product.imageSrc} alt={product.title} className="w-full h-full object-cover transition-transform duration-700 group-hover/img:scale-105" />
        <div className="absolute top-4 inset-x-4 flex justify-center">
           <Badge className={`px-3 py-1.5 rounded-xl border font-bold text-[9px] uppercase tracking-widest shadow-sm ${stockTheme}`}>
            {stockLabel}
          </Badge>
        </div>
      </div>

      <div className="p-8 flex flex-col flex-1 items-center text-center space-y-6">
        <div className="space-y-2">
          <p className="text-[10px] font-bold text-indigo-500 uppercase tracking-[0.2em] leading-none">{product.vendor || 'General'}</p>
          <h4 className="text-lg font-bold text-slate-900 leading-tight line-clamp-2 px-2">{product.title}</h4>
        </div>

        <div className="flex flex-col items-center gap-2">
           <div className="flex flex-col items-center">
              <span className="text-2xl font-black text-slate-900 tabular-nums tracking-tighter">৳{(product.price || 0).toLocaleString()}</span>
              {product.compareAtPrice > 0 && (
                <span className="text-xs text-slate-300 font-bold line-through tracking-wider">৳{product.compareAtPrice.toLocaleString()}</span>
              )}
           </div>
           <Badge variant="outline" className={`px-3 py-1 rounded-full border-slate-100 text-slate-400 text-[8px] font-bold uppercase tracking-[0.15em] mt-1`}>
              {product.status}
           </Badge>
        </div>
        
        <div className="pt-6 flex gap-3 border-t border-slate-50 w-full mt-auto">
          <Button onClick={onEdit} variant="outline" className="flex-1 h-12 rounded-2xl bg-white border-slate-200 text-indigo-600 hover:bg-indigo-50 hover:border-indigo-100 font-bold text-[10px] uppercase tracking-widest transition-all">
            Manage Item
          </Button>
          <Button variant="ghost" size="icon" onClick={onDelete} className="h-12 w-12 min-w-[48px] rounded-2xl text-slate-300 hover:text-rose-500 hover:bg-rose-50 transition-all border border-transparent">
            <Trash2 className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

function InventoryMetric({ label, value, icon: Icon, color }: any) {
  const themes: any = {
    indigo: "text-indigo-600 bg-indigo-50 border-indigo-100",
    emerald: "text-emerald-600 bg-emerald-50 border-emerald-100",
    amber: "text-amber-600 bg-amber-50 border-amber-100",
    rose: "text-rose-600 bg-rose-50 border-rose-100"
  };

  return (
    <Card className={`rounded-[2.5rem] p-10 border shadow-sm group flex flex-col items-center justify-center text-center bg-white hover:border-indigo-200 transition-all duration-300`}>
       <div className={`h-14 w-14 rounded-2xl flex items-center justify-center border transition-transform duration-500 group-hover:scale-110 mb-6 ${themes[color]}`}>
          <Icon className="h-6 w-6" />
       </div>
       <div className="flex flex-col items-center">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] leading-none mb-3">{label}</p>
          <p className="text-4xl font-black text-slate-900 tabular-nums leading-none tracking-tighter">{value}</p>
       </div>
    </Card>
  );
}
