import React, { useState } from "react";
import { Dialog, DialogContent } from "../../ui/dialog";
import { Button } from "../../ui/button";
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger 
} from "../../ui/dropdown-menu";
import { 
  ChevronDown, User, MapPin, Truck, RefreshCw, Package, 
  ShieldCheck, Loader2, Printer, Copy, Check, ExternalLink,
  CreditCard, Hash, Tag, Info
} from "lucide-react";
import { LogisticsTimeline } from "./LogisticsTimeline";
import { Order, STATUS_THEMES, getBannerColor } from "./types";
import { InvoiceTemplate } from "./InvoiceTemplate";
import { motion, AnimatePresence } from "motion/react";
import { Card, CardContent } from "../../ui/card";
import { Badge } from "../../ui/badge";
import { toast } from "sonner";

// Print-specific high-fidelity styles
const PRINT_STYLES = `
  @media print {
    @page {
      size: auto;
      margin: 0mm;
    }
    body * { visibility: hidden; }
    #official-invoice { 
      visibility: visible; 
      display: block !important;
      position: absolute; 
      left: 0; 
      top: 0; 
      width: 100%; 
      background: white;
      z-index: 9999;
    }
    #official-invoice * { 
      visibility: visible; 
    }
    .no-print { display: none !important; }
  }
`;

interface OrderDetailModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateStatus: (orderId: string, status: string) => Promise<void>;
  onSendToSteadfast: (orderId: string) => Promise<void>;
  onRefreshSteadfast: (orderId: string) => Promise<void>;
  isUpdating: boolean;
  isSteadfastLoading: boolean;
  steadfastStatus: string | null;
}

const CopyButton = ({ value }: { value: string }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button 
      onClick={handleCopy}
      className="p-1.5 hover:bg-slate-100 rounded-md transition-colors text-slate-400 hover:text-indigo-600"
    >
      {copied ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
    </button>
  );
};

export const OrderDetailModal = ({
  order,
  isOpen,
  onClose,
  onUpdateStatus,
  onSendToSteadfast,
  onRefreshSteadfast,
  isUpdating,
  isSteadfastLoading,
  steadfastStatus
}: OrderDetailModalProps) => {
  if (!order) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <style>{PRINT_STYLES}</style>
      <DialogContent id="printable-order-detail" className="sm:max-w-4xl p-0 overflow-hidden border-slate-200 shadow-2xl bg-slate-50 flex flex-col max-h-[90vh] rounded-[2rem]">
        
        {/* Header */}
        <div className="px-8 py-6 border-b border-slate-200 bg-white flex items-center justify-between shrink-0">
           <div className="flex items-center gap-4">
              <div className="h-10 w-10 bg-indigo-50 rounded-xl flex items-center justify-center border border-indigo-100/50">
                 <Hash className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                 <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Order Number</span>
                    <CopyButton value={order.orderNumber} />
                 </div>
                 <h2 className="text-xl font-bold text-slate-900 tracking-tight leading-none mt-1">{order.orderNumber}</h2>
              </div>
           </div>

           <div className="flex items-center gap-3 no-print">
              <div className="hidden sm:flex flex-col items-end mr-4">
                 <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Created At</span>
                 <span className="text-xs font-bold text-slate-700 tabular-nums">{new Date(order.createdAt).toLocaleString()}</span>
              </div>
              <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                     <Button variant="outline" className={`h-10 px-4 rounded-xl border ${STATUS_THEMES[order.status]?.color || ""} font-bold text-[10px] uppercase tracking-wider transition-all`}>
                        {order.status || "Status"}
                        <ChevronDown className="ml-2 h-3.5 w-3.5 opacity-50" />
                     </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 p-1.5 rounded-xl">
                     {Object.keys(STATUS_THEMES).map((status) => (
                       <DropdownMenuItem 
                         key={status} 
                         onClick={() => onUpdateStatus(order._id, status)}
                         className="flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer text-xs font-bold uppercase tracking-wider text-slate-600"
                       >
                          <div className={`w-2 h-2 rounded-full ${STATUS_THEMES[status].color.split(' ').find(c => c.startsWith('bg-'))?.replace('50', '500') || 'bg-slate-400'}`} />
                          {status}
                       </DropdownMenuItem>
                     ))}
                  </DropdownMenuContent>
              </DropdownMenu>
           </div>
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar">
           <div className="p-8 space-y-8">
              {/* Logistics Progress */}
              <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                 <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-2">
                       <Truck className="h-4 w-4 text-indigo-600" />
                       <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600">Delivery Status</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Step {
                       ["Pending", "In Review", "Shipped", "Delivered"].indexOf(order.status) + 1
                    }/4</span>
                 </div>
                 <LogisticsTimeline status={order.status} />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                 {/* Left Column: Customer Info */}
                 <div className="lg:col-span-2 space-y-6">
                    <div className="bg-white rounded-[2rem] p-8 border border-slate-200 shadow-sm space-y-8">
                       <div className="relative">
                          <div className="flex items-center gap-2 mb-6">
                             <User className="h-4 w-4 text-slate-400" />
                             <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Customer Details</span>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                             <div className="space-y-6">
                                <div>
                                   <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Full Name</p>
                                   <p className="text-xl font-bold text-slate-900 tracking-tight">{order.customerName}</p>
                                </div>
                                <div className="space-y-3">
                                   <div className="space-y-1">
                                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Mobile Number</p>
                                      <div className="flex items-center gap-2">
                                         <p className="text-sm font-bold text-indigo-600 tabular-nums">{order.customerPhone}</p>
                                         <CopyButton value={order.customerPhone} />
                                      </div>
                                   </div>
                                   {order.customerEmail && (
                                     <div className="space-y-1">
                                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Email Address</p>
                                        <p className="text-xs text-slate-600">{order.customerEmail}</p>
                                     </div>
                                   )}
                                </div>
                             </div>

                             <div className="space-y-6 md:pl-8 md:border-l border-slate-100">
                                <div className="space-y-3">
                                   <div className="flex items-center justify-between">
                                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Delivery Address</p>
                                      <CopyButton value={order.address} />
                                   </div>
                                   <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                                      <p className="text-xs font-medium text-slate-600 leading-relaxed italic">
                                         {order.address}
                                      </p>
                                   </div>
                                </div>
                             </div>
                          </div>
                       </div>

                       {order.customerNote && (
                          <div className="pt-6 border-t border-slate-100 flex gap-3">
                             <Info className="h-4 w-4 text-indigo-500 shrink-0" />
                             <div>
                                <p className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest mb-1">Customer Note</p>
                                <p className="text-xs text-slate-500 italic leading-relaxed">{order.customerNote}</p>
                             </div>
                          </div>
                       )}

                       {/* FraudShield Integration */}
                       <FraudShieldReport phone={order.customerPhone} />
                    </div>

                    {/* Carrier Info */}
                    {order.trackingCode && (
                      <div className="bg-indigo-50 border border-indigo-100 rounded-[1.5rem] p-6 flex flex-col sm:flex-row items-center justify-between gap-6">
                         <div className="flex items-center gap-4">
                            <div className="h-12 w-12 flex items-center justify-center bg-white rounded-2xl border border-indigo-100 shadow-sm">
                               <Truck className="h-6 w-6 text-indigo-600" />
                            </div>
                            <div>
                               <div className="flex items-center gap-2">
                                  <p className="text-[10px] font-bold text-indigo-500 uppercase tracking-wider mb-0.5">Steadfast Logistics</p>
                                  <ExternalLink className="h-3 w-3 text-indigo-400" />
                               </div>
                               <p className="text-sm font-bold text-slate-900">
                                  {isSteadfastLoading ? "Updating..." : (steadfastStatus || "Dispatched")}
                                </p>
                            </div>
                         </div>
                         <div className="flex items-center gap-4 bg-white px-5 py-3 rounded-xl border border-indigo-100 shadow-sm no-print">
                            <code className="text-[10px] font-bold text-slate-600 tracking-widest tabular-nums">{order.trackingCode}</code>
                            <div className="h-4 w-[1px] bg-slate-100" />
                            <button onClick={() => onRefreshSteadfast(order._id)}>
                               <RefreshCw 
                                 className={`h-4 w-4 text-indigo-500 cursor-pointer ${isSteadfastLoading ? "animate-spin" : "hover:rotate-180 transition-transform duration-500"}`} 
                               />
                            </button>
                         </div>
                      </div>
                    )}
                 </div>

                 {/* Right Column: Totals */}
                 <div>
                    <Card className="rounded-[2rem] border-slate-200 shadow-sm bg-white overflow-hidden h-full flex flex-col">
                       <CardContent className="p-8 space-y-8 flex-1 flex flex-col justify-between">
                          <div className="space-y-8">
                             <div className="flex items-center gap-2">
                                <CreditCard className="h-4 w-4 text-slate-400" />
                                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Order Summary</span>
                             </div>

                             <div className="space-y-4">
                                <div className="flex justify-between items-center">
                                   <span className="text-xs text-slate-500">Subtotal</span>
                                   <span className="text-sm font-bold text-slate-700 tabular-nums">৳{(order.totalAmount - order.deliveryCharge).toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between items-center">
                                   <span className="text-xs text-slate-500">Shipping</span>
                                   <span className="text-sm font-bold text-slate-700 tabular-nums">+৳{order.deliveryCharge.toLocaleString()}</span>
                                </div>
                                <div className="h-px bg-slate-100 w-full" />
                                <div className="pt-2">
                                   <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest mb-1">Total Paid</p>
                                   <p className="text-4xl font-bold text-slate-900 tracking-tight tabular-nums">
                                      ৳{(Number(order.totalAmount) || 0).toLocaleString()}
                                   </p>
                                </div>
                             </div>
                          </div>

                          <div className="mt-8 pt-8 border-t border-slate-100">
                             <div className="flex items-center gap-2 mb-4">
                                <div className="h-2 w-2 rounded-full bg-emerald-500" />
                                <span className="text-[9px] font-bold text-emerald-600 uppercase tracking-widest">Transaction Verified</span>
                             </div>
                             <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-100 flex items-center gap-3">
                                <ShieldCheck className="h-5 w-5 text-emerald-600" />
                                <p className="text-[10px] font-bold text-emerald-800 leading-tight tracking-tight">
                                   This order is secure and logged to your records.
                                </p>
                             </div>
                          </div>
                       </CardContent>
                    </Card>
                 </div>
              </div>

              {/* Items Table */}
              <div className="space-y-6">
                 <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                       <Package className="h-4 w-4 text-slate-400" />
                       <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Products Ordered</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{order.items?.length || 0} Units</span>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {order.items?.map((item, i) => (
                      <div key={i} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-5 group border-transparent hover:border-indigo-100 transition-all">
                         <div className="h-16 w-16 bg-slate-50 rounded-2xl flex items-center justify-center font-bold text-slate-900 border border-slate-100 group-hover:bg-indigo-600 group-hover:text-white group-hover:border-indigo-600 transition-all">
                            {item.quantity}
                         </div>
                         <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-slate-900 truncate leading-tight">
                               {item.title}
                            </p>
                            <div className="flex items-center gap-2 mt-2">
                               <div className="flex items-center gap-1.5 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-100">
                                  <Tag className="h-2.5 w-2.5 text-indigo-600" />
                                  <span className="text-[9px] font-bold text-indigo-700 uppercase">{item.variant || "Standard"}</span>
                               </div>
                               <div className="h-1.5 w-1.5 rounded-full bg-slate-200" />
                               <span className="text-xs font-medium text-slate-400 tabular-nums">৳{(Number(item.price) || 0).toLocaleString()} / unit</span>
                            </div>
                         </div>
                         <div className="text-right">
                            <p className="text-xs font-bold text-slate-900 tabular-nums">৳{( (Number(item.price) || 0) * (Number(item.quantity) || 0) ).toLocaleString()}</p>
                         </div>
                      </div>
                    ))}
                 </div>
              </div>
           </div>
        </div>

        {/* Footer Actions */}
        <div className="p-8 border-t border-slate-200 bg-white flex flex-col sm:flex-row gap-4 shrink-0 no-print">
           <Button variant="ghost" onClick={onClose} className="h-12 rounded-xl text-slate-400 font-bold uppercase text-[10px] tracking-widest hover:bg-slate-50 hover:text-slate-900 transition-all sm:flex-1 border border-transparent">
              Close Detail
           </Button>
           
           {!order.trackingCode ? (
              <Button 
                 onClick={() => onSendToSteadfast(order._id)}
                 disabled={isUpdating}
                 className="h-12 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold uppercase text-[10px] tracking-widest transition-all sm:flex-[2] flex items-center justify-center gap-2 shadow-lg shadow-indigo-100 active:scale-95 disabled:opacity-50"
              >
                 {isUpdating ? <Loader2 className="h-5 w-5 animate-spin" /> : (
                   <>Send to Courier</>
                 )}
              </Button>
           ) : (
              <div className="sm:flex-[2] flex gap-3">
                 <div className="h-12 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-100 font-bold uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 flex-1">
                    <Check className="h-4 w-4" /> Dispatched
                 </div>
                 <Button onClick={() => window.print()} variant="outline" className="h-12 w-12 rounded-xl border-slate-200 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 active:scale-90">
                    <Printer className="h-5 w-5" />
                 </Button>
              </div>
           )}
        </div>

        {/* Official Branded Invoice (Hidden on screen, visible on print) */}
        <InvoiceTemplate order={order} />
      </DialogContent>
    </Dialog>
  );
};

function FraudShieldReport({ phone }: { phone: string }) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const auditPhone = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/fraudshield/audit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({ phone })
      });

      if (!response.ok) throw new Error("Shield link failed");
      const result = await response.json();
      
      if (result.success) {
        setData(result);
        toast.success("Intelligence dossier synchronized");
      } else {
        toast.error(result.message || "Audit packet rejected");
      }
    } catch (error) {
      toast.error("FraudShield: Link failed. CORS or Auth error.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-8 pt-8 border-t border-slate-100 flex flex-col gap-8 no-print">
       <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-xl shadow-indigo-100 group">
                <ShieldCheck className="h-5 w-5 group-hover:scale-110 transition-transform" />
             </div>
             <div>
                <p className="text-[11px] font-black text-slate-900 uppercase tracking-widest leading-none">Intelligence Dossier</p>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.2em] mt-1.5 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
                  Real-time Risk Telemetry
                </p>
             </div>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={auditPhone}
            disabled={loading}
            className="h-10 px-5 rounded-2xl border-indigo-200 text-indigo-600 hover:bg-indigo-600 hover:text-white font-black text-[10px] uppercase tracking-widest transition-all shadow-lg hover:shadow-indigo-200"
          >
            {loading ? <Loader2 className="h-3 w-3 animate-spin mr-2" /> : <RefreshCw className="h-3 w-3 mr-2" />}
            {data ? "Flash Re-Audit" : "Run Security Audit"}
          </Button>
       </div>

       <AnimatePresence>
          {data && (
             <motion.div 
               initial={{ opacity: 0, scale: 0.98 }}
               animate={{ opacity: 1, scale: 1 }}
               className="flex flex-col gap-6"
             >
                {/* Tactical Risk Header */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                   <div className="col-span-1 md:col-span-2 p-8 rounded-[2rem] bg-slate-900 border border-slate-800 text-white shadow-2xl relative overflow-hidden flex flex-col justify-between">
                      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/10 blur-[80px] rounded-full -mr-32 -mt-32" />
                      <div className="relative z-10">
                         <div className="flex items-center justify-between mb-8">
                            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">Customer Risk Analysis</span>
                            <Badge className={`${data.fraudRiskScore.level === 'low' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border-rose-500/30'} font-black text-[10px] uppercase tracking-widest py-1 px-4 border`}>
                               {data.fraudRiskScore.level} Risk
                            </Badge>
                         </div>
                         <div className="flex items-end gap-6 mb-8">
                            <p className="text-7xl font-black tracking-tighter tabular-nums leading-none">
                               {data.fraudRiskScore.score}
                            </p>
                            <div className="pb-1">
                               <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest leading-none">Fraud Score</p>
                               <p className="text-[9px] font-bold text-indigo-400 tracking-[0.2em] mt-2 uppercase leading-none">Scale 0-100</p>
                            </div>
                         </div>
                      </div>
                      <div className="relative z-10 w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                         <motion.div 
                           initial={{ width: 0 }}
                           animate={{ width: `${data.fraudRiskScore.score}%` }}
                           className={`h-full ${data.fraudRiskScore.level === 'low' ? 'bg-emerald-500' : 'bg-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.5)]'}`}
                         />
                      </div>
                   </div>

                   <div className="grid grid-cols-1 gap-4">
                      <div className="p-6 rounded-[1.5rem] bg-indigo-600 border border-indigo-500 text-white shadow-xl shadow-indigo-100">
                         <p className="text-[9px] font-black text-indigo-200 uppercase tracking-widest mb-3">Total Parcels</p>
                         <p className="text-3xl font-black leading-none tabular-nums">{data.courierData.summary.total_parcels}</p>
                      </div>
                      <div className="p-6 rounded-[1.5rem] bg-slate-100 border border-slate-200">
                         <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-3">Success Rate</p>
                         <div className="flex items-center justify-between">
                            <p className="text-3xl font-black text-slate-900 leading-none tabular-nums">{data.courierData.summary.success_rate}%</p>
                            <TrendingUp className="h-5 w-5 text-emerald-500" />
                         </div>
                      </div>
                   </div>
                </div>

                {/* Courier Intelligence breakdown */}
                <div className="space-y-4">
                   <div className="flex items-center gap-3">
                      <div className="h-px flex-1 bg-slate-100" />
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.4em]">Courier Intelligence</span>
                      <div className="h-px flex-1 bg-slate-100" />
                   </div>
                   
                   <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {data.courierData.couriers.map((c: any, index: number) => (
                         <motion.div 
                           key={index}
                           initial={{ opacity: 0, y: 10 }}
                           animate={{ opacity: 1, y: 0 }}
                           transition={{ delay: index * 0.1 }}
                           className="p-5 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-white hover:shadow-lg transition-all group"
                         >
                            <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest mb-3">{c.courier}</p>
                            <div className="flex flex-col gap-2">
                               <div className="flex items-center justify-between">
                                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Sent</span>
                                  <span className="text-[11px] font-black text-slate-900 tabular-nums">{c.total}</span>
                               </div>
                               <div className="flex items-center justify-between">
                                  <span className="text-[9px] font-bold text-emerald-500 uppercase tracking-widest">Success</span>
                                  <span className="text-[11px] font-black text-emerald-600 tabular-nums">{c.successful}</span>
                               </div>
                               <div className="flex items-center justify-between">
                                  <span className="text-[9px] font-bold text-rose-500 uppercase tracking-widest">Failed</span>
                                  <span className="text-[11px] font-black text-rose-600 tabular-nums">{c.cancelled}</span>
                               </div>
                            </div>
                         </motion.div>
                      ))}
                   </div>
                </div>
             </motion.div>
          )}
       </AnimatePresence>
    </div>
  );
}

function TrendingUp({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="3" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
      <polyline points="16 7 22 7 22 13" />
    </svg>
  );
}
