import mongoose from "mongoose";

const MONGODB_URI = "mongodb+srv://alif0x1:kali@cluster0.7rfifdo.mongodb.net/?appName=Cluster0";

const productSchema = new mongoose.Schema({
  handle: String,
  title: String,
  bodyHtml: String,
  vendor: String,
  category: String,
  type: String,
  price: Number,
  compareAtPrice: Number,
  imageSrc: String,
  status: String,
  options: [{
    name: String,
    values: [String]
  }]
});

const Product = mongoose.model("Product", productSchema);

const products = [
  {
    handle: "better-enjoyment-2",
    title: "Better enjoyment white",
    bodyHtml: "<p>X Level Better Enjoyment brings a smooth, premium feel to your phone while keeping it slim and easy to handle.</p>",
    vendor: "Online lifestyle",
    category: "Electronics > Communications > Telephony > Mobile & Smart Phone Accessories > Mobile Phone Cases",
    type: "",
    price: 1250.00,
    compareAtPrice: 1800.00,
    imageSrc: "https://cdn.shopify.com/s/files/1/0721/3740/8556/files/better-enjoyment-whiteonline-lifestyle-4982159.jpg?v=1773924757",
    status: "active",
    options: [{ name: "Model", values: ["17 pro max", "17 pro", "16 pro max", "15 pro max"] }]
  },
  {
    handle: "better-enjoyment-1",
    title: "Better Enjoyment Imperial Blue",
    bodyHtml: "<p>X Level Better Enjoyment brings a smooth, premium feel to your phone while keeping it slim and easy to handle.</p>",
    vendor: "Online lifestyle",
    category: "Electronics > Communications > Telephony > Mobile & Smart Phone Accessories > Mobile Phone Cases",
    type: "",
    price: 1250.00,
    compareAtPrice: 1600.00,
    imageSrc: "https://cdn.shopify.com/s/files/1/0721/3740/8556/files/better-enjoyment-imperial-blueonline-lifestyle-2414063.jpg?v=1773924756",
    status: "active",
    options: [{ name: "Model", values: ["17 pro max", "17 pro"] }]
  },
  {
    handle: "better-enjoyment",
    title: "Better enjoyment Cosmic Orange",
    bodyHtml: "<p>X Level Better Enjoyment brings a smooth, premium feel to your phone while keeping it slim and easy to handle.</p>",
    vendor: "Online lifestyle",
    category: "Electronics > Communications > Telephony > Mobile & Smart Phone Accessories > Mobile Phone Cases",
    type: "",
    price: 1250.00,
    compareAtPrice: 1600.00,
    imageSrc: "https://cdn.shopify.com/s/files/1/0721/3740/8556/files/better-enjoyment-cosmic-orangeonline-lifestyle-2332668.jpg?v=1773924755",
    status: "active",
    options: [{ name: "Model", values: ["17 pro max", "17 pro"] }]
  },
  {
    handle: "mossily-tempered-glass",
    title: "MOSSILY Privacy Tempered Glass",
    bodyHtml: "<p>A popular choice among youngsters who want both style and protection.</p>",
    vendor: "Online lifestyle",
    category: "Electronics > Electronics Accessories > Electronics Films & Shields > Screen Protectors",
    type: "",
    price: 500.00,
    compareAtPrice: 850.00,
    imageSrc: "https://cdn.shopify.com/s/files/1/0721/3740/8556/files/mossily-privacy-tempered-glassonline-lifestyle-4578757.jpg?v=1773924755",
    status: "active",
    options: [{ name: "Model", values: ["17 pro max", "17 pro"] }]
  },
  {
    handle: "luxo-mocha-royale",
    title: "Luxo Mocha Royale",
    bodyHtml: "<p>The Luxo hard matte case keeps your iPhone slim, smooth, and scratch-free.</p>",
    vendor: "Online lifestyle",
    category: "Electronics > Communications > Telephony > Mobile & Smart Phone Accessories > Mobile Phone Cases",
    type: "",
    price: 1100.00,
    compareAtPrice: 1600.00,
    imageSrc: "https://cdn.shopify.com/s/files/1/0721/3740/8556/files/luxo-mocha-royaleonline-lifestyle-4606841.jpg?v=1773924754",
    status: "active",
    options: [{ name: "Model", values: ["17 pro max", "17 pro", "16 pro max", "15 pro max"] }]
  },
  {
    handle: "folding-electric-silicone-kettle-600ml",
    title: "Folding Electric Silicone Kettle 600ML",
    bodyHtml: "<p>যারা ট্রাভেল করেন বা যারা সবসময় একটু গরম পানি বা চায়ের চিন্তায় থাকেন -তাদের জন্য নিয়ে এসেছি এই ভাঁজ করা যায় এমন ইলেকট্রিক কেটলি!</p>",
    vendor: "Online lifestyle",
    category: "Home & Garden > Kitchen & Dining > Kitchen Appliances > Electric Kettles",
    type: "Kettle",
    price: 820.00,
    compareAtPrice: 1600.00,
    imageSrc: "https://cdn.shopify.com/s/files/1/0721/3740/8556/files/folding-electric-silicone-kettle-600mlonline-lifestyle-3895051.jpg?v=1773924746",
    status: "active",
    options: [{ name: "Color", values: ["pink", "blue"] }]
  },
  {
    handle: "luxo-neon-edition",
    title: "Luxo Neon Edition",
    bodyHtml: "<p>The Luxo hard matte case keeps your iPhone slim, smooth, and scratch-free.</p>",
    vendor: "Online lifestyle",
    category: "Electronics > Communications > Telephony > Mobile & Smart Phone Accessories > Mobile Phone Cases",
    type: "",
    price: 1100.00,
    compareAtPrice: 1400.00,
    imageSrc: "https://cdn.shopify.com/s/files/1/0721/3740/8556/files/luxo-neon-editiononline-lifestyle-6606702.jpg?v=1773924752",
    status: "active",
    options: [{ name: "Model", values: ["17 pro max", "17 pro", "16 pro max", "16 pro", "15 pro max"] }]
  }
];

async function seed() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log("Connected to MongoDB for seeding");
    
    await Product.deleteMany({});
    console.log("Cleared existing products");
    
    await Product.insertMany(products);
    console.log("Seeded products successfully");
    
    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    console.error("Seeding error:", err);
    process.exit(1);
  }
}

seed();
