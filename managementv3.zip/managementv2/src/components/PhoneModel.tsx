import React, { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { RoundedBox, MeshRefractionMaterial, MeshTransmissionMaterial } from "@react-three/drei";
import * as THREE from "three";

export default function PhoneModel() {
  const meshRef = useRef<THREE.Group>(null);
  const bodyRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      // Smooth tilt following mouse
      const targetRotationX = (state.mouse.y * 0.2) + 0.4;
      const targetRotationY = (state.mouse.x * 0.3) - 0.4;
      
      meshRef.current.rotation.x = THREE.MathUtils.lerp(meshRef.current.rotation.x, targetRotationX, 0.1);
      meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, targetRotationY, 0.1);
      
      // Floating motion
      meshRef.current.position.y = Math.sin(performance.now() * 0.0005) * 0.1;
    }
  });

  return (
    <group ref={meshRef}>
      {/* Phone Body */}
      <RoundedBox
        ref={bodyRef}
        args={[3, 6, 0.4]} 
        radius={0.3}
        smoothness={8}
      >
        <meshPhysicalMaterial
          color="#0f172a"
          roughness={0.15}
          metalness={0.9}
          reflectivity={1}
          clearcoat={1}
          clearcoatRoughness={0.1}
        />
      </RoundedBox>

      {/* Internal Display Glow */}
      <mesh position={[0, 0, 0.21]}>
        <planeGeometry args={[2.75, 5.75]} />
        <meshStandardMaterial 
          color="#020617" 
          emissive="#4f46e5" 
          emissiveIntensity={0.8} 
        />
      </mesh>

      {/* Buttons - Right Side (Power) */}
      <RoundedBox args={[0.05, 0.8, 0.1]} radius={0.02} position={[1.52, 0.5, 0]}>
         <meshStandardMaterial color="#1e293b" metalness={1} roughness={0} />
      </RoundedBox>

      {/* Buttons - Left Side (Volume) */}
      <RoundedBox args={[0.05, 0.4, 0.1]} radius={0.02} position={[-1.52, 1, 0]}>
         <meshStandardMaterial color="#1e293b" metalness={1} roughness={0} />
      </RoundedBox>
      <RoundedBox args={[0.05, 0.4, 0.1]} radius={0.02} position={[-1.52, 0.4, 0]}>
         <meshStandardMaterial color="#1e293b" metalness={1} roughness={0} />
      </RoundedBox>

      {/* Camera Module (Back) */}
      <group position={[0.6, 2.1, -0.21]}>
         <RoundedBox args={[1.2, 1.2, 0.1]} radius={0.15}>
            <meshStandardMaterial color="#020617" metalness={1} roughness={0.2} />
         </RoundedBox>
         
         {/* Lenses */}
         <mesh position={[-0.25, 0.25, -0.05]} rotation={[Math.PI/2, 0, 0]}>
            <cylinderGeometry args={[0.22, 0.22, 0.1, 32]} />
            <meshPhysicalMaterial color="#000" metalness={1} roughness={0} />
         </mesh>
         <mesh position={[0.25, 0, -0.05]} rotation={[Math.PI/2, 0, 0]}>
            <cylinderGeometry args={[0.22, 0.22, 0.1, 32]} />
            <meshPhysicalMaterial color="#000" metalness={1} roughness={0} />
         </mesh>
         <mesh position={[-0.25, -0.25, -0.05]} rotation={[Math.PI/2, 0, 0]}>
            <cylinderGeometry args={[0.22, 0.22, 0.1, 32]} />
            <meshPhysicalMaterial color="#000" metalness={1} roughness={0} />
         </mesh>
      </group>

      {/* Branding Ring (Back) */}
      <mesh position={[0, 0, -0.211]} rotation={[0, 0, 0]}>
         <ringGeometry args={[0.4, 0.42, 64]} />
         <meshBasicMaterial color="#334155" transparent opacity={0.5} />
      </mesh>
    </group>
  );
}
