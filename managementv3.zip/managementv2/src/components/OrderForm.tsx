import React, { useState, useEffect } from "react";
import { Input } from "./ui/input";
import { MapPin, Loader2, Check, ChevronDown, User, Phone, Mail, Navigation, ClipboardList, Info } from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { useCart } from "../hooks/useCart";

interface Location {
  id: number;
  name: string;
}

interface OrderFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  locations: Location[];
  onZoneChange?: (zone: "inside_dhaka" | "outside_dhaka" | "") => void;
  initialLocation?: string;
}

const FormField = ({ label, children, required, icon: Icon }: any) => (
  <div className="space-y-2">
    <div className="flex items-center gap-2">
       {Icon && <Icon className="h-3.5 w-3.5 text-slate-400" />}
       <Label className="text-sm font-bold text-slate-700">
          {label} {required && <span className="text-indigo-600 ml-0.5">*</span>}
       </Label>
    </div>
    {children}
  </div>
);

export default function OrderForm({ 
  onSubmit, onCancel, locations, onZoneChange, initialLocation = ""
}: OrderFormProps) {
  const { total, discount, appliedCoupon, applyCoupon } = useCart();
  const [formData, setFormData] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    address: "",
    location: initialLocation,
    customerNote: "",
    deliveryZone: "" as "inside_dhaka" | "outside_dhaka" | ""
  });
  const [isValidating, setIsValidating] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [locationOpen, setLocationOpen] = useState(false);
  const locationRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (locationRef.current && !locationRef.current.contains(e.target as Node)) {
        setLocationOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.customerName.trim()) { toast.error("Please enter your name"); return; }
    if (!formData.customerPhone.trim()) { toast.error("Phone number is required"); return; }
    if (!formData.deliveryZone) { toast.error("Please select a delivery zone"); return; }
    if (!formData.address.trim()) { toast.error("Delivery address is required"); return; }
    
    const isValidLocation = locations.some(loc => loc.name.toLowerCase() === formData.location.toLowerCase());
    if (!formData.location || !isValidLocation) {
      toast.error("Please select a valid area");
      return;
    }

    setIsSubmitting(true);
    const deliveryCharge = formData.deliveryZone === "inside_dhaka" ? 80 : 120;
    onSubmit({ ...formData, deliveryCharge });
  };

  return (
    <form id="checkout-form" onSubmit={handleSubmit} className="space-y-10 text-left">
      
      {/* Customer Info */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 mb-2">
          <div className="h-5 w-1 bg-indigo-600 rounded-full" />
          <h3 className="text-lg font-bold text-slate-900">Contact Information</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField label="Full Name" icon={User} required>
             <Input 
               required 
               value={formData.customerName} 
               onChange={(e) => setFormData({ ...formData, customerName: e.target.value })} 
               placeholder="Enter your full name" 
               className="h-12 rounded-xl border-slate-200 focus:ring-indigo-100" 
             />
          </FormField>
          <FormField label="Phone Number" icon={Phone} required>
             <Input 
               required 
               value={formData.customerPhone} 
               onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })} 
               placeholder="01XXXXXXXXX" 
               className="h-12 rounded-xl border-slate-200 focus:ring-indigo-100" 
             />
          </FormField>
        </div>
        
        <FormField label="Email Address" icon={Mail}>
           <Input 
             type="email" 
             value={formData.customerEmail} 
             onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })} 
             placeholder="email@example.com (optional)" 
             className="h-12 rounded-xl border-slate-200 focus:ring-indigo-100" 
           />
        </FormField>
      </section>

      {/* SLogistics */}
      <section className="space-y-6 pt-6 border-t border-slate-100">
        <div className="flex items-center gap-2 mb-2">
          <div className="h-5 w-1 bg-indigo-600 rounded-full" />
          <h3 className="text-lg font-bold text-slate-900">Delivery Details</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            { id: "inside_dhaka", label: "Inside Dhaka", sub: "৳80 • 2-3 days", zone: "inside_dhaka" },
            { id: "outside_dhaka", label: "Outside Dhaka", sub: "৳120 • 3-5 days", zone: "outside_dhaka" }
          ].map((z) => (
            <button 
              key={z.id}
              type="button" 
              onClick={() => { setFormData({...formData, deliveryZone: z.zone as any}); onZoneChange?.(z.zone as any); }} 
              className={`p-5 rounded-2xl border text-left transition-all relative ${formData.deliveryZone === z.id ? "bg-indigo-50 border-indigo-600 ring-4 ring-indigo-50" : "bg-white border-slate-200 hover:border-slate-300"}`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-sm font-bold ${formData.deliveryZone === z.id ? "text-indigo-700" : "text-slate-900"}`}>{z.label}</span>
                {formData.deliveryZone === z.id && <Check className="h-4 w-4 text-indigo-600" />}
              </div>
              <p className={`text-xs ${formData.deliveryZone === z.id ? "text-indigo-600/70" : "text-slate-500"}`}>{z.sub}</p>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div ref={locationRef} className="relative">
            <FormField label="Area / Sector" icon={Navigation} required>
               <div className="relative group">
                 <Input 
                   value={formData.location} 
                   onChange={(e) => { setFormData({ ...formData, location: e.target.value }); setLocationOpen(true); }} 
                   onFocus={() => setLocationOpen(true)} 
                   placeholder="Select your area" 
                   className="h-12 rounded-xl border-slate-200 focus:ring-indigo-100 pr-10" 
                 />
                 <ChevronDown className={`absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 transition-transform ${locationOpen ? "rotate-180" : ""}`} />
               </div>
               
               <AnimatePresence>
                 {locationOpen && locations.length > 0 && (
                   <motion.div 
                     initial={{ opacity: 0, y: 5 }}
                     animate={{ opacity: 1, y: 0 }}
                     exit={{ opacity: 0, y: 5 }}
                     className="absolute z-50 w-full mt-2 bg-white rounded-xl shadow-xl border border-slate-100 overflow-hidden"
                   >
                     <div className="max-h-60 overflow-y-auto py-2 custom-scrollbar">
                       {locations.filter(loc => !formData.location || loc.name.toLowerCase().includes(formData.location.toLowerCase())).map((loc) => (
                         <button key={loc.id} type="button" onClick={() => { setFormData({ ...formData, location: loc.name }); setLocationOpen(false); }}
                           className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-slate-50 ${formData.location === loc.name ? "bg-indigo-50 text-indigo-700 font-bold" : "text-slate-600"}`}
                         >
                           <MapPin className="h-3.5 w-3.5" />
                           <span className="text-sm">{loc.name}</span>
                         </button>
                       ))}
                     </div>
                   </motion.div>
                 )}
               </AnimatePresence>
            </FormField>
          </div>

          <FormField label="Detailed Address" icon={MapPin} required>
             <Input 
               required 
               value={formData.address} 
               onChange={(e) => setFormData({ ...formData, address: e.target.value })} 
               placeholder="House, Road, Area details" 
               className="h-12 rounded-xl border-slate-200 focus:ring-indigo-100" 
             />
          </FormField>
        </div>
      </section>

      {/* Note */}
      <section className="space-y-4 pt-6 border-t border-slate-100">
        <FormField label="Order Note (Optional)" icon={ClipboardList}>
           <Textarea 
             value={formData.customerNote} 
             onChange={(e) => setFormData({ ...formData, customerNote: e.target.value })} 
             placeholder="Any specific delivery instructions?" 
             rows={3} 
             className="rounded-xl border-slate-200 focus:ring-indigo-100 resize-none" 
           />
        </FormField>
      </section>
      
      <button type="submit" className="hidden" />
    </form>
  );
}
