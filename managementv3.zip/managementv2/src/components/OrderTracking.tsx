import React, { useState } from "react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { 
  Search, Loader2, Package, Truck, Calendar, MapPin, 
  ChevronRight, ArrowLeft, ShieldCheck, Activity, Terminal, ExternalLink
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";

const STATUS_THEMES: Record<string, { color: string, glow: string }> = {
  "Pending": { color: "text-amber-400 bg-amber-400/10 border-amber-400/20", glow: "shadow-[0_0_15px_rgba(251,191,36,0.2)]" },
  "In Review": { color: "text-sky-400 bg-sky-400/10 border-sky-400/20", glow: "shadow-[0_0_15px_rgba(56,189,248,0.2)]" },
  "Shipped": { color: "text-indigo-400 bg-indigo-400/10 border-indigo-400/20", glow: "shadow-[0_0_15px_rgba(129,140,248,0.2)]" },
  "Delivered": { color: "text-emerald-400 bg-emerald-400/10 border-emerald-400/20", glow: "shadow-[0_0_15px_rgba(52,211,153,0.2)]" },
  "Returned": { color: "text-rose-400 bg-rose-400/10 border-rose-400/20", glow: "shadow-[0_0_15px_rgba(251,113,133,0.2)]" },
  "Cancelled": { color: "text-slate-400 bg-slate-400/10 border-slate-400/20", glow: "" }
};

export default function OrderTracking({ onBack }: { onBack: () => void }) {
  const [phone, setPhone] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [orders, setOrders] = useState<any[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);

  const handleSearch = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!phone || phone.length < 11) {
      toast.error("Please enter a valid phone number");
      return;
    }

    setIsLoading(true);
    try {
      // We use the existing orders endpoint but filter on frontend for security/simplicity 
      // In a real app, this would be a dedicated secure endpoint
      const response = await fetch("/api/orders");
      if (response.ok) {
        const data = await response.json();
        const found = data.filter((o: any) => o.customerPhone.includes(phone));
        setOrders(found);
        setHasSearched(true);
        if (found.length === 0) toast.error("No orders found for this number");
      }
    } catch (error) {
      toast.error("Network error");
    } finally {
      setIsLoading(false);
    }
  };

  if (selectedOrder) {
     return <OrderDetailsView order={selectedOrder} onBack={() => setSelectedOrder(null)} />;
  }

  return (
    <div className="min-h-screen pt-24 pb-20 px-4 md:px-6">
      <div className="max-w-4xl mx-auto space-y-12">
        
        {/* Header */}
        <div className="text-center space-y-4">
           <motion.div 
             initial={{ opacity: 0, scale: 0.9 }}
             animate={{ opacity: 1, scale: 1 }}
             className="inline-flex items-center gap-2 bg-indigo-600/10 px-4 py-2 rounded-2xl border border-indigo-500/20 text-indigo-400 mb-2"
           >
              <Activity className="h-4 w-4" />
              <span className="text-[10px] font-black uppercase tracking-[0.3em]">Quantum Tracking System</span>
           </motion.div>
           <h1 className="text-4xl md:text-6xl font-black text-white italic tracking-tighter uppercase leading-none">Track Your <span className="text-indigo-400">Armor</span></h1>
           <p className="text-slate-500 font-bold uppercase text-[10px] tracking-[0.2em] max-w-md mx-auto">Enter your credentials to access the delivery stream.</p>
        </div>

        {/* Search Input */}
        <motion.form 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          onSubmit={handleSearch}
          className="max-w-xl mx-auto relative group"
        >
           <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-[2.5rem] blur opacity-20 group-hover:opacity-40 transition duration-1000 group-focus-within:opacity-100" />
           <div className="relative flex gap-2">
              <div className="relative flex-1">
                 <Search className="absolute left-6 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                 <input 
                   type="tel"
                   placeholder="ENTER PHONE NUMBER..." 
                   value={phone}
                   onChange={(e) => setPhone(e.target.value)}
                   className="w-full h-16 pl-16 pr-6 bg-slate-900 border border-white/5 text-white placeholder:text-slate-700 rounded-[2rem] focus:ring-2 focus:ring-indigo-500 focus:bg-black transition-all uppercase text-xs font-black tracking-widest outline-none"
                 />
              </div>
              <Button type="submit" disabled={isLoading} className="h-16 px-8 rounded-[2rem] bg-indigo-600 hover:bg-white hover:text-indigo-600 text-white font-black uppercase text-[10px] tracking-widest transition-all">
                 {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : "SEARCH"}
              </Button>
           </div>
        </motion.form>

        {/* Results */}
        <div className="space-y-6">
           {hasSearched && orders.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {orders.map((order, idx) => (
                    <motion.div 
                      key={order._id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      onClick={() => setSelectedOrder(order)}
                      className="group bg-white/5 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/10 hover:border-indigo-500/50 transition-all cursor-pointer relative overflow-hidden"
                    >
                       <div className="relative z-10 flex flex-col h-full justify-between gap-6">
                          <div className="flex items-center justify-between">
                             <Badge className={`${STATUS_THEMES[order.status]?.color || ""} border-none font-black px-4 py-1.5 rounded-xl uppercase text-[9px] tracking-widest`}>
                                {order.status}
                             </Badge>
                             <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest italic">{new Date(order.createdAt).toLocaleDateString()}</span>
                          </div>
                          <div>
                             <p className="text-[9px] font-black text-indigo-400 uppercase tracking-widest leading-none mb-1">Order Identifier</p>
                             <p className="text-2xl font-black text-white italic tracking-tighter uppercase italic">{order.orderNumber}</p>
                          </div>
                          <div className="flex items-center justify-between pt-4 border-t border-white/5">
                             <span className="text-xl font-black text-white italic tabular-nums">৳{order.totalAmount?.toLocaleString()}</span>
                             <div className="h-10 w-10 rounded-xl bg-white/5 flex items-center justify-center group-hover:bg-indigo-600 transition-colors">
                                <ChevronRight className="h-5 w-5 text-indigo-400 group-hover:text-white" />
                             </div>
                          </div>
                       </div>
                    </motion.div>
                 ))}
              </div>
           )}
           {hasSearched && orders.length === 0 && !isLoading && (
              <div className="text-center py-20 bg-white/5 border border-white/5 rounded-[3rem] backdrop-blur-xl">
                 <Package className="h-12 w-12 text-slate-700 mx-auto mb-4" />
                 <p className="text-sm font-black text-slate-500 uppercase tracking-[0.2em]">No logs found for this signature.</p>
              </div>
           )}
        </div>
      </div>
    </div>
  );
}

function OrderDetailsView({ order, onBack }: { order: any, onBack: () => void }) {
  const theme = STATUS_THEMES[order.status] || STATUS_THEMES["Pending"];

  return (
    <div className="min-h-screen pt-24 pb-20 px-4 md:px-6">
       <div className="max-w-3xl mx-auto space-y-8">
          <button onClick={onBack} className="flex items-center gap-2 text-[10px] font-black text-slate-500 hover:text-indigo-400 uppercase tracking-widest transition-colors mb-4">
             <ArrowLeft className="h-4 w-4" /> Back to History
          </button>

          <div className="bg-white/5 backdrop-blur-3xl rounded-[3rem] border border-white/10 overflow-hidden shadow-2xl relative">
             {/* Header Section */}
             <div className="bg-gradient-to-br from-indigo-950/50 via-slate-900 to-indigo-950/50 p-10 md:p-14 text-white border-b border-white/5">
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-8">
                   <div className="space-y-4">
                      <div className="flex items-center gap-3">
                         <Terminal className="h-5 w-5 text-indigo-400" />
                         <span className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-400/70">System Audit Log</span>
                      </div>
                      <h2 className="text-5xl font-black tracking-tighter italic uppercase underline decoration-indigo-500/30 underline-offset-8">{order.orderNumber}</h2>
                      <div className="flex flex-wrap items-center gap-6">
                         <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-slate-500" />
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{new Date(order.createdAt).toLocaleString()}</span>
                         </div>
                         <div className="w-1.5 h-1.5 rounded-full bg-indigo-500/30" />
                         <span className="text-[10px] font-black text-indigo-400/80 uppercase tracking-widest italic">Verification: {(order._id).slice(-8)}</span>
                      </div>
                   </div>
                   <div className="text-right">
                      <div className={`px-8 py-4 rounded-[2rem] border ${theme.color} font-black text-[11px] uppercase tracking-[0.3em] italic ${theme.glow}`}>
                         {order.status}
                      </div>
                   </div>
                </div>
             </div>

             {/* Content */}
             <div className="p-8 md:p-14 space-y-12">
                {/* Visual Timeline */}
                <div className="space-y-6">
                   <div className="flex items-center gap-3">
                      <div className="h-px flex-1 bg-white/5" />
                      <span className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-500">Logistics Stream</span>
                      <div className="h-px flex-1 bg-white/5" />
                   </div>
                   <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {["Pending", "Review", "Shipped", "Delivered"].map((st, i) => {
                         const currentIdx = ["Pending", "In Review", "Shipped", "Delivered"].indexOf(order.status);
                         const isActive = currentIdx >= i;
                         return (
                            <div key={st} className="space-y-3">
                               <div className={`h-1.5 rounded-full transition-all duration-1000 ${isActive ? "bg-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.5)]" : "bg-white/5"}`} />
                               <p className={`text-[9px] font-black uppercase tracking-widest text-center ${isActive ? "text-white italic" : "text-slate-700"}`}>{st}</p>
                            </div>
                         );
                      })}
                   </div>
                </div>

                {/* Items */}
                <div className="space-y-6">
                   <div className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em] italic">Manifest Content</div>
                   <div className="space-y-3">
                      {order.items?.map((item: any, i: number) => (
                         <div key={i} className="bg-white/5 p-6 rounded-[2rem] border border-white/5 flex items-center justify-between">
                            <div className="flex items-center gap-6">
                               <div className="h-12 w-12 bg-indigo-600/20 border border-indigo-500/20 rounded-xl flex items-center justify-center font-black text-indigo-400 text-sm">
                                  {item.quantity}
                               </div>
                               <div>
                                  <p className="text-sm font-black text-white uppercase italic tracking-tight leading-none">{item.title}</p>
                                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">{item.variant || "Standard Armor"}</p>
                               </div>
                            </div>
                         </div>
                      ))}
                   </div>
                </div>

                {/* Summary */}
                <div className="bg-white/5 rounded-[2.5rem] p-8 border border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
                   <div className="space-y-1 text-center md:text-left">
                      <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest italic">Operational Value</p>
                      <p className="text-4xl font-black text-white italic tracking-tighter tabular-nums">৳{order.totalAmount?.toLocaleString()}</p>
                   </div>
                   {order.trackingCode && (
                      <a 
                        href={`https://steadfast.com.bd/t/${order.trackingCode}`} 
                        target="_blank" 
                        className="h-14 px-8 rounded-[1.5rem] bg-indigo-600 hover:bg-white hover:text-indigo-600 text-white font-black uppercase text-[10px] tracking-[0.2em] italic flex items-center gap-3 transition-all"
                      >
                         Track Pulse <ExternalLink className="h-4 w-4" />
                      </a>
                   )}
                </div>
             </div>
          </div>
       </div>
    </div>
  );
}
