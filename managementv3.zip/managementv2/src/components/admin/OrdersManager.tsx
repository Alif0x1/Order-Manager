import React, { useState, useEffect, useMemo } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { 
  Search, RefreshCw, Truck, BarChart3, ListFilter,
  ArrowUpRight, ShoppingBag, CreditCard, Layers, X
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { Card, CardContent } from "../ui/card";

// Internal Components
import { OrderCard } from "./orders/OrderCard";
import { OrderDetailModal } from "./orders/OrderDetailModal";
import { Order, STATUS_THEMES, getBannerColor } from "./orders/types";

export default function OrdersManager() {
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDataLoading, setIsDataLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isUpdating, setIsUpdating] = useState<string | null>(null);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showSteadfastOnly, setShowSteadfastOnly] = useState(false);
  const [steadfastBalance, setSteadfastBalance] = useState<number | null>(null);

  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [steadfastStatus, setSteadfastStatus] = useState<string | null>(null);
  const [isSteadfastLoading, setIsSteadfastLoading] = useState(false);

  const fetchSteadfastBalance = async () => {
    try {
      const res = await fetch("/api/steadfast/balance");
      if (res.ok) {
        const data = await res.json();
        setSteadfastBalance(data.current_balance || 0);
      }
    } catch (e) {
      console.error("Balance sync failed");
    }
  };

  const fetchLiveSteadfastStatus = async (orderId: string) => {
    if (!orderId) return;
    setIsSteadfastLoading(true);
    setSteadfastStatus(null);
    try {
      const response = await fetch(`/api/steadfast/status/${orderId}`);
      if (response.ok) {
        const data = await response.json();
        setSteadfastStatus(data.delivery_status || "Unknown Status");
      } else {
        setSteadfastStatus("Sync Required");
      }
    } catch (error) {
      setSteadfastStatus("Offline");
    } finally {
      setIsSteadfastLoading(false);
    }
  };

  const fetchAllOrders = async () => {
    setIsDataLoading(true);
    setIsLoading(true);
    try {
      const response = await fetch("/api/orders");
      if (response.ok) {
        const data = await response.json();
        setAllOrders(Array.isArray(data) ? data : []);
        fetchSteadfastBalance();
      }
    } catch (error) {
      console.error("Sync error", error);
      toast.error("Failed to sync orders");
    } finally {
      setIsDataLoading(false);
      setIsLoading(false);
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    setIsUpdating(orderId);
    try {
      const response = await fetch(`/api/orders/${orderId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
      if (response.ok) {
        const updated = await response.json();
        setAllOrders(prev => prev.map(o => o._id === orderId ? updated : o));
        if (selectedOrder?._id === orderId) setSelectedOrder(updated);
        toast.success(`Order status updated to ${newStatus}`);
      }
    } catch (error) {
      toast.error("Failed to update status");
    } finally {
      setIsUpdating(null);
    }
  };

  const handleBulkStatusUpdate = async (newStatus: string) => {
    if (selectedIds.length === 0) return;
    setIsDataLoading(true);
    try {
      const response = await fetch("/api/orders/bulk/status", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: selectedIds, status: newStatus }),
      });
      if (response.ok) {
        setAllOrders(prev => prev.map(o => 
          selectedIds.includes(o._id) ? { ...o, status: newStatus } : o
        ));
        setSelectedIds([]);
        toast.success(`Updated ${selectedIds.length} orders to ${newStatus}`);
      }
    } catch (error) {
      toast.error("Bulk status update failed");
    } finally {
      setIsDataLoading(false);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!confirm(`Are you absolutely sure you want to PERMANENTLY delete ${selectedIds.length} orders? This cannot be undone.`)) return;
    
    setIsDataLoading(true);
    try {
      const response = await fetch("/api/orders/bulk", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: selectedIds }),
      });
      if (response.ok) {
        setAllOrders(prev => prev.filter(o => !selectedIds.includes(o._id)));
        setSelectedIds([]);
        toast.success(`Permanently purged ${selectedIds.length} records`);
      }
    } catch (error) {
      toast.error("Bulk deletion failed");
    } finally {
      setIsDataLoading(false);
    }
  };

  const toggleSelection = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const deleteOrder = async (orderId: string) => {
    setIsUpdating(orderId);
    try {
      const response = await fetch(`/api/orders/${orderId}`, { method: "DELETE" });
      if (response.ok) {
        setAllOrders(prev => prev.filter(o => o._id !== orderId));
        setSelectedOrder(null);
        toast.success("Order purged entirely");
      }
    } catch (error) {
      toast.error("Failed to delete order");
    } finally {
      setIsUpdating(null);
    }
  };

  const sendToSteadfast = async (orderId: string) => {
    setIsUpdating(orderId);
    try {
      const response = await fetch(`/api/orders/${orderId}/send-to-steadfast`, {
        method: "POST",
      });
      const data = await response.json();
      if (response.ok) {
        setAllOrders(prev => prev.map(o => o._id === orderId ? data : o));
        if (selectedOrder?._id === orderId) setSelectedOrder(data);
        toast.success("Synchronized with Steadfast Logistics");
        fetchLiveSteadfastStatus(orderId);
      } else {
        toast.error(data.error || "Courier rejection");
      }
    } catch (error) {
      toast.error("Bridge failure");
    } finally {
      setIsUpdating(null);
    }
  };

  useEffect(() => {
    fetchAllOrders();
  }, []);

  useEffect(() => {
    if (selectedOrder?._id && selectedOrder.trackingCode) {
       fetchLiveSteadfastStatus(selectedOrder._id);
    }
  }, [selectedOrder]);

  const filteredOrders = useMemo(() => {
    let orders = allOrders.filter(order => 
      (order.orderNumber || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
      (order.customerName || "").toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    if (showSteadfastOnly) {
      orders = orders.filter(o => o.consignmentId || o.trackingCode);
    }

    if (startDate || endDate) {
      orders = orders.filter(order => {
        const orderDate = new Date(order.createdAt).toISOString().slice(0, 10);
        if (startDate && orderDate < startDate) return false;
        if (endDate && orderDate > endDate) return false;
        return true;
      });
    }
    
    return orders.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [allOrders, searchQuery, startDate, endDate, showSteadfastOnly]);

  const totalRevenue = filteredOrders.reduce((s, o) => s + (Number(o.totalAmount) || 0), 0);
  const totalDeliveryFees = filteredOrders.reduce((s, o) => s + (Number(o.deliveryCharge) || 0), 0);

  return (
    <div className="space-y-10 pb-20 max-w-7xl mx-auto px-6 sm:px-10">
      
      {/* Search & Stats Header */}
      <div className="flex flex-col items-center text-center space-y-10">
        <div className="space-y-4">
           <div className="flex flex-col items-center gap-5">
              <div className="h-16 w-16 bg-indigo-600 rounded-3xl flex items-center justify-center text-white shadow-2xl shadow-indigo-200 animate-in zoom-in duration-700">
                 <ShoppingBag className="h-8 w-8" />
              </div>
              <h1 className="text-3xl sm:text-5xl font-black text-slate-900 tracking-tighter">Order Logistics</h1>
           </div>
           <p className="text-sm font-black text-slate-400 uppercase tracking-[0.3em]">Operational Flow & Global Fulfillment</p>
        </div>
        
        <div className="flex flex-col items-center gap-6 w-full max-w-4xl">
           <div className="flex flex-col sm:flex-row gap-4 w-full">
              <div className="relative flex-[1.5] group">
                 <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
                 <Input 
                   placeholder="Search order registry, customers..." 
                   value={searchQuery}
                   onChange={(e) => setSearchQuery(e.target.value)}
                   className="h-16 pl-14 rounded-[1.5rem] bg-white border-slate-200 focus:ring-8 focus:ring-indigo-50/50 transition-all font-bold text-slate-700 text-lg shadow-sm"
                 />
              </div>
              <div className="flex-[2] flex gap-4">
                 <div className="relative flex-1 group">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[8px] font-black text-slate-400 uppercase tracking-widest z-10 pointer-events-none">Start</span>
                    <Input 
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="h-16 pl-16 rounded-[1.5rem] bg-white border-slate-200 focus:ring-8 focus:ring-indigo-50/50 transition-all font-bold text-slate-700 text-sm shadow-sm uppercase"
                    />
                 </div>
                 <div className="relative flex-1 group">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[8px] font-black text-slate-400 uppercase tracking-widest z-10 pointer-events-none">End</span>
                    <Input 
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="h-16 pl-16 rounded-[1.5rem] bg-white border-slate-200 focus:ring-8 focus:ring-indigo-50/50 transition-all font-bold text-slate-700 text-sm shadow-sm uppercase"
                    />
                 </div>
                 {(startDate || endDate) && (
                   <button 
                     onClick={() => { setStartDate(""); setEndDate(""); }}
                     className="p-2 text-slate-400 hover:text-rose-500 transition-colors"
                   >
                     <X className="h-5 w-5" />
                   </button>
                 )}
              </div>
              <div className="flex gap-3">
                 <Button 
                   variant={showSteadfastOnly ? "default" : "outline"}
                   onClick={() => setShowSteadfastOnly(!showSteadfastOnly)}
                   className={`h-16 px-8 rounded-[1.5rem] font-black uppercase text-[10px] tracking-widest transition-all ${
                     showSteadfastOnly 
                       ? "bg-slate-900 text-white shadow-2xl" 
                       : "bg-white border-slate-200 text-slate-500 hover:text-indigo-600 shadow-sm"
                   }`}
                 >
                   <Truck className="h-5 w-5 mr-3" />
                   Logistics Flow
                 </Button>
                 <Button 
                   onClick={fetchAllOrders} 
                   disabled={isDataLoading} 
                   variant="outline" 
                   className="h-16 w-16 rounded-[1.5rem] bg-white border-slate-200 hover:bg-slate-50 shadow-sm shrink-0"
                 >
                    <RefreshCw className={`h-5 w-5 ${isDataLoading ? "animate-spin" : ""}`} />
                 </Button>
              </div>
           </div>
        </div>
      </div>
      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <MetricSmall title="Net Sales" value={`৳${(totalRevenue - totalDeliveryFees).toLocaleString()}`} icon={BarChart3} color="indigo" />
        <MetricSmall title="Active Orders" value={filteredOrders.length} icon={Layers} color="slate" />
        <MetricSmall title="Total Revenue" value={`৳${totalRevenue.toLocaleString()}`} icon={ArrowUpRight} color="emerald" />
        <Card className="rounded-[2.5rem] border-slate-100 shadow-sm bg-indigo-600 text-white overflow-hidden relative group">
           <div className="absolute top-0 right-0 p-10 opacity-10 group-hover:scale-110 transition-transform">
              <CreditCard className="h-24 w-24" />
           </div>
           <CardContent className="h-full flex flex-col justify-center items-center text-center p-8 space-y-2 relative">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-100/70">Carrier Credit</p>
              <p className="text-3xl font-black tracking-tighter">৳{steadfastBalance?.toLocaleString() || "0"}</p>
              <div className="flex items-center gap-2 text-[8px] font-black uppercase tracking-widest text-indigo-100/80 mt-2">
                 <div className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                 Bridge Stable
              </div>
           </CardContent>
        </Card>
      </div>

      {/* Status Bar */}
      <Card className="rounded-[3rem] border-slate-100 shadow-sm overflow-hidden bg-white">
         <CardContent className="p-10 space-y-10 flex flex-col items-center text-center">
            <div className="space-y-2">
               <h3 className="text-lg font-black text-slate-900 tracking-tight">Status Distribution</h3>
               <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{allOrders.length} records in active directory</p>
            </div>
            
            <div className="h-4 w-full max-w-4xl bg-slate-50 border border-slate-100 rounded-full overflow-hidden flex gap-1 p-1">
               {Object.keys(STATUS_THEMES).map((status) => {
                 const count = allOrders.filter(o => o.status === status).length;
                 const percent = allOrders.length ? (count / allOrders.length) * 100 : 0;
                 if (percent === 0) return null;
                 const colorClass = STATUS_THEMES[status].color.split(' ').find(c => c.startsWith('bg-'))?.replace('50', '500') || 'bg-slate-400';
                 return (
                   <motion.div 
                     key={status}
                     initial={{ width: 0 }}
                     animate={{ width: `${percent}%` }}
                     className={`h-full rounded-full ${colorClass} group relative cursor-pointer active:scale-95 transition-transform`}
                   >
                      <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all z-10 pointer-events-none shadow-2xl">
                         {status} • {count}
                      </div>
                   </motion.div>
                 );
               })}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-10 w-full max-w-5xl">
               {Object.keys(STATUS_THEMES).map((status) => (
                 <div key={status} className="flex flex-col items-center gap-3">
                    <div className="flex items-center gap-2">
                       <div className={`h-2.5 w-2.5 rounded-full ${getBannerColor(status)} shadow-sm`} />
                       <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{status}</span>
                    </div>
                    <p className="text-3xl font-black text-slate-900 leading-none tracking-tighter">{allOrders.filter(o => o.status === status).length}</p>
                 </div>
               ))}
            </div>
         </CardContent>
      </Card>

      {/* Orders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <AnimatePresence>
          {isLoading ? (
            Array(8).fill(0).map((_, i) => (
              <div key={i} className="h-64 bg-white rounded-3xl border border-slate-100 animate-pulse" />
            ))
          ) : (
            filteredOrders.map((order, idx) => (
              <OrderCard 
                key={order._id || idx} 
                order={order} 
                index={idx}
                isSelected={selectedIds.includes(order._id)}
                onSelect={toggleSelection}
                onView={() => setSelectedOrder(order)} 
              />
            ))
          )}
        </AnimatePresence>
      </div>

      <OrderDetailModal 
        isOpen={!!selectedOrder}
        order={selectedOrder}
        onClose={() => setSelectedOrder(null)}
        onUpdateStatus={updateOrderStatus}
        onSendToSteadfast={sendToSteadfast}
        onRefreshSteadfast={fetchLiveSteadfastStatus}
        onDelete={deleteOrder}
        isUpdating={!!isUpdating}
        isSteadfastLoading={isSteadfastLoading}
        steadfastStatus={steadfastStatus}
      />

      {/* Bulk Action Toolbar */}
      <AnimatePresence>
        {selectedIds.length > 0 && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[100] w-full max-w-2xl px-6"
          >
            <div className="bg-slate-900 text-white rounded-[2.5rem] p-6 shadow-2xl flex items-center justify-between gap-8 border border-slate-800">
               <div className="flex items-center gap-6">
                  <div className="h-12 w-12 bg-indigo-600 rounded-2xl flex items-center justify-center font-black">
                     {selectedIds.length}
                  </div>
                  <div>
                     <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Tactical selection</p>
                     <p className="text-sm font-bold tracking-tight">Active Operation Phase</p>
                  </div>
               </div>
               
               <div className="flex items-center gap-3">
                  <div className="flex items-center bg-slate-800 rounded-xl p-1">
                    {Object.keys(STATUS_THEMES).slice(0, 4).map(status => (
                       <button 
                         key={status}
                         onClick={() => handleBulkStatusUpdate(status)}
                         className="px-4 py-2 hover:bg-slate-700 rounded-lg text-[9px] font-black uppercase tracking-widest transition-colors"
                       >
                         {status}
                       </button>
                    ))}
                  </div>
                  <Button 
                    variant="ghost" 
                    onClick={handleBulkDelete}
                    className="h-12 w-12 rounded-xl text-rose-500 hover:bg-rose-500/10 transition-colors"
                  >
                     <X className="h-5 w-5" />
                  </Button>
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function MetricSmall({ title, value, icon: Icon, color }: any) {
  const themes: any = {
    indigo: "text-indigo-600 bg-indigo-50 border-indigo-100",
    emerald: "text-emerald-600 bg-emerald-50 border-emerald-100",
    slate: "text-slate-600 bg-slate-50 border-slate-100"
  };

  return (
    <Card className="rounded-[2.5rem] p-6 sm:p-10 border border-slate-100 shadow-sm bg-white group hover:border-indigo-200 transition-all duration-300 flex flex-col items-center text-center justify-center">
        <div className={`h-12 w-12 sm:h-14 sm:w-14 rounded-2xl flex items-center justify-center border transition-transform duration-500 group-hover:scale-110 mb-4 sm:mb-6 ${themes[color]}`}>
           <Icon className="h-5 w-5 sm:h-6 sm:w-6" />
        </div>
        <div className="flex flex-col items-center">
           <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] leading-none mb-2 sm:mb-3">{title}</p>
           <p className="text-2xl sm:text-3xl font-black text-slate-900 tabular-nums leading-none tracking-tighter">{value}</p>
        </div>
    </Card>
  );
}
