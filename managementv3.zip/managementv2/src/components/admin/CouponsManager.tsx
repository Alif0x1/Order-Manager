import React, { useState, useEffect } from "react";
import { Plus, Ticket, Loader2, ShieldCheck, Zap, Percent, DollarSign, Award, Edit3, Trash2, Tag, Gift, Info, ChevronRight, Hash, RefreshCw, Scissors } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../ui/dialog";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../ui/card";

interface CouponItem {
  _id?: string;
  code: string;
  type: "percentage" | "fixed";
  value: number;
  minOrder: number;
  active: boolean;
}

export default function CouponsManager() {
  const [coupons, setCoupons] = useState<CouponItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDataLoading, setIsDataLoading] = useState(false);
  const [isUpdating, setIsUpdating] = useState<string | null>(null);

  const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<CouponItem | null>(null);
  const [couponFormData, setCouponFormData] = useState<CouponItem>({
    code: "",
    type: "percentage",
    value: 0,
    minOrder: 0,
    active: true
  });

  useEffect(() => {
    fetchCoupons();
  }, []);

  const fetchCoupons = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/coupons");
      if (response.ok) {
        const data = await response.json();
        setCoupons(data);
      }
    } catch (error) {
      toast.error("Failed to sync coupons");
    } finally {
      setIsLoading(false);
      setIsDataLoading(false);
    }
  };

  const handleCouponSubmit = async () => {
    if (!couponFormData.code) {
      toast.error("Please enter a coupon code");
      return;
    }
    setIsDataLoading(true);
    const method = editingCoupon ? "PATCH" : "POST";
    const url = editingCoupon ? `/api/coupons/${editingCoupon._id}` : "/api/coupons";
    try {
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...couponFormData, code: couponFormData.code.toUpperCase() })
      });
      if (response.ok) {
        toast.success(`Coupon ${editingCoupon ? "updated" : "created"} successfully!`);
        setIsCouponModalOpen(false);
        fetchCoupons();
      } else {
        toast.error("Failed to save coupon");
      }
    } catch (error) {
      toast.error("Network error");
    } finally {
      setIsDataLoading(false);
    }
  };

  const toggleCouponActive = async (coupon: CouponItem) => {
    try {
      const response = await fetch(`/api/coupons/${coupon._id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active: !coupon.active })
      });
      if (response.ok) {
        toast.success(`Coupon ${coupon.code} ${coupon.active ? "disabled" : "enabled"}`);
        fetchCoupons();
      }
    } catch (error) {
      toast.error("Failed to toggle status");
    }
  };

  const deleteCoupon = async (couponId: string) => {
    if (!confirm("Are you sure you want to delete this coupon? This cannot be undone.")) return;
    setIsUpdating(couponId);
    try {
      const response = await fetch(`/api/coupons/${couponId}`, { method: "DELETE" });
      if (response.ok) {
        toast.success("Coupon removed from system");
        fetchCoupons();
      }
    } catch (error) {
      toast.error("Failed to delete coupon");
    } finally {
      setIsUpdating(null);
    }
  };

  const openAddCoupon = () => {
    setEditingCoupon(null);
    setCouponFormData({ code: "", type: "percentage", value: 0, minOrder: 0, active: true });
    setIsCouponModalOpen(true);
  };

  const handleEditCoupon = (coupon: CouponItem) => {
    setEditingCoupon(coupon);
    setCouponFormData(coupon);
    setIsCouponModalOpen(true);
  };

  return (
    <div className="space-y-10 pb-20 max-w-7xl mx-auto px-6 sm:px-10">
      
      {/* Header Area */}
      <div className="flex flex-col items-center text-center space-y-8">
        <div className="space-y-3">
           <div className="flex flex-col items-center gap-4">
              <div className="h-14 w-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-200 animate-in zoom-in duration-500">
                 <Ticket className="h-7 w-7" />
              </div>
              <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tighter">Coupon System</h1>
           </div>
           <p className="text-sm font-bold text-slate-400 uppercase tracking-[0.2em]">Promotional Infrastructure & Growth Control</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full max-w-md">
           <Button onClick={openAddCoupon} className="flex-1 w-full h-14 rounded-[1.25rem] bg-slate-900 hover:bg-black text-white font-black uppercase text-xs tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95">
             <Plus className="h-5 w-5" />
             New Directive
           </Button>
           <Button onClick={fetchCoupons} disabled={isLoading} variant="outline" className="h-14 w-14 rounded-[1.25rem] bg-white border-slate-200 hover:bg-slate-50 transition-all shrink-0">
              <RefreshCw className={`h-5 w-5 ${isLoading ? "animate-spin" : ""}`} />
           </Button>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
         <MetricBox label="Active Coupons" value={coupons.filter(c => c.active).length} icon={ShieldCheck} color="indigo" />
         <MetricBox label="Discount Volume" value={coupons.length} icon={TrendingUp} color="emerald" />
         <MetricBox label="Expiring Soon" value={0} icon={Award} color="rose" />
      </div>

      {/* Main Listing */}
      <Card className="rounded-[2.5rem] border-slate-100 shadow-sm overflow-hidden bg-white">
        <CardHeader className="px-8 py-10 border-b border-slate-50 flex flex-col items-center text-center">
           <div className="flex flex-col items-center gap-4">
              <div className="h-12 w-12 bg-indigo-50 rounded-2xl flex items-center justify-center border border-indigo-100/50">
                 <Gift className="h-6 w-6 text-indigo-600" />
              </div>
              <div>
                 <CardTitle className="text-xl font-black text-slate-900 tracking-tight">Promotion Registry</CardTitle>
                 <CardDescription className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1.5">{coupons.length} codes registered in system</CardDescription>
              </div>
           </div>
        </CardHeader>
        <CardContent className="p-8 sm:p-10 bg-slate-50/30">
          <div className="space-y-4 text-left">
            <AnimatePresence mode="popLayout">
              {isLoading && coupons.length === 0 ? (
                <div className="h-64 flex flex-col items-center justify-center gap-4 text-slate-300">
                   <Loader2 className="h-10 w-10 animate-spin" />
                   <p className="text-sm font-bold uppercase tracking-widest text-slate-400">Syncing database...</p>
                </div>
              ) : coupons.length === 0 ? (
                <div className="h-64 flex flex-col items-center justify-center gap-4 text-center">
                   <div className="h-16 w-16 bg-slate-100 rounded-full flex items-center justify-center mb-2">
                      <Ticket className="h-8 w-8 text-slate-300" />
                   </div>
                   <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">No active coupons found</p>
                   <Button onClick={openAddCoupon} variant="outline" className="rounded-xl border-slate-200">Add First Coupon</Button>
                </div>
              ) : (
                coupons.map((coupon: CouponItem) => (
                  <CouponNode 
                    key={coupon._id} 
                    coupon={coupon} 
                    onToggle={() => toggleCouponActive(coupon)}
                    onEdit={() => handleEditCoupon(coupon)}
                    onDelete={() => deleteCoupon(coupon._id!)}
                  />
                ))
              )}
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>

      {/* Coupon Modal */}
      <Dialog open={isCouponModalOpen} onOpenChange={setIsCouponModalOpen}>
        <DialogContent className="sm:max-w-xl rounded-[2.5rem] p-0 overflow-hidden border-slate-200 shadow-2xl bg-white">
          <div className="px-10 py-8 border-b border-slate-100 bg-slate-50/50 text-left">
             <div className="flex items-center gap-3 mb-2">
                <div className="h-10 w-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
                   <Zap className="h-5 w-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-600">Promotion Settings</span>
             </div>
             <DialogHeader>
                <DialogTitle className="text-2xl font-bold text-slate-900 tracking-tight">
                   {editingCoupon ? "Edit Offer Code" : "Create Offer Code"}
                </DialogTitle>
                <DialogDescription className="text-slate-500 font-medium text-xs mt-1">
                   Configure discount values and eligibility thresholds.
                </DialogDescription>
             </DialogHeader>
          </div>
          
          <div className="p-10 space-y-8 text-left max-h-[60vh] overflow-y-auto no-scrollbar">
            <div className="space-y-2">
              <Label className="text-xs font-bold text-slate-500 ml-1">Coupon Code</Label>
              <Input
                value={couponFormData.code}
                onChange={(e) => setCouponFormData({...couponFormData, code: e.target.value.toUpperCase()})}
                placeholder="FREE50, SUMMER24, etc."
                className="h-14 border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-50 font-bold text-xl px-6 uppercase tracking-wider"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-4">
                  <Label className="text-xs font-bold text-slate-500 ml-1">Discount Type</Label>
                  <div className="flex flex-col gap-3">
                    <button
                      type="button"
                      onClick={() => setCouponFormData({...couponFormData, type: "percentage"})}
                      className={`flex items-center gap-4 h-12 rounded-xl border transition-all px-5 ${
                        couponFormData.type === "percentage" ? "border-indigo-600 bg-indigo-50 text-indigo-600" : "border-slate-200 bg-white text-slate-400 hover:bg-slate-50"
                      }`}
                    >
                      <Percent className="h-4 w-4" />
                      <span className="text-xs font-bold uppercase">Percentage</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setCouponFormData({...couponFormData, type: "fixed"})}
                      className={`flex items-center gap-4 h-12 rounded-xl border transition-all px-5 ${
                        couponFormData.type === "fixed" ? "border-indigo-600 bg-indigo-50 text-indigo-600" : "border-slate-200 bg-white text-slate-400 hover:bg-slate-50"
                      }`}
                    >
                      <DollarSign className="h-4 w-4" />
                      <span className="text-xs font-bold uppercase">Fixed Amount</span>
                    </button>
                  </div>
               </div>

               <div className="space-y-6">
                  <div className="space-y-2">
                    <Label className="text-xs font-bold text-slate-500 ml-1">Value ({couponFormData.type === 'percentage' ? '%' : '৳'})</Label>
                    <Input
                      type="number"
                      value={couponFormData.value}
                      onChange={(e) => setCouponFormData({...couponFormData, value: Number(e.target.value)})}
                      className="h-12 border-slate-200 bg-indigo-50/50 text-indigo-600 rounded-xl focus:ring-4 focus:ring-indigo-50 font-bold text-lg tabular-nums"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-bold text-slate-500 ml-1">Minimum Order (৳)</Label>
                    <Input
                      type="number"
                      value={couponFormData.minOrder}
                      onChange={(e) => setCouponFormData({...couponFormData, minOrder: Number(e.target.value)})}
                      className="h-12 border-slate-200 bg-white rounded-xl focus:ring-4 focus:ring-indigo-50 font-bold text-lg tabular-nums"
                    />
                  </div>
               </div>
            </div>
          </div>

          <div className="p-8 border-t border-slate-100 bg-slate-50/50 flex gap-4">
             <Button variant="ghost" onClick={() => setIsCouponModalOpen(false)} className="h-12 flex-1 rounded-xl text-slate-400 font-bold uppercase text-[10px] tracking-widest hover:bg-white hover:text-slate-900 border border-transparent">
                Cancel
             </Button>
             <Button 
               onClick={handleCouponSubmit} 
               disabled={isDataLoading || !couponFormData.code} 
               className="h-12 flex-[2] rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold uppercase text-[10px] tracking-widest shadow-lg shadow-indigo-100 transition-all"
             >
               {isDataLoading ? <Loader2 className="h-6 w-6 animate-spin" /> : (editingCoupon ? "Save Changes" : "Create Coupon")}
             </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function CouponNode({ coupon, onToggle, onEdit, onDelete }: any) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className={`relative group rounded-[2.5rem] border p-8 flex flex-col items-center text-center gap-8 transition-all duration-300 ${
        coupon.active 
          ? "bg-white border-slate-100 shadow-sm hover:shadow-xl hover:shadow-indigo-50/50 hover:border-indigo-100" 
          : "bg-slate-50 border-slate-100 opacity-60"
      }`}
    >
      <div className="flex flex-col items-center gap-6 w-full">
         <div className="flex flex-col items-center gap-3">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] leading-none mb-1">Authorization Code</p>
            <div className="flex flex-col items-center gap-4">
               <div className={`h-16 w-16 rounded-[1.25rem] flex items-center justify-center border transition-all duration-500 ${coupon.active ? "bg-indigo-600 text-white shadow-xl shadow-indigo-200" : "bg-white text-slate-300 border-slate-200"}`}>
                  <Hash className="h-8 w-8" />
               </div>
               <span className="text-4xl font-black text-slate-900 tracking-tighter uppercase">{coupon.code}</span>
            </div>
         </div>

         <div className="grid grid-cols-2 gap-12 w-full max-w-sm pt-4 border-t border-slate-50">
            <div className="flex flex-col items-center gap-1">
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-2">Benefit</p>
               <span className="text-2xl font-black text-indigo-600 tabular-nums leading-none tracking-tighter">
                  {coupon.type === "percentage" ? `${coupon.value}%` : `৳${coupon.value}`}
               </span>
               <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Offered</span>
            </div>

            <div className="flex flex-col items-center gap-1">
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-2">Threshold</p>
               <span className="text-2xl font-black text-slate-900 tabular-nums leading-none tracking-tighter">৳{coupon.minOrder.toLocaleString()}</span>
               <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Order Min</span>
            </div>
         </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-sm">
        <Button 
          onClick={onToggle}
          className={`h-12 flex-1 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg ${
            coupon.active 
              ? "bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white shadow-rose-100" 
              : "bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white shadow-emerald-100"
          }`}
        >
          {coupon.active ? "Deactivate" : "Authorize"}
        </Button>
        <div className="flex gap-2">
           <button onClick={onEdit} className="h-12 w-12 rounded-2xl bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-100 transition-all flex items-center justify-center">
             <Edit3 className="h-5 w-5" />
           </button>
           <button onClick={onDelete} className="h-12 w-12 rounded-2xl bg-slate-50 text-slate-400 hover:text-rose-500 hover:bg-rose-50 border border-slate-100 transition-all flex items-center justify-center">
             <Trash2 className="h-5 w-5" />
           </button>
        </div>
      </div>
    </motion.div>
  );
}

function MetricBox({ label, value, icon: Icon, color }: any) {
  const themes: any = {
    indigo: "text-indigo-600 bg-indigo-50 border-indigo-100",
    emerald: "text-emerald-600 bg-emerald-50 border-emerald-100",
    rose: "text-rose-600 bg-rose-50 border-rose-100"
  };

  return (
    <Card className={`rounded-[2.5rem] p-6 sm:p-10 border shadow-sm group flex flex-col items-center justify-center text-center bg-white hover:border-indigo-200 transition-all duration-300`}>
       <div className={`h-12 w-12 sm:h-14 sm:w-14 rounded-2xl flex items-center justify-center border transition-transform duration-500 group-hover:scale-110 mb-4 sm:mb-6 ${themes[color]}`}>
          <Icon className="h-5 w-5 sm:h-6 sm:w-6" />
       </div>
       <div className="flex flex-col items-center">
          <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] leading-none mb-2 sm:mb-3">{label}</p>
          <p className="text-2xl sm:text-4xl font-black text-slate-900 tabular-nums leading-none tracking-tighter">{value}</p>
       </div>
    </Card>
  );
}

function TrendingUp(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
      <polyline points="16 7 22 7 22 13" />
    </svg>
  );
}
