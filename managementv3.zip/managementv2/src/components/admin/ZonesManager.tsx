import React, { useState, useEffect } from "react";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "../ui/dialog";
import { 
  MapPin, Plus, Edit3, Trash2, Loader2, 
  ShoppingBag, Globe, Zap, Network, Activity,
  Terminal, ShieldCheck, ChevronRight, RefreshCw,
  Search, Target, LayoutGrid, ArrowUpRight, TrendingUp
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../ui/card";

export default function ZonesManager() {
  const [locations, setLocations] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Dialog States
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingZone, setEditingZone] = useState<any>(null);
  
  // Form States
  const [zoneName, setZoneName] = useState("");
  const [zoneStatus, setZoneStatus] = useState("Active");

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/locations");
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      }
    } catch (error) {
      toast.error("Failed to sync delivery areas");
    } finally {
      setIsLoading(false);
    }
  };

  const createZone = async () => {
    if (!zoneName.trim()) return toast.error("Please enter a zone name");
    setIsProcessing(true);
    try {
      const response = await fetch("/api/locations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: zoneName, status: zoneStatus }),
      });
      if (response.ok) {
        toast.success("Delivery zone added successfully");
        setIsAddOpen(false);
        setZoneName("");
        fetchLocations();
      } else {
        const data = await response.json();
        toast.error(data.error || "Failed to create zone");
      }
    } catch (error) {
      toast.error("Network error");
    } finally {
      setIsProcessing(false);
    }
  };

  const updateZone = async () => {
    if (!zoneName.trim() || !editingZone) return;
    setIsProcessing(true);
    try {
      const response = await fetch(`/api/locations/${editingZone._id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: zoneName, status: zoneStatus }),
      });
      if (response.ok) {
        toast.success("Zone updated successfully");
        setIsEditOpen(false);
        setEditingZone(null);
        setZoneName("");
        fetchLocations();
      } else {
        const data = await response.json();
        toast.error(data.error || "Failed to update zone");
      }
    } catch (error) {
      toast.error("Network error");
    } finally {
      setIsProcessing(false);
    }
  };

  const deleteZone = async (zoneId: string) => {
    if (!confirm("Are you sure you want to delete this delivery zone?")) return;
    try {
      const response = await fetch(`/api/locations/${zoneId}`, { method: "DELETE" });
      if (response.ok) {
        toast.success("Zone removed successfully");
        fetchLocations();
      }
    } catch (error) {
      toast.error("Failed to delete zone");
    }
  };

  const openEdit = (zone: any) => {
    setEditingZone(zone);
    setZoneName(zone.name);
    setZoneStatus(zone.status || "Active");
    setIsEditOpen(true);
  };

  const totalOrders = locations.reduce((s, l) => s + (l.orders || 0), 0);

  return (
    <div className="space-y-10 pb-20 max-w-7xl mx-auto px-6 sm:px-10">
      
      {/* Header Section */}
      <div className="flex flex-col items-center text-center space-y-8">
        <div className="space-y-3">
           <div className="flex flex-col items-center gap-4">
              <div className="h-14 w-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-200 animate-in zoom-in duration-500">
                 <MapPin className="h-7 w-7" />
              </div>
              <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tighter">Delivery Regions</h1>
           </div>
           <p className="text-sm font-bold text-slate-400 uppercase tracking-[0.2em]">Operational Coverage & Logistics Mapping</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full max-w-md">
           <Button 
             onClick={() => setIsAddOpen(true)}
             className="flex-1 w-full h-14 rounded-[1.25rem] bg-slate-900 hover:bg-black text-white font-black uppercase text-xs tracking-widest shadow-2xl transition-all flex items-center justify-center gap-3 active:scale-95"
           >
              <Plus className="h-5 w-5" />
              New Deployment
           </Button>
           <Button onClick={fetchLocations} disabled={isLoading} variant="outline" className="h-14 w-14 rounded-[1.25rem] bg-white border-slate-200 hover:bg-slate-50 transition-all shrink-0">
              <RefreshCw className={`h-5 w-5 ${isLoading ? "animate-spin" : ""}`} />
           </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
         <ZoneMetric label="Total Zones" value={locations.length} icon={Globe} color="indigo" />
         <ZoneMetric label="Active Regions" value={locations.filter(l => l.status === "Active").length} icon={ShieldCheck} color="emerald" />
         <ZoneMetric label="Total Deliveries" value={totalOrders} icon={TrendingUp} color="emerald" />
      </div>

      {/* Main Listing */}
      <Card className="rounded-[2.5rem] border-slate-100 shadow-sm overflow-hidden bg-white">
        <CardHeader className="px-8 py-8 border-b border-slate-50">
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                 <div className="h-10 w-10 bg-indigo-50 rounded-xl flex items-center justify-center border border-indigo-100/50">
                    <Target className="h-5 w-5 text-indigo-600" />
                 </div>
                 <div>
                    <CardTitle className="text-lg font-bold text-slate-900">Coverage Map</CardTitle>
                    <CardDescription className="text-xs font-medium text-slate-400">{locations.length} regions defined</CardDescription>
                 </div>
              </div>
           </div>
        </CardHeader>
        <CardContent className="p-8 sm:p-10 bg-slate-50/30">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 text-left">
            <AnimatePresence mode="popLayout">
              {isLoading ? (
                Array(4).fill(0).map((_, i) => (
                  <div key={i} className="h-64 bg-white rounded-3xl border border-slate-100 animate-pulse" />
                ))
              ) : locations.length === 0 ? (
                <div className="col-span-full py-20 text-center space-y-4">
                    <div className="bg-slate-100 h-20 w-20 rounded-full flex items-center justify-center mx-auto">
                       <Globe className="h-8 w-8 text-slate-300" />
                    </div>
                    <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">No zones identified</p>
                    <Button onClick={() => setIsAddOpen(true)} variant="outline" className="rounded-xl border-slate-200">Add First Zone</Button>
                </div>
              ) : (
                locations.map((loc, idx) => (
                  <ZoneNodeCard 
                    key={loc._id || loc.id} 
                    loc={loc} 
                    index={idx}
                    onEdit={() => openEdit(loc)}
                    onDelete={() => deleteZone(loc._id)}
                  />
                ))
              )}
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>

      {/* Zone Dialog */}
      <Dialog open={isAddOpen || isEditOpen} onOpenChange={(open) => {
        if (!open) {
          setIsAddOpen(false);
          setIsEditOpen(false);
          setEditingZone(null);
          setZoneName("");
        }
      }}>
        <DialogContent className="sm:max-w-[500px] rounded-[2.5rem] p-0 overflow-hidden border-slate-200 shadow-2xl bg-white">
           <div className="px-10 py-8 border-b border-slate-100 bg-slate-50/50 text-left">
              <div className="flex items-center gap-3 mb-2">
                 <div className="h-10 w-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
                    <Target className="h-5 w-5" />
                 </div>
                 <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-600">Location Settings</span>
              </div>
              <DialogHeader>
                 <DialogTitle className="text-2xl font-bold text-slate-900 tracking-tight">
                   {isEditOpen ? "Edit Zone Parameters" : "Add New Delivery Zone"}
                 </DialogTitle>
                 <DialogDescription className="text-slate-500 font-medium text-xs mt-1">
                    Configure names and operational status for this region.
                 </DialogDescription>
              </DialogHeader>
           </div>
           
           <div className="p-10 space-y-8 text-left">
              <div className="space-y-2">
                 <Label className="text-xs font-bold text-slate-500 ml-1">Zone Name</Label>
                 <Input 
                   value={zoneName}
                   onChange={(e) => setZoneName(e.target.value)}
                   className="h-12 border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-50 font-medium"
                   placeholder="e.g. Dhaka North"
                 />
              </div>

              <div className="space-y-4">
                 <Label className="text-xs font-bold text-slate-500 ml-1">Status</Label>
                 <div className="grid grid-cols-2 gap-4">
                    {["Active", "Standby"].map((s) => (
                      <button
                        key={s}
                        onClick={() => setZoneStatus(s)}
                        className={`h-12 rounded-xl border font-bold text-xs transition-all ${
                          zoneStatus === s 
                          ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-100" 
                          : "bg-white border-slate-200 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50"
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                 </div>
              </div>
           </div>

           <div className="p-8 border-t border-slate-100 bg-slate-50/50 flex gap-4">
              <Button variant="ghost" onClick={() => { setIsAddOpen(false); setIsEditOpen(false); }} className="h-12 flex-1 rounded-xl text-slate-400 font-bold uppercase text-[10px] tracking-widest hover:bg-white hover:text-slate-900 border border-transparent">
                 Cancel
              </Button>
              <Button 
                onClick={isEditOpen ? updateZone : createZone}
                disabled={isProcessing}
                className="h-12 flex-[2] rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold uppercase text-[10px] tracking-widest shadow-lg shadow-indigo-100 transition-all"
              >
                 {isProcessing ? <Loader2 className="h-5 w-5 animate-spin" /> : (isEditOpen ? "Update Zone" : "Create Zone")}
              </Button>
           </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ZoneNodeCard({ loc, index, onEdit, onDelete }: any) {
  const isActive = loc.status === "Active" || !loc.status;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ y: -4 }}
      className="group relative bg-white rounded-[2.5rem] p-8 border border-slate-100 hover:border-indigo-100 transition-all duration-300 shadow-sm hover:shadow-xl hover:shadow-indigo-50/50 overflow-hidden flex flex-col items-center text-center gap-6"
    >
      <div className="flex flex-col items-center gap-3 w-full">
          <Badge variant="outline" className={`px-4 py-1 rounded-full border font-black text-[9px] uppercase tracking-[0.2em] shadow-sm ${
            isActive 
            ? "bg-emerald-50 border-emerald-100 text-emerald-600" 
            : "bg-amber-50 border-amber-100 text-amber-600"
          }`}>
            {loc.status || "Active"}
          </Badge>
          <div className="flex gap-2">
             <button onClick={onEdit} className="h-10 w-10 rounded-xl bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-100 transition-all flex items-center justify-center">
                <Edit3 className="h-4 w-4" />
             </button>
             <button onClick={onDelete} className="h-10 w-10 rounded-xl bg-slate-50 text-slate-400 hover:text-rose-500 hover:bg-rose-50 border border-slate-100 transition-all flex items-center justify-center">
                <Trash2 className="h-4 w-4" />
             </button>
          </div>
      </div>

      <div className="space-y-2">
         <p className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em] leading-none mb-1">Coverage Alpha</p>
         <h3 className="text-2xl font-black text-slate-900 group-hover:text-indigo-600 transition-colors tracking-tighter">{loc.name}</h3>
      </div>

      <div className="bg-slate-50 p-6 rounded-[1.5rem] border border-slate-100 flex flex-col items-center gap-3 w-full">
         <div className="h-12 w-12 bg-white rounded-2xl flex items-center justify-center shadow-lg shadow-slate-200/50 border border-slate-100">
            <ShoppingBag className="h-6 w-6 text-indigo-600" />
         </div>
         <div className="flex flex-col items-center">
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Load Factor</p>
            <p className="text-2xl font-black text-slate-900 tabular-nums leading-none tracking-tighter">{loc.orders || 0}</p>
         </div>
         <ChevronRight className="h-4 w-4 text-slate-300 group-hover:text-indigo-600 transition-all mt-2" />
      </div>
    </motion.div>
  );
}

function ZoneMetric({ label, value, icon: Icon, color }: any) {
  const themes: any = {
    indigo: "text-indigo-600 bg-indigo-50 border-indigo-100",
    emerald: "text-emerald-600 bg-emerald-50 border-emerald-100 shadow-emerald-50"
  };

  return (
    <Card className="rounded-[2.5rem] p-6 sm:p-10 border border-slate-100 shadow-sm bg-white hover:border-indigo-100 transition-all duration-300 flex flex-col items-center justify-center text-center group">
       <div className={`h-12 w-12 sm:h-14 sm:w-14 rounded-2xl flex items-center justify-center border transition-transform duration-500 group-hover:scale-110 mb-4 sm:mb-6 ${themes[color]}`}>
          <Icon className="h-5 w-5 sm:h-6 sm:w-6" />
       </div>
       <div className="flex flex-col items-center">
          <p className="text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] leading-none mb-2 sm:mb-3">{label}</p>
          <p className="text-2xl sm:text-4xl font-black text-slate-900 tabular-nums leading-none tracking-tighter">{value}</p>
       </div>
    </Card>
  );
}
