import React from "react";
import { motion } from "motion/react";
import { ChevronRight, User, Clock, Package, MapPin, Hash } from "lucide-react";
import { Order, STATUS_THEMES } from "./types";

interface OrderCardProps {
  order: Order;
  onView: () => void;
  index: number;
  isSelected?: boolean;
  onSelect?: (id: string) => void;
}

export const OrderCard = ({ order, onView, index, isSelected, onSelect }: OrderCardProps) => {
  const theme = STATUS_THEMES[order.status] || STATUS_THEMES["Pending"];
  
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ 
        duration: 0.4, 
        delay: index * 0.05,
        ease: [0.23, 1, 0.32, 1]
      }}
      whileHover={{ y: -4 }}
      onClick={onView}
      className={`group relative bg-white rounded-[2.5rem] p-8 border hover:border-indigo-200 transition-all duration-300 cursor-pointer shadow-sm hover:shadow-xl hover:shadow-indigo-50/50 ${isSelected ? "border-indigo-600 bg-indigo-50/20" : "border-slate-100"}`}
    >
      {/* Multi-select Checkbox */}
      {onSelect && (
        <div 
          onClick={(e) => { e.stopPropagation(); onSelect(order._id); }}
          className={`absolute top-6 right-6 h-6 w-6 rounded-lg border-2 flex items-center justify-center transition-all duration-200 ${
            isSelected 
              ? "bg-indigo-600 border-indigo-600 scale-110 shadow-lg shadow-indigo-200" 
              : "bg-white border-slate-200 hover:border-indigo-400"
          }`}
        >
          {isSelected && <div className="h-2.5 w-2.5 bg-white rounded-sm animate-in zoom-in duration-200" />}
        </div>
      )}
      <div className="flex flex-col h-full items-center text-center space-y-8">
        <div className="flex flex-col items-center gap-3 w-full">
           <div className={`px-4 py-1.5 rounded-full border ${theme.color} text-[9px] font-black uppercase tracking-[0.2em] shadow-sm`}>
              {order.status || "Pending"}
           </div>
           <div className="flex items-center gap-2 text-slate-400">
              <Hash className="h-4 w-4" />
              <p className="text-sm font-black tracking-widest tabular-nums">{order.orderNumber || "0000"}</p>
           </div>
        </div>

        <div className="flex flex-col items-center gap-4 w-full">
           <div className="h-16 w-16 bg-slate-50 text-slate-400 rounded-2xl flex items-center justify-center border border-slate-100 group-hover:bg-slate-900 group-hover:text-white group-hover:border-slate-900 transition-all duration-500 shadow-sm">
              <User className="h-7 w-7" />
           </div>
           <div className="min-w-0 flex-1 space-y-1">
              <p className="text-lg font-black text-slate-900 leading-tight tracking-tight px-2">
                 {order.customerName || "Anonymous Customer"}
              </p>
              <div className="flex items-center justify-center gap-2 text-slate-400">
                 <MapPin className="h-3 w-3" />
                 <p className="text-[10px] font-black uppercase tracking-widest truncate max-w-[150px]">
                    {order.address?.split(',')[0] || "No Address Listed"}
                 </p>
              </div>
           </div>
        </div>

        <div className="grid grid-cols-2 gap-8 py-6 border-y border-slate-50 w-full">
           <div className="flex flex-col items-center gap-1.5">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Inventory</p>
              <div className="flex items-center gap-2">
                 <Package className="h-4 w-4 text-canvas-700" />
                 <p className="text-sm font-black text-slate-900 tabular-nums">{order.items?.length || 0}</p>
              </div>
           </div>
           <div className="flex flex-col items-center gap-1.5">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Arrival</p>
              <div className="flex items-center gap-2">
                 <Clock className="h-4 w-4 text-canvas-700" />
                 <p className="text-sm font-black text-slate-900 tabular-nums">
                    {new Date(order.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                 </p>
              </div>
           </div>
        </div>

        <div className="flex flex-col items-center gap-1 w-full pt-2">
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Total Valuation</p>
           <div className="flex items-center justify-center gap-4 w-full">
              <div className="h-1 w-12 rounded-full bg-slate-50" />
              <p className="text-3xl font-black text-slate-900 tabular-nums tracking-tighter shrink-0">
                 ৳{(Number(order.totalAmount) || 0).toLocaleString()}
              </p>
              <div className="h-1 w-12 rounded-full bg-slate-50" />
           </div>
        </div>
      </div>
    </motion.div>
  );
};

