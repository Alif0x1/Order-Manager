import React from "react";
import { Order } from "./types";
import { Terminal, Hash, Phone, MapPin, Calendar, User, Package, CreditCard } from "lucide-react";

interface InvoiceTemplateProps {
  order: Order;
}

export const InvoiceTemplate = ({ order }: InvoiceTemplateProps) => {
  const currentDate = new Date().toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <div id="official-invoice" className="hidden print:block bg-white p-8 font-sans text-slate-900 min-h-[297mm] w-[210mm] mx-auto">
      {/* Decorative Border */}
      <div className="absolute top-0 left-0 w-full h-1 bg-indigo-600 print:bg-black" />

      {/* Header Section */}
      <div className="flex justify-between items-start mb-12">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-lg print:bg-black">
            <Terminal className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight text-slate-900 uppercase">CaseHub</h1>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Premium Mobile Accessories</p>
          </div>
        </div>
        <div className="text-right">
          <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tighter mb-1">Invoice</h2>
          <div className="flex flex-col items-end gap-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Order #</span>
              <span className="text-sm font-bold text-slate-900 tabular-nums">{order.orderNumber}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date</span>
              <span className="text-sm font-bold text-slate-900 tabular-nums">{currentDate}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Information Grid */}
      <div className="grid grid-cols-2 gap-12 mb-12">
        <div>
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 border-b pb-2">Store Information</h3>
          <div className="space-y-2">
            <p className="text-sm font-bold text-slate-800">CaseHub BD</p>
            <p className="text-xs text-slate-600 leading-relaxed max-w-[200px]">
              House 24, Road 7, Block D<br />
              Banani, Dhaka - 1213<br />
              Bangladesh
            </p>
            <div className="flex items-center gap-2 text-xs text-slate-600 mt-2">
              <Phone className="h-3 w-3" />
              <span>+880 1234-567890</span>
            </div>
          </div>
        </div>
        <div>
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 border-b pb-2">Bill To</h3>
          <div className="space-y-2 text-right flex flex-col items-end">
            <p className="text-lg font-black text-slate-900 underline decoration-indigo-600/30 underline-offset-4">{order.customerName}</p>
            <div className="flex justify-end items-center gap-2 text-sm font-bold text-slate-700">
              <Phone className="h-3 w-3 text-slate-400" />
              <span>{order.customerPhone}</span>
            </div>
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 mt-2 text-xs text-slate-600 italic text-right max-w-[250px] ml-auto">
              <MapPin className="h-3 w-3 text-slate-400 inline mr-1 mb-1" />
              {order.address}
            </div>
            {order.customerEmail && <p className="text-xs text-slate-500 mt-1">{order.customerEmail}</p>}
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="mb-12">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 print:bg-black text-white">
              <th className="px-4 py-3 text-[10px] font-black uppercase tracking-widest rounded-l-lg">Product Description</th>
              <th className="px-4 py-3 text-[10px] font-black uppercase tracking-widest text-center">Qty</th>
              <th className="px-4 py-3 text-[10px] font-black uppercase tracking-widest text-right">Unit Price</th>
              <th className="px-4 py-3 text-[10px] font-black uppercase tracking-widest text-right rounded-r-lg">Total</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {order.items.map((item, idx) => (
              <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-4 py-4">
                  <p className="text-sm font-bold text-slate-900">{item.title}</p>
                  <p className="text-[9px] font-bold text-indigo-600 uppercase tracking-widest mt-1">{item.variant || "Standard Edition"}</p>
                </td>
                <td className="px-4 py-4 text-center text-sm font-bold text-slate-700 tabular-nums">
                  {item.quantity}
                </td>
                <td className="px-4 py-4 text-right text-sm font-medium text-slate-600 tabular-nums">
                  ৳{item.price.toLocaleString()}
                </td>
                <td className="px-4 py-4 text-right text-sm font-black text-slate-900 tabular-nums">
                  ৳{(item.price * item.quantity).toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Section */}
      <div className="flex justify-between items-start">
        <div className="w-1/2">
          {order.customerNote && (
            <div className="bg-slate-50 p-6 rounded-2xl border border-dashed border-slate-200">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                <Calendar className="h-3 w-3" /> Customer Instruction
              </h4>
              <p className="text-xs text-slate-600 italic leading-relaxed">{order.customerNote}</p>
            </div>
          )}
          <div className="mt-8">
            <div className="flex items-center gap-2 opacity-30 grayscale">
              <Terminal className="h-10 w-10 text-slate-300" />
              <div className="h-8 w-[1px] bg-slate-200" />
              <div className="space-y-0.5">
                <p className="text-[8px] font-black uppercase tracking-[0.4em]">Verified Authenticity</p>
                <p className="text-[6px] text-slate-400 font-bold uppercase tracking-widest">Secure Supply Chain Hub</p>
              </div>
            </div>
          </div>
        </div>
        <div className="w-[300px] space-y-4">
          <div className="space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-400 uppercase tracking-widest">Subtotal</span>
              <span className="font-bold text-slate-700 tabular-nums">৳{(order.totalAmount - order.deliveryCharge).toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-400 uppercase tracking-widest">Delivery Charge</span>
              <span className="font-bold text-slate-700 tabular-nums">+৳{order.deliveryCharge.toLocaleString()}</span>
            </div>
          </div>
          <div className="h-px bg-slate-900 print:bg-black w-full" />
          <div className="flex justify-between items-end pt-2">
            <div>
              <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-1">Grand Total</p>
              <p className="text-3xl font-black text-slate-900 tabular-nums tracking-tighter">৳{order.totalAmount.toLocaleString()}</p>
            </div>
            <div className="flex flex-col items-end">
              <div className="bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border border-emerald-100 flex items-center gap-1.5 mb-2">
                <CreditCard className="h-2.5 w-2.5" /> COD Verified
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-auto pt-12 border-t border-slate-100 flex justify-between items-end">
        <div className="space-y-4">
          <p className="text-[10px] text-slate-400 font-medium max-w-[400px]">
            Thank you for choosing CaseHub. For any inquiries regarding this invoice, please contact support@casehub.bd. All products are covered under our 7-day replacement policy.
          </p>
          <div className="flex items-center gap-4">
            <div className="h-8 w-8 bg-slate-100 rounded-lg flex items-center justify-center">
              <User className="h-4 w-4 text-slate-400" />
            </div>
            <div className="h-8 w-8 bg-slate-100 rounded-lg flex items-center justify-center">
              <Package className="h-4 w-4 text-slate-400" />
            </div>
            <div className="h-8 w-8 bg-slate-100 rounded-lg flex items-center justify-center">
              <Hash className="h-4 w-4 text-slate-400" />
            </div>
          </div>
        </div>
        <div className="text-right space-y-2">
          <div className="w-32 h-1 bg-slate-200 ml-auto mb-1" />
          <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Authorized Signature</p>
          <p className="text-[8px] text-slate-400 uppercase tracking-widest font-bold">Electronic Document Hub</p>
        </div>
      </div>
    </div>
  );
};
