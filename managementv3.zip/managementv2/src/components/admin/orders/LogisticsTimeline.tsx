import React from "react";
import { motion } from "motion/react";
import { Clock, ShieldCheck, Truck, Package } from "lucide-react";

interface LogisticsTimelineProps {
  status: string;
}

export const LogisticsTimeline = ({ status }: LogisticsTimelineProps) => {
  const stages = [
    { id: "Pending", label: "Signed", icon: Clock },
    { id: "In Review", label: "Confirmed", icon: ShieldCheck },
    { id: "Shipped", label: "On Way", icon: Truck },
    { id: "Delivered", label: "Arrived", icon: Package }
  ];

  const currentIdx = stages.findIndex(s => s.id === status);
  
  return (
    <div className="flex justify-between items-center w-full px-2">
       {stages.map((stage, i) => {
         const isActive = i <= currentIdx;
         const isCurrent = i === currentIdx;
         return (
           <React.Fragment key={stage.id}>
             <div className="flex flex-col items-center gap-2 relative z-10 group">
                <div className={`h-11 w-11 rounded-full border flex items-center justify-center transition-all duration-300 ${
                  isActive 
                  ? "bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-100" 
                  : "bg-slate-50 border-slate-100 text-slate-300"
                }`}>
                   <stage.icon className="h-5 w-5" />
                   {isCurrent && (
                     <span className="absolute -top-1 -right-1 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500 border-2 border-white"></span>
                     </span>
                   )}
                </div>
                <span className={`text-[10px] font-bold uppercase tracking-wider ${isActive ? "text-indigo-600" : "text-slate-400"}`}>
                   {stage.label}
                </span>
             </div>
             {i !== stages.length - 1 && (
               <div className="flex-1 h-0.5 mx-2 bg-slate-100 relative top-[-10px]">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: isActive ? "100%" : 0 }}
                    className="h-full bg-indigo-200"
                  />
               </div>
             )}
           </React.Fragment>
         );
       })}
    </div>
  );
};
