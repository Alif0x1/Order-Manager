import { Clock, ShieldCheck, Truck, Package } from "lucide-react";

export interface OrderItem {
  title: string;
  quantity: number;
  price: number;
  variant?: string;
}

export interface Order {
  _id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  address: string;
  customerNote?: string;
  totalAmount: number;
  deliveryCharge: number;
  status: string;
  items: OrderItem[];
  createdAt: string;
  consignmentId?: string;
  trackingCode?: string;
}

export const STATUS_THEMES: Record<string, { color: string }> = {
  "Pending": { color: "text-amber-600 bg-amber-50 border-amber-100" },
  "In Review": { color: "text-blue-600 bg-blue-50 border-blue-100" },
  "Shipped": { color: "text-indigo-600 bg-indigo-50 border-indigo-100" },
  "Delivered": { color: "text-emerald-600 bg-emerald-50 border-emerald-100" },
  "Returned": { color: "text-rose-600 bg-rose-50 border-rose-100" },
  "Cancelled": { color: "text-slate-600 bg-slate-50 border-slate-100" }
};

export const getBannerColor = (status: string) => {
  const theme = STATUS_THEMES[status] || STATUS_THEMES["Pending"];
  const parts = theme.color.split(' ');
  return parts.find(p => p.startsWith('bg-')) || 'bg-indigo-50';
};
