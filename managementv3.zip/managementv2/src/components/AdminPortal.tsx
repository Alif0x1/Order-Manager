import React, { useState, useEffect, useCallback } from "react";
import OrdersManager from "./admin/OrdersManager";
import InventoryManager from "./admin/InventoryManager";
import CouponsManager from "./admin/CouponsManager";
import ZonesManager from "./admin/ZonesManager";
import { 
  ShoppingBag, DollarSign, Package, Database, 
  RefreshCw, LayoutDashboard, Search,
  X, Store, Ticket, MapPin, ChevronRight,
  Settings, LogOut, Menu as MenuIcon, ShoppingCart,
  Activity, Sparkles, Zap, AlertTriangle, Trash2
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { useCart } from "../hooks/useCart";
import { ScrollArea } from "./ui/scroll-area";
import { 
  Card, CardContent, CardHeader, CardTitle 
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { 
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, 
  DropdownMenuSeparator, DropdownMenuTrigger
} from "./ui/dropdown-menu";
import { Dialog, DialogContent } from "./ui/dialog";

interface Stats {
  totalOrders: number;
  totalProducts: number;
  totalRevenue: number;
  recentOrders: any[];
}

export default function AdminPortal({ onBackToShop, onOpenCart }: { onBackToShop: () => void, onOpenCart: () => void }) {
  const { cartCount, items, total, clearCart } = useCart();
  const [activeTab, setActiveTab] = useState<"overview" | "orders" | "inventory" | "coupons" | "zones">("overview");
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isPurgeModalOpen, setIsPurgeModalOpen] = useState(false);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const fetchStats = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (startDate) params.append("startDate", startDate);
      if (endDate) params.append("endDate", endDate);
      const url = `/api/dashboard/stats${params.toString() ? '?' + params.toString() : ''}`;
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      toast.error("Telemetry link failed");
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate]);

  const purgeCollection = async (collection: string) => {
    const confirmText = prompt(`Type "PURGE" to permanently wipe the "${collection}" collection:`);
    if (confirmText !== "PURGE") {
      toast.error("Safety lock engaged - Purge aborted");
      return;
    }
    try {
      const response = await fetch(`/api/admin/purge/${collection}`, { method: "DELETE" });
      if (response.ok) {
        toast.success(`${collection.toUpperCase()} collection purged entirely`);
        fetchStats();
      } else {
        toast.error("Purge authorization failed");
      }
    } catch (e) {
      toast.error("Deep purge network failure");
    }
  };

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  const snapTransition = { type: "tween", duration: 0.25, ease: "easeOut" };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-0 lg:p-6 font-sans antialiased text-slate-900 selection:bg-indigo-600 selection:text-white">
      
      <div className="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(79,70,229,0.03)_0%,transparent_100%)]" />
        <div className="absolute top-1/4 left-1/4 w-1/2 h-1/2 bg-indigo-500/5 blur-[160px] rounded-full animate-pulse" />
      </div>

      <div className="w-full max-w-[1720px] h-full lg:h-[calc(100vh-48px)] flex flex-col bg-white overflow-hidden relative lg:rounded-[3rem] lg:shadow-[0_40px_100px_-20px_rgba(0,0,0,0.12)] border border-slate-200/60">
        
        <header className="h-20 bg-white border-b border-slate-200/60 flex items-center justify-between px-6 lg:px-12 z-50 shrink-0">
          <div className="flex items-center gap-6">
             <div className="flex items-center gap-3 group">
                <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-100 group-hover:rotate-12 transition-transform">
                  <Database className="h-5.5 w-5.5" />
                </div>
                <div className="hidden sm:flex flex-col">
                   <span className="font-black text-lg tracking-[-0.05em] uppercase leading-none">Admin OS</span>
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Terminal.Main</span>
                </div>
             </div>
             
             <Separator orientation="vertical" className="h-8 bg-slate-200 hidden lg:block" />
             
             <div className="hidden lg:flex items-center gap-2">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Root</span>
                <ChevronRight className="h-3 w-3 text-slate-300" />
                <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">{activeTab}</span>
             </div>
          </div>

          <div className="relative hidden lg:flex flex-1 max-w-xl mx-12">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input 
                placeholder="Search global operational nodes (⌘K)..." 
                className="pl-12 h-12 w-full bg-slate-50 border-slate-200/80 rounded-[1.5rem] text-xs font-bold focus:ring-8 focus:ring-indigo-50/50 transition-all shadow-inner"
              />
          </div>

          <div className="flex items-center gap-4 sm:gap-6">
            <div className="hidden sm:flex flex-col text-right">
                <div className="flex items-center gap-2.5 justify-end">
                   <span className="text-[9px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-2 py-0.5 rounded-full">Operational</span>
                   <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,1)]" />
                </div>
            </div>

            <button onClick={onOpenCart} className="relative p-2.5 rounded-xl text-slate-600 hover:text-indigo-600 hover:bg-slate-50 transition-all">
              <ShoppingCart className="h-6 w-6" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 h-4.5 w-4.5 flex items-center justify-center rounded-full bg-indigo-600 text-white text-[9px] font-black shadow-lg">
                  {cartCount}
                </span>
              )}
            </button>

            <DropdownMenu>
              <DropdownMenuTrigger className="flex items-center gap-3 p-1.5 pr-4 rounded-full bg-slate-50 border border-slate-200/60 hover:shadow-md transition-all cursor-pointer focus:outline-none">
                <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-black text-xs">A</div>
                <div className="text-left hidden sm:block">
                  <p className="text-[11px] font-black text-slate-900 leading-none uppercase">Admin</p>
                </div>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 mt-2 p-2 rounded-2xl shadow-2xl border-slate-100">
                <DropdownMenuItem className="rounded-xl px-4 py-2.5 font-bold focus:bg-indigo-50 transition-colors"><Settings className="h-4 w-4 mr-3" /> Dashboard Info</DropdownMenuItem>
                <DropdownMenuItem onClick={onBackToShop} className="rounded-xl px-4 py-2.5 font-bold focus:bg-indigo-50 transition-colors"><Store className="h-4 w-4 mr-3" /> View Storefront</DropdownMenuItem>
                <DropdownMenuSeparator className="bg-slate-100" />
                <DropdownMenuItem 
                  onClick={() => setIsPurgeModalOpen(true)}
                  className="rounded-xl px-4 py-2.5 font-bold text-rose-600 focus:bg-rose-50 transition-colors cursor-pointer"
                >
                  <AlertTriangle className="h-4 w-4 mr-3" /> System Maintenance
                </DropdownMenuItem>
                <DropdownMenuItem className="rounded-xl px-4 py-2.5 font-bold text-slate-400 focus:bg-slate-50 transition-colors"><LogOut className="h-4 w-4 mr-3" /> Terminate Link</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <nav className="h-16 bg-slate-50/50 backdrop-blur-md border-b border-slate-200/60 flex items-center justify-center px-6 z-40 shrink-0">
           <div className="hidden lg:flex items-center gap-1">
              <MenuOption active={activeTab === "overview"} onClick={() => setActiveTab("overview")} icon={<LayoutDashboard />} label="Dashboard" />
              <MenuOption active={activeTab === "orders"} onClick={() => setActiveTab("orders")} icon={<ShoppingBag />} label="Orders" />
              <MenuOption active={activeTab === "inventory"} onClick={() => setActiveTab("inventory")} icon={<Package />} label="Inventory" />
              <MenuOption active={activeTab === "coupons"} onClick={() => setActiveTab("coupons")} icon={<Ticket />} label="Coupons" />
              <MenuOption active={activeTab === "zones"} onClick={() => setActiveTab("zones")} icon={<MapPin />} label="Logistics" />
           </div>
           
           <div className="lg:hidden flex items-center justify-between w-full">
              <button 
                onClick={() => setIsSidebarOpen(true)}
                className="flex items-center gap-3 px-4 py-2 bg-white border border-slate-200 rounded-xl shadow-sm"
              >
                 <MenuIcon className="h-5 w-5 text-slate-600" />
                 <span className="text-[10px] font-black uppercase tracking-widest text-slate-900">{activeTab}</span>
              </button>
              <Button size="icon" variant="ghost" className="rounded-xl"><Search className="h-5 w-5" /></Button>
           </div>
        </nav>

        <AnimatePresence>
           {isSidebarOpen && (
              <>
                 <motion.div 
                   initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                   onClick={() => setIsSidebarOpen(false)}
                   className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] lg:hidden"
                 />
                 <motion.aside
                   initial={{ x: "-100%" }} animate={{ x: 0 }} exit={{ x: "-100%" }}
                   transition={snapTransition}
                   className="fixed inset-y-0 left-0 w-[280px] bg-white z-[70] shadow-2xl lg:hidden flex flex-col p-6"
                 >
                    <div className="flex items-center justify-between mb-10">
                       <span className="font-black text-xl tracking-tighter uppercase">Menu Hub</span>
                       <Button variant="ghost" size="icon" onClick={() => setIsSidebarOpen(false)}><X className="h-6 w-6" /></Button>
                    </div>
                    <div className="space-y-2 flex-1">
                       <NavOption active={activeTab === "overview"} onClick={() => { setActiveTab("overview"); setIsSidebarOpen(false); }} icon={<LayoutDashboard />} label="Dashboard" />
                       <NavOption active={activeTab === "orders"} onClick={() => { setActiveTab("orders"); setIsSidebarOpen(false); }} icon={<ShoppingBag />} label="Orders" />
                       <NavOption active={activeTab === "inventory"} onClick={() => { setActiveTab("inventory"); setIsSidebarOpen(false); }} icon={<Package />} label="Inventory" />
                       <NavOption active={activeTab === "coupons"} onClick={() => { setActiveTab("coupons"); setIsSidebarOpen(false); }} icon={<Ticket />} label="Coupons" />
                       <NavOption active={activeTab === "zones"} onClick={() => { setActiveTab("zones"); setIsSidebarOpen(false); }} icon={<MapPin />} label="Logistics" />
                    </div>
                    <div className="pt-6 border-t border-slate-100">
                       <NavOption active={false} onClick={onBackToShop} icon={<Store />} label="Portal Exit" />
                    </div>
                 </motion.aside>
              </>
           )}
        </AnimatePresence>

        <div className="flex-1 overflow-y-auto no-scrollbar scroll-smooth bg-white">
           <AnimatePresence mode="wait">
              {activeTab === "overview" && (
                <motion.div
                  key="tab-overview"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -30 }}
                  transition={snapTransition}
                  className="px-6 lg:px-12 py-16 space-y-16 max-w-[1700px] mx-auto flex flex-col items-center"
                >
                   <div className="text-center space-y-4">
                      <motion.h2 
                        initial={{ scale: 0.95 }} animate={{ scale: 1 }}
                        className="text-6xl lg:text-9xl font-black text-slate-900 tracking-[-0.08em] leading-none select-none"
                      >
                        CONTROL
                      </motion.h2>
                      <div className="flex items-center justify-center gap-6">
                         <div className="h-px w-16 bg-indigo-600/20" />
                         <p className="text-[10px] lg:text-xs font-black text-slate-400 uppercase tracking-[0.6em] whitespace-nowrap">Tactical operational hub</p>
                         <div className="h-px w-16 bg-indigo-600/20" />
                      </div>
                   </div>

                   <div className="w-full max-w-4xl bg-white border border-slate-200 rounded-[2.5rem] p-4 flex flex-col sm:flex-row items-center gap-4 shadow-sm">
                      <div className="flex-1 flex items-center gap-4 w-full">
                         <div className="relative flex-1 group">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[9px] font-black text-slate-400 uppercase tracking-widest z-10 pointer-events-none">Start</span>
                            <Input 
                              type="date" 
                              value={startDate} 
                              onChange={(e) => setStartDate(e.target.value)}
                              className="h-14 pl-14 rounded-2xl bg-slate-50 border-none font-bold text-xs focus:ring-4 focus:ring-indigo-100 transition-all uppercase"
                            />
                         </div>
                         <div className="relative flex-1 group">
                            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[9px] font-black text-slate-400 uppercase tracking-widest z-10 pointer-events-none">End</span>
                            <Input 
                              type="date" 
                              value={endDate} 
                              onChange={(e) => setEndDate(e.target.value)}
                              className="h-14 pl-14 rounded-2xl bg-slate-50 border-none font-bold text-xs focus:ring-4 focus:ring-indigo-100 transition-all uppercase"
                            />
                         </div>
                      </div>
                      {(startDate || endDate) && (
                         <Button 
                           variant="ghost" 
                           onClick={() => { setStartDate(""); setEndDate(""); }}
                           className="h-14 px-6 rounded-2xl text-[9px] font-black uppercase tracking-widest text-slate-400 hover:text-rose-500 hover:bg-rose-50 transition-all"
                         >
                            Reset Signal
                         </Button>
                      )}
                      <Button 
                        onClick={fetchStats}
                        className="h-14 px-10 rounded-[1.5rem] bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase tracking-widest text-[9px] shadow-xl shadow-indigo-100 active:scale-95 transition-all"
                      >
                         Refresh Data
                      </Button>
                   </div>

                   <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-8 w-full">
                      <MetricCard title="Gross" value={`৳${(stats?.totalRevenue || 0).toLocaleString()}`} icon={<DollarSign />} color="text-emerald-500" />
                      <MetricCard title="Volume" value={stats?.totalOrders || 0} icon={<ShoppingBag />} color="text-indigo-600" />
                      <MetricCard title="Catalog" value={stats?.totalProducts || 0} icon={<Package />} color="text-blue-500" />
                      <MetricCard title="Active" value="12 Nodes" icon={<Activity />} color="text-orange-500" />
                      <ShieldUsageMonitor />
                   </div>

                   <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-14 w-full items-start">
                      <Card className="rounded-[3.5rem] border-slate-200 shadow-2xl shadow-indigo-500/5 bg-white flex flex-col min-h-[750px] border-b-8 border-b-indigo-600">
                         <CardHeader className="p-12 border-b border-slate-50 text-center flex flex-col items-center gap-8">
                            <div className="w-20 h-20 bg-indigo-600 rounded-[2rem] flex items-center justify-center text-white shadow-2xl shadow-indigo-300">
                               <ShoppingCart className="h-10 w-10" />
                            </div>
                            <div className="space-y-3">
                               <CardTitle className="text-4xl font-black text-slate-900 tracking-tight uppercase">Registry</CardTitle>
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.5em]">Order Staging Environment</p>
                            </div>
                            <div className="px-10 py-5 bg-indigo-50/50 rounded-[2.5rem] border border-indigo-100/50 flex items-center gap-6">
                               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Staged Assets Sum</span>
                               <div className="h-5 w-px bg-indigo-200" />
                               <span className="text-4xl font-black text-indigo-700 tracking-tighter tabular-nums leading-none">৳{total.toLocaleString()}</span>
                            </div>
                         </CardHeader>
                         
                         <CardContent className="flex-1 p-0 flex flex-col min-h-0">
                            <ScrollArea className="flex-1 px-8 py-10">
                               <div className="flex flex-col gap-6 items-center">
                                  {items.length > 0 ? items.map((item: any) => (
                                     <div key={`${item._id}-${item.selectedVariant}`} className="w-full max-w-xl flex items-center gap-6 p-6 rounded-[2.5rem] bg-slate-50/30 border border-slate-100/60 hover:bg-white hover:border-indigo-200 transition-all duration-300">
                                        <div className="h-24 w-24 rounded-[2rem] bg-white border border-slate-100 overflow-hidden shrink-0 shadow-sm">
                                           <img src={item.imageSrc} alt={item.title} className="w-full h-full object-cover" />
                                        </div>
                                        <div className="flex-1 min-w-0 text-left">
                                           <p className="text-lg font-black text-slate-900 uppercase leading-none">{item.title}</p>
                                           <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-widest">{item.selectedVariant || "Standard Edition"}</p>
                                           <div className="flex items-center gap-4 mt-5">
                                               <span className="text-[10px] font-black text-indigo-700 bg-indigo-50 px-3 py-1 rounded-xl">x{item.quantity}</span>
                                               <p className="text-sm font-black text-slate-900 tabular-nums">৳{(item.price * item.quantity).toLocaleString()}</p>
                                           </div>
                                        </div>
                                     </div>
                                  )) : (
                                     <div className="py-40 opacity-10 flex flex-col items-center gap-8">
                                        <Sparkles className="h-20 w-20" />
                                        <p className="text-[10px] font-black uppercase tracking-[0.8em]">Operational standby</p>
                                     </div>
                                  )}
                               </div>
                            </ScrollArea>
                            
                            <div className="p-10 border-t border-slate-100 flex flex-col gap-4">
                               <Button onClick={onOpenCart} className="h-16 rounded-[2rem] bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase tracking-[0.25em] shadow-2xl shadow-indigo-100 active:scale-95 transition-all">Commit Operations</Button>
                               <Button variant="ghost" onClick={() => clearCart()} className="h-12 rounded-[1.5rem] text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 hover:text-rose-500">Flush Registry Buffer</Button>
                            </div>
                         </CardContent>
                      </Card>
    
                      <Card className="rounded-[3.5rem] border-slate-200 bg-white shadow-2xl shadow-indigo-500/5 flex flex-col min-h-[750px]">
                         <CardHeader className="p-12 border-b border-slate-50 flex flex-col items-center text-center gap-8">
                            <div className="w-20 h-20 bg-orange-500 rounded-[2rem] flex items-center justify-center text-white shadow-2xl shadow-orange-100">
                               <RefreshCw className="h-10 w-10 animate-[spin_4s_linear_infinite]" />
                            </div>
                            <div className="space-y-3">
                               <CardTitle className="text-4xl font-black text-slate-900 tracking-tight uppercase">Live Feed</CardTitle>
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.5em]">Real-time Order Signal Telemetry</p>
                            </div>
                         </CardHeader>
                         
                         <CardContent className="flex-1 p-8 space-y-6 overflow-y-auto no-scrollbar">
                            {stats?.recentOrders?.length ? stats.recentOrders.slice(0, 10).map((order: any) => (
                              <div key={order._id} className="flex items-center gap-6 p-6 rounded-[2.5rem] bg-white hover:bg-slate-50 border border-slate-100 transition-all cursor-pointer group/order">
                                 <div className="w-16 h-16 rounded-[1.5rem] bg-slate-100 text-slate-400 flex items-center justify-center group-hover/order:bg-indigo-600 group-hover/order:text-white transition-all duration-300">
                                    <ShoppingBag className="h-6 w-6" />
                                  </div>
                                 <div className="flex-1 min-w-0 text-left">
                                    <p className="text-base font-black text-slate-900 truncate uppercase">{order.customerName}</p>
                                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5">ID: #{order.orderNumber}</p>
                                 </div>
                                 <div className="text-right">
                                    <p className="text-lg font-black text-slate-900 tabular-nums">৳{order.totalAmount?.toLocaleString()}</p>
                                    <div className="inline-block mt-2 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[9px] font-black uppercase tracking-widest border border-emerald-100">Secured</div>
                                 </div>
                              </div>
                            )) : (
                              <div className="py-40 opacity-10 flex flex-col items-center gap-8">
                                 <Activity className="h-20 w-20" />
                                 <p className="text-[10px] font-black uppercase tracking-[0.8em]">Awaiting Data Packet</p>
                              </div>
                            )}
                         </CardContent>
                         <div className="p-10 border-t border-slate-100">
                            <Button onClick={() => setActiveTab("orders")} variant="ghost" className="w-full h-14 rounded-[2rem] text-[10px] font-black uppercase tracking-[0.4em] text-indigo-600 hover:bg-indigo-50">View Command Log</Button>
                         </div>
                      </Card>
                   </div>
                </motion.div>
              )}
    
              {activeTab === "orders" && <motion.div key="tab-orders" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-10 max-w-[1600px] mx-auto"><OrdersManager /></motion.div>}
              {activeTab === "inventory" && <motion.div key="tab-inventory" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-10 max-w-[1600px] mx-auto"><InventoryManager /></motion.div>}
              {activeTab === "coupons" && <motion.div key="tab-coupons" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-10 max-w-[1600px] mx-auto"><CouponsManager /></motion.div>}
              {activeTab === "zones" && <motion.div key="tab-zones" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-10 max-w-[1600px] mx-auto"><ZonesManager /></motion.div>}
            </AnimatePresence>
        </div>
      </div>

      <Dialog open={isPurgeModalOpen} onOpenChange={setIsPurgeModalOpen}>
         <DialogContent className="sm:max-w-xl rounded-[2.5rem] p-0 overflow-hidden border-rose-100 shadow-2xl bg-white">
            <div className="bg-rose-50 px-10 py-12 border-b border-rose-100 flex flex-col items-center text-center">
               <div className="h-20 w-20 bg-rose-600 text-white rounded-[2.5rem] flex items-center justify-center shadow-2xl shadow-rose-200 mb-6 animate-pulse">
                  <AlertTriangle className="h-10 w-10" />
               </div>
               <h2 className="text-3xl font-black text-slate-900 tracking-tighter mb-2">Danger Zone</h2>
               <p className="text-xs font-bold text-rose-600 uppercase tracking-widest leading-relaxed px-10">Administrative System Maintenance & Data Purging Protocol</p>
            </div>

            <div className="p-10 space-y-6">
               <PurgeOption 
                  title="Purge Order Registry" 
                  description="Permanently delete every order record and financial history."
                  onPurge={() => purgeCollection("orders")}
               />
               <PurgeOption 
                  title="Clear Product Catalog" 
                  description="Remove all inventory items, variants, and stock data."
                  onPurge={() => purgeCollection("products")}
               />
               <PurgeOption 
                  title="Wipe Voucher Systems" 
                  description="Delete all discount coupons and validation rules."
                  onPurge={() => purgeCollection("coupons")}
               />
               <PurgeOption 
                  title="Delete Logistics Zones" 
                  description="Clear all delivery areas and pricing configuration."
                  onPurge={() => purgeCollection("zones")}
               />
            </div>

            <div className="p-8 border-t border-slate-100 bg-slate-50/50">
               <Button onClick={() => setIsPurgeModalOpen(false)} variant="ghost" className="w-full h-14 rounded-2xl font-black uppercase text-[10px] tracking-widest text-slate-400 hover:text-slate-900">
                  Deactivate Maintenance Mode
               </Button>
            </div>
         </DialogContent>
       </Dialog>
    </div>
  );
}

function PurgeOption({ title, description, onPurge }: any) {
  return (
    <div className="flex items-center justify-between p-6 rounded-3xl border border-slate-100 bg-slate-50/30 group hover:border-rose-200 transition-all">
       <div className="space-y-1">
          <p className="text-sm font-black text-slate-900 tracking-tight">{title}</p>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">{description}</p>
       </div>
       <Button onClick={onPurge} variant="ghost" className="h-12 w-12 rounded-xl text-slate-300 hover:text-rose-600 hover:bg-rose-50 transition-all">
          <Trash2 className="h-5 w-5" />
       </Button>
    </div>
  );
}

function MenuOption({ active, onClick, icon, label }: any) {
  return (
    <button
      onClick={onClick}
      className={`px-8 py-2.5 h-12 flex items-center gap-3 transition-all duration-300 group relative ${
        active 
          ? "text-indigo-600 font-extrabold" 
          : "text-slate-500 hover:text-slate-900"
      }`}
    >
      <div className={`transition-transform duration-300 ${active ? "scale-110" : "text-slate-400 group-hover:text-indigo-600"}`}>
        {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: "h-4.5 w-4.5" }) : icon}
      </div>
      <span className="text-[10px] whitespace-nowrap uppercase tracking-[0.25em] leading-none">{label}</span>
      
      {active && (
         <motion.div 
           layoutId="nav-underline" 
           className="absolute bottom-0 left-6 right-6 h-0.5 bg-indigo-600 rounded-full"
           transition={{ type: "spring", stiffness: 380, damping: 30 }}
         />
      )}
    </button>
  );
}

function NavOption({ active, onClick, icon, label, className = "" }: any) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center transition-all duration-200 rounded-2xl group ${
        active 
          ? "bg-indigo-600 text-white font-black shadow-xl" 
          : "text-slate-500 hover:bg-slate-50"
      } px-6 py-4.5 gap-4 ${className}`}
    >
      <div className={`transition-all duration-300 ${active ? "scale-110" : "text-slate-400 group-hover:text-indigo-600"}`}>
        {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: "h-5 w-5" }) : icon}
      </div>
      <span className="text-[11px] font-black uppercase tracking-[0.2em]">{label}</span>
    </button>
  );
}

function MetricCard({ title, value, icon, color }: any) {
  return (
    <Card className="rounded-[3rem] p-10 border border-slate-200/60 shadow-xl shadow-slate-200/30 bg-white group hover:translate-y-[-6px] transition-all duration-300 flex flex-col items-center justify-center text-center relative overflow-hidden">
        <div className={`h-16 w-16 rounded-2xl flex items-center justify-center transition-all duration-500 group-hover:scale-110 mb-8 ${color} bg-slate-50 border border-slate-100`}>
           {React.isValidElement(icon) ? React.cloneElement(icon as React.ReactElement<any>, { className: "h-8 w-8" }) : icon}
        </div>
        <div className="flex flex-col items-center">
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] leading-none mb-4">{title}</p>
           <p className="text-4xl font-black text-slate-900 tracking-[-0.08em] leading-none tabular-nums">{value}</p>
        </div>
    </Card>
  );
}

function ShieldUsageMonitor() {
  const [usage, setUsage] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsage = async () => {
      try {
        const response = await fetch("/api/fraudshield/usage", {
          headers: {
            "Accept": "application/json"
          }
        });
        const result = await response.json();
        if (result.success) setUsage(result.data);
      } catch (error) {
        console.error("Shield stats link failed");
      } finally {
        setLoading(false);
      }
    };
    fetchUsage();
  }, []);

  if (loading) return <MetricCard title="Shield" value="..." icon={<ShieldCheck className="animate-pulse" />} color="text-slate-400" />;

  return (
    <Card className="rounded-[3rem] p-10 border border-slate-200/60 shadow-xl shadow-slate-200/30 bg-white group hover:translate-y-[-6px] transition-all duration-300 flex flex-col items-center justify-center text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4">
           {usage?.package?.is_active && <Badge className="bg-emerald-500 text-white text-[8px] font-black uppercase tracking-widest">{usage.package.name}</Badge>}
        </div>
        <div className={`h-16 w-16 rounded-2xl flex items-center justify-center transition-all duration-500 group-hover:scale-110 mb-8 text-indigo-600 bg-indigo-50 border border-indigo-100`}>
           <ShieldCheck className="h-8 w-8" />
        </div>
        <div className="flex flex-col items-center">
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] leading-none mb-4">Shield Quota</p>
           <p className="text-4xl font-black text-slate-900 tracking-[-0.08em] leading-none tabular-nums">
              {usage?.remaining_today ?? 0}
              <span className="text-sm text-slate-400 ml-1">/ {usage?.daily_limit ?? 0}</span>
           </p>
           <div className="mt-4 w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${((usage?.used_today || 0) / (usage?.daily_limit || 1)) * 100}%` }}
                className="h-full bg-indigo-600"
              />
           </div>
        </div>
    </Card>
  );
}

function ShieldCheck({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
