import React, { useState } from "react";
import OrderForm from "./OrderForm";
import { Button } from "./ui/button";
import { 
  ArrowLeft, 
  ShoppingBag, 
  ChevronRight, 
  Truck, 
  ShieldCheck, 
  CheckCircle2,
  ArrowRight,
  Loader2,
  Tag
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { ScrollArea } from "./ui/scroll-area";
import { Separator } from "./ui/separator";

import { useCart } from "../hooks/useCart";

interface CheckoutPageProps {
  locations: any[];
  onSubmitOrder: (data: any) => Promise<any>;
  onBackToShop: () => void;
}

export default function CheckoutPage({
  locations,
  onSubmitOrder,
  onBackToShop
}: CheckoutPageProps) {
  const { 
    items, 
    subtotal,
    total, 
    discount, 
    applyCoupon: onApplyCoupon, 
    removeCoupon,
    appliedCoupon 
  } = useCart();
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState<any>(null);
  const [couponCode, setCouponCode] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const [deliveryZone, setDeliveryZone] = useState<"inside_dhaka" | "outside_dhaka" | "">("");

  const deliveryCharge = deliveryZone === "inside_dhaka" ? 80 : deliveryZone === "outside_dhaka" ? 120 : 0;
  const finalTotal = total + deliveryCharge;

  const handleApplyCoupon = async () => {
    if (!couponCode) return;
    setIsValidating(true);
    try {
      const response = await fetch("/api/coupons/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: couponCode, cartTotal: subtotal })
      });
      if (response.ok) {
        const data = await response.json();
        onApplyCoupon(data);
        toast.success(`Coupon ${data.code} applied!`);
      } else {
        const err = await response.json();
        toast.error(err.error || "Invalid coupon code");
      }
    } catch (error) {
      toast.error("Failed to apply coupon");
    } finally {
      setIsValidating(false);
    }
  };

  const handleFinalSubmit = async (formData: any) => {
    setIsPlacingOrder(true);
    try {
      const orderData = {
        ...formData,
        items,
        subtotal: subtotal,
        totalAmount: subtotal + formData.deliveryCharge - discount,
        deliveryCharge: formData.deliveryCharge,
        discountAmount: discount,
        couponCode: appliedCoupon?.code || null
      };
      
      const successData = await onSubmitOrder(orderData);
      setOrderSuccess(successData);
      toast.success("Order placed successfully!");
    } catch (error) {
      toast.error("Failed to place order. Please try again.");
    } finally {
      setIsPlacingOrder(false);
    }
  };

  if (orderSuccess) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 antialiased">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full bg-white rounded-3xl p-10 text-center shadow-xl shadow-slate-200 border border-slate-200"
        >
          <div className="bg-emerald-50 h-20 w-20 rounded-full flex items-center justify-center mx-auto mb-6">
             <CheckCircle2 className="h-10 w-10 text-emerald-600" />
          </div>

          <h2 className="text-2xl font-bold text-slate-900 mb-2">Order Confirmed</h2>
          <p className="text-slate-500 mb-8">
            Thank you for your purchase! Your order <span className="text-indigo-600 font-semibold">#{orderSuccess.orderNumber}</span> has been received and is being processed.
          </p>
          
          <div className="bg-slate-50 p-6 rounded-2xl mb-8 text-left space-y-3">
             <div className="flex justify-between text-sm">
                <span className="text-slate-500">Order ID</span>
                <span className="text-slate-900 font-bold">#{orderSuccess.orderNumber}</span>
             </div>
             <div className="flex justify-between text-sm">
                <span className="text-slate-500">Status</span>
                <span className="text-emerald-600 font-bold">Processing</span>
             </div>
          </div>

          <Button onClick={onBackToShop} className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold font-sans transition-all">
             Continue Shopping
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans antialiased text-slate-900">
      
      {/* Simple Header */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 h-16 md:h-20 flex items-center justify-between">
          <button 
            onClick={onBackToShop}
            className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-semibold text-sm transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Shop
          </button>
          
          <div className="flex items-center gap-3 px-4 py-1.5 rounded-full bg-emerald-50 border border-emerald-100">
            <ShieldCheck className="h-4 w-4 text-emerald-600" />
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">Secure Checkout</span>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-10 md:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          
          {/* Main Form Area */}
          <div className="lg:col-span-7 space-y-10">
            <div>
               <div className="flex items-center gap-3 mb-4">
                  <div className="h-1 w-8 bg-indigo-600 rounded-full" />
                  <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Step 02 / 02</span>
               </div>
               <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight">Checkout</h1>
               <p className="text-slate-500 mt-4 text-lg">
                 Complete your order details and delivery info.
               </p>
            </div>

            <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-slate-200">
               <OrderForm 
                 onSubmit={handleFinalSubmit}
                 onCancel={onBackToShop}
                 locations={locations}
                 onZoneChange={setDeliveryZone}
               />
            </div>
            
            <div className="flex items-start gap-4 p-6 bg-indigo-50/50 rounded-2xl border border-indigo-100">
              <Truck className="h-5 w-5 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-bold text-slate-900">Fast & Reliable Delivery</p>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Most orders arrive within 2-4 business days. We'll send you a tracking number as soon as it ships.
                </p>
              </div>
            </div>
          </div>

          {/* Sidebar Area */}
          <div className="lg:col-span-5">
            <div className="sticky top-28 space-y-6">
              <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200">
                <h3 className="text-lg font-bold text-slate-900 mb-8 flex items-center gap-3">
                   Order Summary
                   <span className="text-slate-400 font-normal">({items.length} items)</span>
                </h3>
                
                <ScrollArea className="max-h-[40vh] pr-4">
                  <div className="space-y-6">
                    {items.map((item) => (
                      <div key={item._id + (item.selectedVariant || "")} className="flex gap-4 group">
                        <div className="h-20 w-20 rounded-xl overflow-hidden bg-slate-50 border border-slate-100 shrink-0">
                          <img src={item.imageSrc} alt={item.title} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                        </div>
                        <div className="flex-1 min-w-0 flex flex-col justify-center">
                           <h4 className="text-sm font-bold text-slate-900 truncate">{item.title}</h4>
                           <div className="flex items-center gap-2 mt-1">
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{item.selectedVariant || "Standard Edition"}</span>
                              <span className="text-slate-200">•</span>
                              <span className="text-[10px] font-bold text-slate-400">Qty: {item.quantity}</span>
                           </div>
                           <p className="text-sm font-bold text-slate-900 mt-1">৳{(item.price * item.quantity).toLocaleString()}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                <div className="mt-8 pt-8 border-t border-slate-100 space-y-6">
                  {/* Coupon UI */}
                  {!appliedCoupon?.code ? (
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                        <input 
                          type="text" 
                          placeholder="Coupon code" 
                          value={couponCode}
                          onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                          className="w-full h-11 pl-9 pr-4 rounded-xl border border-slate-200 text-sm outline-none focus:ring-4 focus:ring-indigo-50 focus:border-indigo-400 placeholder:text-slate-400 transition-all font-semibold"
                        />
                      </div>
                      <Button 
                        onClick={handleApplyCoupon}
                        disabled={!couponCode || isValidating}
                        className="h-11 px-6 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 disabled:opacity-50 transition-all"
                      >
                        {isValidating ? <Loader2 className="h-4 w-4 animate-spin" /> : "Apply"}
                      </Button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between p-4 bg-indigo-50 border border-indigo-100 rounded-xl">
                       <div className="flex items-center gap-3">
                          <Tag className="h-4 w-4 text-indigo-600" />
                          <span className="text-sm font-bold text-slate-900">{appliedCoupon.code}</span>
                       </div>
                       <button onClick={removeCoupon} className="text-xs font-bold text-rose-500 hover:text-rose-600 transition-colors">Remove</button>
                    </div>
                  )}

                  <div className="space-y-3">
                     <div className="flex justify-between text-sm">
                       <span className="text-slate-500">Subtotal</span>
                       <span className="text-slate-900 font-bold">৳{subtotal.toLocaleString()}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-sm font-bold text-emerald-600">
                         <span>Coupon discount</span>
                         <span>−৳{discount.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                       <span className="text-slate-500">Shipping estimate</span>
                       <span className="text-slate-900 font-bold">{deliveryCharge > 0 ? `৳${deliveryCharge.toLocaleString()}` : "Calculated later"}</span>
                    </div>
                    <Separator className="bg-slate-100 my-4" />
                    <div className="flex justify-between items-end pt-2">
                       <div>
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total</p>
                          <p className="text-3xl font-bold text-slate-900 tracking-tighter tabular-nums leading-none">৳{finalTotal.toLocaleString()}</p>
                       </div>
                    </div>
                  </div>
                </div>

                <div className="mt-10">
                   <Button 
                     onClick={() => {
                        const form = document.getElementById("checkout-form") as HTMLFormElement;
                        if (form) form.requestSubmit();
                     }}
                     disabled={isPlacingOrder}
                     className="w-full h-14 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-sm shadow-xl shadow-indigo-600/20 transition-all flex items-center justify-center gap-2 active:scale-95"
                   >
                     {isPlacingOrder ? <Loader2 className="h-5 w-5 animate-spin" /> : (
                       <>
                          Complete Purchase
                          <ArrowRight className="h-5 w-5 ml-1" />
                       </>
                     )}
                   </Button>
                </div>
              </div>
              
              {/* Payment Partners */}
              <div className="flex flex-col items-center gap-4 py-6 opacity-60">
                 <div className="flex items-center gap-6">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2560px-Visa_Inc._logo.svg.png" className="h-3 grayscale opacity-70" alt="Visa" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/1280px-Mastercard-logo.svg.png" className="h-6 grayscale opacity-70" alt="Mastercard" />
                    <img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/8e/American_Express_logo_%282018%29.svg/1200px-American_Express_logo_%282018%29.svg.png" className="h-7 grayscale opacity-70" alt="Amex" />
                 </div>
                 <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider uppercase">SSL Secured Payment Gateway</p>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Mobile Footer Sticky */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-slate-200 px-6 py-6 pb-8 flex items-center justify-between gap-6 shadow-[0_-10px_30px_rgba(0,0,0,0.05)]">
        <div className="flex flex-col">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Total Due</span>
          <span className="text-2xl font-bold text-slate-900 tracking-tighter">৳{finalTotal.toLocaleString()}</span>
        </div>
        <Button 
          onClick={() => {
            const form = document.getElementById("checkout-form") as HTMLFormElement;
            if (form) form.requestSubmit();
          }}
          disabled={isPlacingOrder}
          className="flex-1 h-14 bg-indigo-600 text-white rounded-2xl font-bold text-sm shadow-xl shadow-indigo-600/20 active:scale-95"
        >
          {isPlacingOrder ? <Loader2 className="h-4 w-4 animate-spin" /> : "Complete Order"}
        </Button>
      </div>
    </div>
  );
}
