import React, { useState } from "react";
import { ShoppingBag, Eye, Zap, Box, Plus, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "./ui/select";
import { Button } from "./ui/button";

interface Product {
  _id: string;
  title: string;
  price: number;
  compareAtPrice?: number;
  imageSrc: string;
  category: string;
  vendor: string;
  stock?: number;
  options?: Array<{ name: string; values: string[] }>;
  variantStock?: Record<string, number>;
}

import { useCart } from "../hooks/useCart";

interface ProductCardProps {
  product: Product;
  onViewProduct: (id: string) => void;
  onBuyNow: (product: Product, variant?: string) => void;
  priority?: boolean;
}

export default function ProductCard({ product, onViewProduct, onBuyNow, priority = false }: ProductCardProps) {
  const { addToCart } = useCart();
  const hasVariants = product.options && 
    product.options.length > 0 && 
    product.options[0].values && 
    product.options[0].values.length > 0;

  const [selectedVariant, setSelectedVariant] = useState<string>(
    hasVariants ? product.options![0].values[0] : ""
  );
  const [isAdding, setIsAdding] = useState(false);

  const discount = product.compareAtPrice 
    ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
    : 0;

  const isOutOfStock = (() => {
    if (hasVariants && selectedVariant) {
      const vStock = product.variantStock?.[selectedVariant] ?? 0;
      return vStock <= 0;
    }
    if (product.stock !== undefined) {
      return product.stock <= 0;
    }
    return false;
  })();

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isOutOfStock) return;
    setIsAdding(true);
    addToCart(product, selectedVariant || undefined);
    setTimeout(() => setIsAdding(false), 800);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isOutOfStock) return;
    onBuyNow(product, selectedVariant || undefined);
  };

  return (
    <motion.div 
      layout
      onClick={() => onViewProduct(product._id)}
      className={`group relative flex flex-col h-full bg-white rounded-2xl border border-slate-200 overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-slate-200/50 hover:border-slate-300 cursor-pointer ${isOutOfStock ? "opacity-75" : ""}`}
    >
      {/* Image Container */}
      <div className="relative aspect-[4/5] bg-slate-100 overflow-hidden">
        <img
          src={product.imageSrc}
          alt={product.title}
          className={`object-cover w-full h-full transition-transform duration-700 ease-out group-hover:scale-105 ${isOutOfStock ? "grayscale opacity-50" : ""}`}
          referrerPolicy="no-referrer"
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          {...(priority ? { fetchPriority: "high" } : {})}
        />
        
        {/* Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          {discount > 0 && !isOutOfStock && (
            <div className="bg-indigo-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow-sm">
              {discount}% OFF
            </div>
          )}
          {isOutOfStock && (
            <div className="bg-slate-900 text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow-sm uppercase tracking-wider">
              Out of Stock
            </div>
          )}
        </div>

        {/* Quick View Button (Desktop) */}
        {!isOutOfStock && (
          <div className="absolute inset-x-0 bottom-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 hidden md:block">
            <Button 
               variant="secondary" 
               className="w-full h-10 bg-white/95 backdrop-blur-sm shadow-lg border-none hover:bg-white text-slate-900 font-semibold text-xs"
            >
              <Eye className="h-3.5 w-3.5 mr-2" />
              Quick View
            </Button>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5 flex flex-col flex-1">
        <div className="mb-4">
          <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest mb-1.5">{product.vendor}</p>
          <h3 className="text-base font-bold text-slate-900 line-clamp-2 leading-snug group-hover:text-indigo-600 transition-colors">
             {product.title}
          </h3>
        </div>

        <div className="mt-auto space-y-4">
          {/* Pricing */}
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-bold text-slate-900">৳{product.price.toLocaleString()}</span>
            {product.compareAtPrice && (
              <span className="text-sm text-slate-400 line-through font-medium">৳{product.compareAtPrice.toLocaleString()}</span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-1 gap-2 pt-2">
             <Button 
               onClick={handleAdd}
               disabled={isAdding || isOutOfStock}
               variant={isAdding ? "default" : "outline"}
               className={`h-10 rounded-xl font-bold text-xs transition-all ${isAdding ? "bg-emerald-600 border-emerald-600 text-white" : "border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50"}`}
             >
                {isAdding ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <>
                    <Plus className="h-4 w-4 mr-2" />
                    Add to Cart
                  </>
                )}
             </Button>
             <Button 
               onClick={handleBuyNow}
               disabled={isOutOfStock}
               className="h-10 rounded-xl bg-slate-900 text-white hover:bg-slate-800 font-bold text-xs"
             >
                Buy Now
             </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export function ProductSkeleton() {
  return (
    <div className="flex flex-col h-full bg-white rounded-2xl border border-slate-100 overflow-hidden animate-pulse">
      <div className="aspect-[4/5] bg-slate-100" />
      <div className="p-5 flex flex-col flex-1 space-y-4">
        <div className="space-y-2">
          <div className="h-2 w-12 bg-slate-100 rounded-full" />
          <div className="h-4 w-full bg-slate-100 rounded-full" />
          <div className="h-4 w-2/3 bg-slate-100 rounded-full" />
        </div>
        <div className="mt-auto space-y-4">
          <div className="h-6 w-24 bg-slate-100 rounded-full" />
          <div className="grid grid-cols-2 gap-2 pt-2">
            <div className="h-10 bg-slate-50 rounded-xl" />
            <div className="h-10 bg-slate-100 rounded-xl" />
          </div>
        </div>
      </div>
    </div>
  );
}
