import React from "react";
import { ShoppingCart, ShoppingBag, LayoutDashboard, Activity, Terminal } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useCart } from "../hooks/useCart";

interface NavbarProps {
  onOpenCart: () => void;
  view: "shop" | "dashboard" | "checkout" | "product" | "tracking";
  setView: (view: "shop" | "dashboard" | "checkout" | "product" | "tracking") => void;
}

export default function Navbar({ onOpenCart, view, setView }: NavbarProps) {
  const { cartCount } = useCart();
  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-slate-200">
      <div className="container mx-auto px-4 h-16 md:h-20 flex items-center justify-between">
        
        {/* Logo */}
        <button 
          onClick={() => setView("shop")} 
          className="flex items-center gap-2.5 group"
        >
          <div className="bg-indigo-600 p-2 rounded-lg shadow-sm group-hover:bg-indigo-700 transition-colors">
            <Terminal className="h-5 w-5 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight text-slate-900">
            Case<span className="text-indigo-600">Hub</span>
          </span>
        </button>

        {/* Navigation Items */}
        <div className="flex items-center gap-1 md:gap-4">
          <div className="hidden md:flex items-center gap-1">
            {[
              { id: "shop", label: "Shop", icon: ShoppingBag },
              { id: "tracking", label: "Track Order", icon: Activity },
              { id: "dashboard", label: "Dashboard", icon: LayoutDashboard }
            ].map((item) => {
              const isActive = (view === item.id || (item.id === "shop" && (view === "shop" || view === "product" || view === "checkout")));
              return (
                <button 
                  key={item.id}
                  onClick={() => setView(item.id as any)}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    isActive
                    ? "text-indigo-600 bg-indigo-50" 
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          <div className="w-px h-6 bg-slate-200 mx-2 hidden md:block" />

          {/* Cart Trigger */}
          <button 
            onClick={onOpenCart} 
            className="relative p-2.5 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all active:scale-95 group"
          >
            <ShoppingCart className="h-5 w-5 transition-transform group-hover:scale-105" />
            <AnimatePresence>
              {cartCount > 0 && (
                <motion.span 
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.5, opacity: 0 }}
                  className="absolute -top-0.5 -right-0.5 h-5 w-5 flex items-center justify-center rounded-full bg-indigo-600 text-white text-[10px] font-bold border-2 border-white shadow-sm"
                >
                  {cartCount}
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>
      </div>
    </nav>
  );
}
