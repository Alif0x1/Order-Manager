import React, { useState, useEffect } from "react";
import { Plus, Minus, ShoppingCart, ArrowRight, Loader2, Trash2, Box, Tag } from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { AnimatePresence, motion } from "motion/react";
import { toast } from "sonner";
import { Separator } from "./ui/separator";

interface CartItem {
  _id: string;
  title: string;
  price: number;
  imageSrc: string;
  quantity: number;
  selectedVariant?: string;
}

import { useCart } from "../hooks/useCart";

interface CartProps {
  onCheckout: () => void;
}

export default function Cart({ onCheckout }: CartProps) {
  const { 
    items, 
    updateQuantity, 
    removeFromCart, 
    discount, 
    subtotal, 
    total, 
    applyCoupon, 
    removeCoupon,
    appliedCoupon 
  } = useCart();
  const [couponCode, setCouponCode] = useState("");
  const [isValidating, setIsValidating] = useState(false);

  useEffect(() => {
    if (appliedCoupon?.code) setCouponCode(appliedCoupon.code);
  }, [appliedCoupon]);

  const handleApply = async () => {
    if (!couponCode) return;
    setIsValidating(true);
    try {
      const response = await fetch("/api/coupons/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: couponCode, cartTotal: subtotal })
      });
      if (response.ok) {
        const data = await response.json();
        applyCoupon(data);
        toast.success(`Coupon ${data.code} applied!`);
      } else {
        const err = await response.json();
        toast.error(err.error || "Invalid coupon");
      }
    } catch (error) {
      toast.error("Failed to apply coupon");
    } finally {
      setIsValidating(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center px-10 bg-white">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-slate-50 w-24 h-24 rounded-full flex items-center justify-center mb-6 border border-slate-100 shadow-sm"
        >
          <Box className="h-8 w-8 text-slate-300" />
        </motion.div>
        <h3 className="text-xl font-bold text-slate-900 mb-2">Your cart is empty</h3>
        <p className="text-sm text-slate-500 max-w-[240px]">
          Looks like you hasn't added anything to your cart yet.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-6 border-b border-slate-100 bg-white/80 backdrop-blur-md z-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-50 p-2 rounded-lg">
             <ShoppingCart className="h-5 w-5 text-indigo-600" />
          </div>
          <h2 className="text-lg font-bold text-slate-900">
            Shopping Cart <span className="text-slate-400 font-normal ml-1">({items.length})</span>
          </h2>
        </div>
      </div>

      {/* Item List */}
      <ScrollArea className="flex-1 px-6">
        <div className="py-6 space-y-6">
          <AnimatePresence initial={false} mode="popLayout">
            {items.map((item) => (
              <motion.div 
                key={`${item._id}-${item.selectedVariant || "default"}`}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="group flex gap-4"
              >
                {/* Image */}
                <div className="h-20 w-20 rounded-xl overflow-hidden bg-slate-100 flex-shrink-0 border border-slate-200">
                  <img src={item.imageSrc} alt={item.title} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                </div>

                {/* Info */}
                <div className="flex-1 flex flex-col justify-between py-0.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h4 className="text-sm font-bold text-slate-900 truncate">{item.title}</h4>
                      {item.selectedVariant && (
                        <p className="text-[10px] font-semibold text-indigo-600 mt-1 uppercase tracking-wider">
                          {item.selectedVariant}
                        </p>
                      )}
                    </div>
                    <button 
                      onClick={() => removeFromCart(item._id, item.selectedVariant)} 
                      className="text-slate-400 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-base font-bold text-slate-900">৳{(item.price * item.quantity).toLocaleString()}</p>
                    
                    <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-lg border border-slate-200/50">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => updateQuantity(item._id, -1, item.selectedVariant)} 
                        disabled={item.quantity <= 1} 
                        className="h-7 w-7 rounded-md hover:bg-white text-slate-500 hover:text-slate-900"
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="text-xs font-bold text-slate-900 w-6 text-center">{item.quantity}</span>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => updateQuantity(item._id, 1, item.selectedVariant)} 
                        className="h-7 w-7 rounded-md hover:bg-white text-slate-500 hover:text-slate-900"
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </ScrollArea>
      
      {/* Summary */}
      <div className="p-6 bg-slate-50 border-t border-slate-100 shrink-0 space-y-4">
        {/* Coupon */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
            <Input 
              placeholder="Coupon code" 
              value={couponCode}
              onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
              disabled={!!appliedCoupon?.code}
              className="h-10 pl-9 bg-white border-slate-200 rounded-xl text-sm focus:ring-indigo-100" 
            />
          </div>
          <Button 
            onClick={appliedCoupon?.code ? removeCoupon : handleApply}
            disabled={isValidating || (!couponCode && !appliedCoupon?.code)}
            variant={appliedCoupon?.code ? "secondary" : "default"}
            className="h-10 px-4 rounded-xl text-xs font-bold"
          >
            {isValidating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : appliedCoupon?.code ? "Remove" : "Apply"}
          </Button>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-slate-500">Subtotal</span>
            <span className="text-slate-900 font-semibold">৳{subtotal.toLocaleString()}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-sm text-emerald-600 font-medium">
              <span>Discount</span>
              <span>−৳{discount.toLocaleString()}</span>
            </div>
          )}
          <Separator className="bg-slate-200" />
          <div className="flex justify-between items-end pt-1">
            <span className="text-slate-900 font-bold">Total</span>
            <span className="text-2xl font-bold text-slate-900">৳{total.toLocaleString()}</span>
          </div>
        </div>

        <Button 
          onClick={onCheckout} 
          className="w-full h-14 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-sm shadow-lg shadow-indigo-600/20 active:scale-[0.98] transition-all"
        >
          Check out now <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}
