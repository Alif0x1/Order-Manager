import React from "react";
import { motion } from "motion/react";

interface WavyTextProps {
  text: string;
  className?: string;
}

export default function WavyText({ text, className = "" }: WavyTextProps) {
  // Split text into characters, including spaces
  const characters = text.split("");

  return (
    <h2 className={`flex overflow-hidden pb-2 ${className}`}>
      {characters.map((char, i) => (
        <motion.span
          key={i}
          animate={{
            y: [0, -8, 0],
          }}
          transition={{
            duration: 2.5,
            repeat: Infinity,
            delay: i * 0.1,
            ease: "easeInOut",
          }}
          whileHover={{
            y: -15,
            scale: 1.2,
            transition: { duration: 0.2, delay: 0 },
          }}
          className={`inline-block ${char === " " ? "mr-4" : ""} bg-gradient-to-b from-slate-900 via-indigo-600 to-emerald-500 bg-clip-text text-transparent select-none`}
        >
          {char}
        </motion.span>
      ))}
    </h2>
  );
}
