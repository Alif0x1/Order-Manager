import React from "react";
import { motion } from "motion/react";
import { Search, Sparkles } from "lucide-react";

interface HeroSectionProps {
  searchValue: string;
  onSearchChange: (value: string) => void;
}

export default function HeroSection({ searchValue, onSearchChange }: HeroSectionProps) {
  return (
    <div className="relative w-full pt-20 pb-24 md:pt-32 md:pb-40 flex flex-col items-center justify-center overflow-hidden bg-slate-50">
      
      {/* Background decoration - subtle indigo glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-indigo-500/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="relative z-10 w-full max-w-4xl px-6 flex flex-col items-center text-center">
        
        {/* Chips/Badges */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-slate-200 shadow-sm mb-10"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
          <span className="text-xs font-semibold text-slate-600">Premium Tech Accessories</span>
        </motion.div>

        {/* Headline */}
        <div className="space-y-6 mb-12">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-extrabold tracking-tight text-slate-900"
          >
            Smarter care for <br /> 
            <span className="text-indigo-600">your daily tech.</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-lg md:text-xl text-slate-500 max-w-2xl mx-auto leading-relaxed"
          >
            Engineered for precision. Crafted for style. Discover the collection of premium cases and shields designed for interstellar citizens.
          </motion.p>
        </div>

        {/* Search Field */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="w-full max-w-2xl relative group"
        >
          <div className="absolute inset-0 bg-indigo-600/5 rounded-2xl blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity" />
          <div className="relative">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
            <input 
              type="text"
              value={searchValue}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search for products, vendors, or categories..."
              className="w-full h-16 md:h-18 pl-14 pr-6 rounded-2xl bg-white border border-slate-200 text-slate-900 text-lg outline-none focus:ring-4 focus:ring-indigo-100 focus:border-indigo-400 transition-all shadow-sm"
            />
          </div>
        </motion.div>

        {/* Quick Tags */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-8 flex flex-wrap justify-center gap-3"
        >
          <span className="text-xs text-slate-400 font-medium">Popular:</span>
          {["iPhone 15", "Galaxy S24", "MacBook Pro", "iPad Air"].map((tag) => (
            <button 
              key={tag}
              onClick={() => onSearchChange(tag)}
              className="text-xs font-semibold text-slate-500 hover:text-indigo-600 transition-colors"
            >
              {tag}
            </button>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
