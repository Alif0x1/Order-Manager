import React, { createContext, useContext, useState, useEffect, useMemo } from "react";
import { toast } from "sonner";

/**
 * simpleCart.js - High-Fidelity Global Cart Context
 * Provides a unified order state across the entire administrative ecosystem.
 */

const CartContext = createContext();

export function CartProvider({ children }) {
  const [items, setItems] = useState([]);
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [selectedLocation, setSelectedLocation] = useState("");
  const [onAddItemCallback, setOnAddItemCallback] = useState(null);

  // Derived calculations
  const subtotal = useMemo(() => 
    items.reduce((sum, item) => sum + (item.price * item.quantity), 0),
  [items]);

  const cartCount = useMemo(() => 
    items.reduce((sum, item) => sum + item.quantity, 0),
  [items]);

  const discount = useMemo(() => {
    if (!appliedCoupon) return 0;
    if (appliedCoupon.minOrder && subtotal < appliedCoupon.minOrder) return 0;
    
    if (appliedCoupon.type === "percentage") {
      return (subtotal * appliedCoupon.value) / 100;
    } else {
      return Math.min(appliedCoupon.value, subtotal);
    }
  }, [appliedCoupon, subtotal]);

  const total = useMemo(() => Math.max(0, subtotal - discount), [subtotal, discount]);

  // Sync with LocalStorage on Mount
  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedItems = localStorage.getItem("cart_items");
      const savedCoupon = localStorage.getItem("applied_coupon");
      const savedLocation = localStorage.getItem("selected_location");

      if (savedItems) setItems(JSON.parse(savedItems));
      if (savedCoupon) setAppliedCoupon(JSON.parse(savedCoupon));
      if (savedLocation) setSelectedLocation(savedLocation);
    }
  }, []);

  // Sync across tabs
  useEffect(() => {
    const handleSync = (e) => {
      if (e.key === "cart_items") setItems(JSON.parse(e.newValue || "[]"));
      if (e.key === "applied_coupon") setAppliedCoupon(JSON.parse(e.newValue || "null"));
      if (e.key === "selected_location") setSelectedLocation(e.newValue || "");
    };
    window.addEventListener("storage", handleSync);
    return () => window.removeEventListener("storage", handleSync);
  }, []);

  // Persistence bridge
  useEffect(() => {
    localStorage.setItem("cart_items", JSON.stringify(items));
  }, [items]);

  useEffect(() => {
    localStorage.setItem("applied_coupon", JSON.stringify(appliedCoupon));
  }, [appliedCoupon]);

  useEffect(() => {
    localStorage.setItem("selected_location", selectedLocation);
  }, [selectedLocation]);


  // Core actions
  const addToCart = (product, variant) => {
    const variantKey = variant || "";
    setItems((prev) => {
      const existing = prev.find(
        (item) => item._id === product._id && (item.selectedVariant || "") === variantKey
      );
      if (existing) {
        return prev.map((item) =>
          item._id === product._id && (item.selectedVariant || "") === variantKey
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { 
        _id: product._id,
        title: product.title,
        price: product.price,
        imageSrc: product.imageSrc,
        quantity: 1, 
        selectedVariant: variantKey 
      }];
    });
    
    // Trigger auto-open if registered
    if (onAddItemCallback) onAddItemCallback();

    toast.success("Added to deployment registry", {
      description: `${product.title} has been staged for delivery.`
    });
  };

  const updateQuantity = (id, delta, variant) => {
    const variantKey = variant || "";
    setItems((prev) =>
      prev.map((item) => {
        if (item._id === id && (item.selectedVariant || "") === variantKey) {
          return { ...item, quantity: Math.max(1, item.quantity + delta) };
        }
        return item;
      })
    );
  };

  const removeFromCart = (id, variant) => {
    const variantKey = variant || "";
    setItems((prev) => prev.filter((item) => !(item._id === id && (item.selectedVariant || "") === variantKey)));
    toast.info("Item removed from registry");
  };

  const applyCoupon = (couponData) => {
    setAppliedCoupon(couponData);
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
  };

  const clearCart = () => {
    setItems([]);
    setAppliedCoupon(null);
    if (typeof window !== "undefined") {
      localStorage.removeItem("cart_items");
      localStorage.removeItem("applied_coupon");
    }
    toast.success("Order registry cleared");
  };

  const value = {
    items,
    cartCount,
    subtotal,
    discount,
    total,
    appliedCoupon,
    selectedLocation,
    setOnAddItemCallback,
    addToCart,
    updateQuantity,
    removeFromCart,
    applyCoupon,
    removeCoupon,
    setSelectedLocation,
    clearCart
  };

  return React.createElement(CartContext.Provider, { value: value }, children);
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
