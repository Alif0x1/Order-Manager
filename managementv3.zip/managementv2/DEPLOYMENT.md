# Deployment Guide - Order Management System

This guide outlines how to deploy the Water Management & Order System to a production server (VPS) running Ubuntu/Linux.

## Prerequisites

1.  **Node.js**: Install Node.js 20 or later.
2.  **MongoDB**: A MongoDB Atlas connection string (or a local MongoDB instance).
3.  **PM2**: Install PM2 globally: `npm install -g pm2`.
4.  **Nginx**: (Optional) For reverse proxying.

---

## Option 1: Manual Deployment (VPS)

### 1. Clone & Install
```bash
git clone <your-repo-url>
cd water-management-&-order-system
npm install
```

### 2. Configure Environment Variables
Copy the example file and fill in your actual credentials:
```bash
cp .env.example .env
nano .env
```

### 3. Build the Frontend
```bash
npm run build:prod
```

### 4. Start with PM2
```bash
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
```

---

## Option 2: Docker Deployment

### 1. Build the Image
```bash
docker build -t order-manager .
```

### 2. Run the Container
```bash
docker run -d \
  -p 3000:3000 \
  --env-file .env \
  --name order-system \
  order-manager
```

---

## Option 3: Vercel Deployment

The project includes a `vercel.json` and is ready for Vercel. 
1. Push your code to GitHub.
2. Import the project in Vercel.
3. Add your environment variables in the Vercel Dashboard.
4. Vercel will automatically detect the build settings.

---

## Nginx Configuration (Reverse Proxy)

To map your domain (e.g., `order.example.com`) to the app running on port 3000:

```nginx
server {
    listen 80;
    server_name order.example.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Maintenance Logs

- View PM2 logs: `pm2 logs order-manager`
- View Docker logs: `docker logs -f order-system`
