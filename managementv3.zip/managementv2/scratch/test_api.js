
async function testFraudShieldAPI() {
  const apiKey = "cf_Nk6g2U63OTOQizNz4xaW3nZ0s5VPqJM9";
  const url = "https://fraudshield.bd/api/usage/daily-limit";
  
  console.log(`Testing FraudShield API with key: ${apiKey}`);
  console.log(`URL: ${url}`);
  
  try {
    const response = await fetch(url, {
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Accept": "application/json"
      }
    });
    
    const result = await response.json();
    console.log("Response Status:", response.status);
    console.log("Response Data:", JSON.stringify(result, null, 2));
    
    if (response.ok && result.success) {
      console.log("✅ API Key is VALID");
    } else {
      console.log("❌ API Key is INVALID or check failed");
    }
  } catch (error) {
    console.error("❌ Request Failed:", error.message);
  }
}

testFraudShieldAPI();
