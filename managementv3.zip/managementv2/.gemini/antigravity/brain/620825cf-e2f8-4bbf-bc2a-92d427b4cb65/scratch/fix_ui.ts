import fs from 'fs';
import path from 'path';

const filePath = path.join(process.cwd(), 'src/components/AdminPortal.tsx');
let content = fs.readFileSync(filePath, 'utf8');

// Target the Revenue Analytics header block precisely
const targetRegex = /<CardHeader className="p-8 border-b border-slate-100 flex-col items-center">[\s\S]*?<div className="flex flex-col items-center gap-4">([\s\S]*?)<\/div>/;

const replacement = `<CardHeader className="p-8 border-b border-slate-100">
                           <div className="flex flex-col sm:flex-row justify-between items-center gap-6 w-full">
                              <div className="flex items-center gap-4">
                                 <div className="h-12 w-12 bg-indigo-50 rounded-2xl flex items-center justify-center border border-indigo-100 group-hover:scale-110 transition-transform duration-500">
                                     <BarChart3 className="h-6 w-6 text-indigo-600" />
                                 </div>
                                 <div className="text-left">
                                     <CardTitle className="text-xl font-black text-slate-900 tracking-tight leading-none">Revenue Analytics</CardTitle>
                                     <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mt-2">Operational Performance Registry</p>
                                 </div>
                              </div>`;

content = content.replace(targetRegex, replacement);

fs.writeFileSync(filePath, content);
console.log('UI Fix Applied Successfully');
